"""Bind live acceptance to the newly built source, covering both primary and compilation routes."""
from pathlib import Path
import ast,json
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch08-ai-only-20261002';D=W/'delivery'
rev=json.loads((W/'reader-commit.json').read_bytes())['commit'];assert (D/'source-revision.txt').read_text().strip()==rev
assert (D/'source-preservation-after-build.json').exists()
p=D/'deploy_verified_snapshot.py';s=p.read_text(encoding='utf8');old="assert changed and set(changed)<=allowed,'Non-handoff source changed after build'";assert old in s;s=s.replace(old,"assert changed and all(p=='STORY_QUALITY_HANDOFF.md' or p.startswith('docs/story-quality/') for p in changed),'Non-handoff source changed after build'");ast.parse(s);p.write_text(s,encoding='utf8')
old=json.loads((O/'delivery/online-verification-targets.json').read_bytes());plan=json.loads((W/'repair-plan.json').read_bytes());text=json.loads((W/'text-plan.json').read_bytes())
old.update(source_revision=rev,changed_paths=sorted(set(old['changed_paths'])|{x['path'] for x in plan['reader_files']}),committed_txt_paths=sorted(set(old['committed_txt_paths'])|{x['path'] for x in text['files'] if x['path'].startswith('website/public/')}));(D/'online-verification-targets.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
targets=[['510301-1', '五分之四'], ['510301-10', '全部答对了'], ['510510-6_Hemql', '鼓手'], ['510510-10_Hemql', '把想法喊出来'], ['510520-4_5XtSr', '我相信你们'], ['510520-10_5XtSr', '较真的样子'], ['510601-1', '同一个场景'], ['510602-3', '铁人三项'], ['510603-3', '独自生活'], ['510604-5', '冰红茶'], ['510604-5', '冰红茶', '510601-04'], ['510710-4_1DyhN', '双腿不能动'], ['510710-11_1DyhN', '补充盐分和水分'], ['510720-5_eP7q2', '既然死了就会被遗忘'], ['510720-10_eP7q2', '还没到该打开的时候'], ['510204-3_m4VmX', '杀了她'], ['340613-3', '为了保护弱者'], ['311133-4', '明日香的表妹']]
for sid,t,*route in targets:
 f=W/'review'/(sid+'.final.txt')
 if f.exists():assert t in f.read_text(encoding='utf8').replace('@',''),(sid,t)
s=(O/'browser_verify.cjs').read_text(encoding='utf8');a=s.index('const targets=');b=s.index('\n(async()=>',a)
s=s[:a]+'const targets='+json.dumps(targets,ensure_ascii=False)+".map(([sid,text,routeHint])=>{const choices=index.filter(s=>(s.json_sources_cn||[]).some(p=>path.basename(p)===sid+'.json'));const s=routeHint?choices.find(s=>String(s.id)===routeHint):choices.sort((a,b)=>a.json_sources_cn.length-b.json_sources_cn.length)[0];if(!s)throw Error('No exact route '+sid+' '+routeHint);return{sid,text,route:s.id,url:'https://magireader.pages.dev/reader/'+encodeURIComponent(s.id)+'?cn='+encodeURIComponent(s.path_cn)+'&jp='+encodeURIComponent(s.path_jp)}});"+s[b:]
s=s.replace('results.length===32','results.length===36');(W/'browser_verify.cjs').write_text(s,encoding='utf8')
s=(O/'accept_live.py').read_text(encoding='utf8').replace("b['checks']==32","b['checks']==36").replace("'BROWSER_PASS',32","'BROWSER_PASS',36");ast.parse(s);(W/'accept_live.py').write_text(s,encoding='utf8')
p=W/'release_after_build.py';s=p.read_text(encoding='utf8').replace("b['checks']==32","b['checks']==36");ast.parse(s);p.write_text(s,encoding='utf8')
(W/'browser-targets.json').write_text(json.dumps(targets,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('ACCEPTANCE_READY',len(targets)*2,'primary-and-compilation-browser checks',len(old['changed_paths']),'source targets',len(old['committed_txt_paths']),'web texts',flush=True)
