"""Validate the fully read AI-only batch, including unchanged previously-complete context without double counting."""
from pathlib import Path
import sys,json,gzip,hashlib,subprocess,datetime
W=Path(__file__).resolve().parent;ROOT=W.parent;R=ROOT/'repo'
sys.path[:0]=[str(W),str(ROOT/'semantic-batch03-20261001'),str(ROOT/'control-authority-20260930'),str(ROOT/'severe-5109-20261001')]
from exact_json import apply,blob
from translation_rules import validate,execution_tokens,color_types
from collect_review import fields
from census import Store
S=Store()
def read(n):return json.loads((W/n).read_bytes())
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def save(n,x):(W/n).write_bytes(enc(x))
def main():
 p=read('repair-plan.json');t=read('text-plan.json');rt=read('reader-tree.json');pt=read('patch-tree.json');render=read('reader-render-validation.json');source=read('review-sources.json')
 assert len(source)==len(p['reviewed_stories'])==len(p['completed_review_stories'])==73 and not p['pending_adjudication_stories']
 assert len(p['reader_files'])==len(p['runtime_files'])==70 and p['reviewed_fields']==4152 and p['changed_fields']==2217
 assert len({s['chapter_id'] for s in source})==9 and sum(s['cn_fields'] for s in source)==4152
 assert render['passed'] and render['actualParser'] and len(render['files'])==73 and render['restoredPreviouslyEmptyDisplayFields']==0
 assert not t['holds'] and not t['missing']
 tests=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(W),'-p','test_translation_rules.py','-v'],cwd=W,capture_output=True,text=True,encoding='utf8');(W/'translation-tests.log').write_text(tests.stdout+tests.stderr,encoding='utf8');assert tests.returncode==0 and 'Ran 23 tests' in tests.stderr
 tests2=subprocess.run(['node','--test',str(W/'test_reader_recovery.cjs'),str(W/'test_narrator_recovery.cjs')],cwd=W,capture_output=True,text=True,encoding='utf8');(W/'reader-recovery-tests.log').write_text(tests2.stdout+tests2.stderr,encoding='utf8');assert tests2.returncode==0 and 'tests 17' in tests2.stdout and 'fail 0' in tests2.stdout
 decisions={s['id']:read('review/'+s['id']+'.edits.json') for s in source};names=0;body=0;placeholders=0
 for s in source:
  d=decisions[s['id']];assert d['reviewed_all_fields'] and d['source_cn_blob']==s['cn_sha'] and d['source_jp_blob']==s['jp_sha'] and d['field_count']==s['cn_fields']
 for f in p['reader_files']:
  a=(W/'originals/reader'/f['path']).read_bytes();b=(W/'stage/reader'/f['path']).read_bytes();d=decisions[Path(f['path']).stem]
  allowed=[[x['address'],x['before'],x['after']] for x in d.get('name_edits',[])];names+=len(allowed);body+=len(f['operations'])-len(allowed)
  assert blob(a)==f['before'] and blob(b)==f['after'];validate(a,b,f['operations'],allowed_name_operations=allowed);assert apply(b,[[at,new,old] for at,old,new in f['operations']])==a
  af,bf=fields(json.loads(a)),fields(json.loads(b));assert len(af)==len(bf)
  for x,y in zip(af,bf):
   assert x['address']==y['address'] and x['text'].count('userName')==y['text'].count('userName');placeholders+=x['text'].count('userName')
   assert execution_tokens(x['text'])==execution_tokens(y['text']) and color_types(x['text'])==color_types(y['text'])
 assert body==2217 and names==0
 for f in t['files']:
  a=S.get(f['before']);b=(W/'stage/reader'/f['path']).read_bytes();assert blob(b)==f['after'];bom=b'\xef\xbb\xbf' if b.startswith(b'\xef\xbb\xbf') else b'';undo=b[len(bom):].decode()
  for e in sorted(f['edits'],key=lambda x:x['after_start'],reverse=True):
   assert undo[e['after_start']:e['after_end']]==e['after_text'];undo=undo[:e['after_start']]+e['before_text']+undo[e['after_end']:]
  assert bom+undo.encode()==a
 authorized=json.loads((R/'docs/reader-availability-local-20260929.json').read_bytes())['protected_source_failure']['paths'];assert len(authorized)==196
 changed={x['path'] for x in p['reader_files']}|{x['path'] for x in t['files']};assert not set(authorized)&changed
 for path in authorized:assert blob((R/path).read_bytes())==rt[path]
 v4=json.loads((R/'manifests/authoritative_scenario_runtime_repairs.v1.json').read_bytes())['entries'];assert len(v4)==43;protected={}
 for f in v4:
  path=f['target_path'];assert path not in changed and blob((R/path).read_bytes())==rt[path]
  peer=[z for z in pt if z.startswith('madomagi/resource/scenario/json/adv/') and Path(z).name==Path(path).name];assert len(peer)==1;protected[peer[0]]=pt[peer[0]]
 assert not set(protected)&{f['path'] for f in p['runtime_files']}
 for path,h in read('dirty-tracked-hashes.json').items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==h
 anchors={'510301-1': ['五分之四', '分数'], '510301-6': ['新玛吉斯'], '510510-6_Hemql': ['鼓手', '海滨小店'], '510520-4_5XtSr': ['相信你们'], '510520-10_5XtSr': ['较真的样子'], '510602-3': ['铁人三项'], '510602-5': ['魔法！！好好吃棒'], '510603-3': ['独自生活'], '510604-5': ['冰红茶'], '510710-4_1DyhN': ['双腿不能动'], '510710-11_1DyhN': ['补充盐分和水分', '小红花'], '510720-5_eP7q2': ['既然死了就会被遗忘'], '510720-7_eP7q2': ['活过的证明'], '510720-10_eP7q2': ['还没到该打开的时候']}
 for sid,terms in anchors.items():
  text=(W/'review'/(sid+'.final.txt')).read_text(encoding='utf8').replace('@','')
  for term in terms:assert term in text,(sid,term)
 context=[x for x in source if x.get('already_complete_context_only')];assert len(context)==2 and sum(x['cn_fields'] for x in context)==108
 for x in context:
  assert not decisions[x['id']]['edits'] and x['cn_path'] not in changed
  assert blob((W/'stage/reader'/x['cn_path']).read_bytes())==x['cn_sha']
 unchanged_new=[x for x in source if not x['already_complete_context_only'] and x['cn_path'] not in changed]
 assert [x['id'] for x in unchanged_new]==['510710-5_1DyhN']
 for x in unchanged_new:
  assert not decisions[x['id']]['edits'] and blob((W/'stage/reader'/x['cn_path']).read_bytes())==x['cn_sha']
 inputs=p['inputs']|t.get('inputs',{})
 for path in authorized:inputs[path]=rt[path]
 for f in v4:inputs[f['target_path']]=rt[f['target_path']]
 for path in ['docs/reader-availability-local-20260929.json','manifests/authoritative_scenario_runtime_repairs.v1.json']:inputs[path]=rt[path]
 save('reader-inputs.json',inputs);save('protected-v4.json',protected)
 now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 v={'schema':3,'batch':p['batch'],'validated_at':now,'indexed_chapters_complete':9,'scenes_full_read':73,'complete_scenes_reviewed':73,'new_complete_scenes':71,'previous_complete_context_scenes':2,'new_reviewed_fields':4044,'context_fields':108,'pending_source_adjudication':[],'display_fields_reviewed':4152,'display_fields_revised':2217,'body_fields_revised':body,'explicit_speaker_label_repairs':names,'display_only':True,'exact_reverse_to_original_bytes':True,'nontext_structure_actor_identity_and_audio_unchanged':True,'AI_import_source_verified':True,'executable_tags_and_highlight_types_unchanged':True,'player_name_placeholders_preserved':placeholders,'actual_reader_parser_files':73,'actual_reader_events_and_audio_metadata_unchanged_except_source_proven_missing_display':True,'restored_previously_empty_display_fields':0,'restored_display_explanation':'No new previously-empty Reader display event. Existing missing/mistranslated visible words are corrected inside already displayed fields; execution identities preserved.','specialized_tests_passed':23,'additional_missing_display_contract_tests':17,'reader_txt_files':len(t['files']),'reader_txt_field_spans':t['physical_field_span_edits'],'historical_full_section_baselines':len(read('historical-text-baselines.json')),'multiline_artifact_spans':t['multiline_artifact_spans'],'txt_missing_fields':0,'txt_alignment_holds':0,'protected_v4_unchanged':43,'protected_authorized_cn_unchanged':196,'unrelated_dirty_paths_unchanged':True,'review_method':p['review_method'],'official_or_human_provenance_not_asserted':True,'published':False,'whole_corpus_complete':False,'device_gameplay_verified':False}
 v.update(changed_runtime_scripts=70,new_complete_unchanged_scripts=['510710-5_1DyhN'])
 save('validation.json',v)
 evidence={'validation':v,'plan':p,'text_plan':t,'historical_baselines':read('historical-text-baselines.json'),'decisions':decisions,'provenance':read('provenance.json'),'chapters':read('chapters.json'),'explicit_name_repairs':[],'missing_display_restoration':read('missing-display-restoration.json'),'second_pass':read('final-name-refinements.json'),'trusted_term_evidence':{f.name:json.loads(f.read_bytes()) for f in W.glob('trusted-*.json')}}
 report=f"""# Batch09 validated source evidence before3321

9 non-overlapping primary chapters;73 unique scripts and4152 display fields read in full against Japanese.71 newly completed scripts/4044 fields and2 previously-complete context scripts/108 fields.2217 body corrections in70 scripts. Newly completed510710-5 remains byte-identical because the inherited translation is accurate; it counts as a complete review, NOT a modified script. No speaker labels, new display events, executable commands, actor identities or audio changed.

Full event5103 Sudachi training,5105 Mixed Summer,5106 Unknown Story and5107 Aquarium.20 paired TXT files including510601-04 compilation;5650 exact physical spans and11 full-section historical baselines. Compilation aliases do not count as additional independent chapters or scripts.23 translation and17 recovery refusal tests plus73 actual Reader parser checks.43V4,196authorized Chinese sources and original unrelated dirty files preserved. Model-assisted proofreading does not reassign official/human authorship. No L2D/AIO/APK/font changes.

Cumulative contributions and full processed/pending inventories reside ONLY in HiiragiNemu/magireco-cn-patch. This source-validation evidence is not a publication receipt or gameplay verification.
"""
 folder='manifests/story_quality_semantic_batch09_ai_only_20261002';files={folder+'.json':enc(v),folder+'_evidence.json.gz':gzip.compress(enc(evidence),mtime=0),'docs/story-quality/20261002-semantic-batch09-validated.md':report.encode()}
 for repo in ['reader','patch']:
  for path,b in files.items():q=W/'stage'/repo/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 for f in (W/'review').glob('*.final.txt'):
  q=W/'stage/reader/docs/story-quality/reviewed/20261002-semantic-batch09-ai-only'/f.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
 progress=read('progress.json');progress.update(stage='validated',validation=v,checkpoint='9整话73片段4152字段全文复核，71新完成/2旧上下文；70脚本2217正文修订与20TXT5650片段验证通过，待3321及Reader/ADV交付',next=['仅既有main提交新文字','3320基线发布3321并核验玩家入口','独立干净Reader构建部署与ADV登记','累计清单仅CN patch']);save('progress.json',progress);S.close();print('VALIDATED',json.dumps(v,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
