"""Finalize verified3321 delivery; aggregate ledger and recovery only in CN patch."""
from pathlib import Path
import sys,json,zipfile,hashlib,datetime
W=Path(__file__).resolve().parent;R=W.parent/'repo';D=W/'delivery';sys.path.insert(0,str(W));from commit_records import commit,dirty_guard,enc,git,tree,blob

def read(n):return json.loads((W/n).read_bytes())
def save(n,x):(W/n).write_bytes(enc(x))
def main():
 assert not (W/'final-handoff-reader-commit.json').exists(),'Already closed; verify rather than republish'
 dirty_guard();now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 v=read('validation.json');p=read('published-package-receipt.json');h=read('delivery/online-exact-verification.json');b=read('browser-verification.json');q=read('delivery/full-check-result.json');edge=read('delivery/edge-status-production-verified.json');a=read('delivery/adv-release-published.json');u=read('delivery/production-upload.json');c=read('current-confirmed-machine-summary.json');cv=read('contributions-3321/verification.json');cs=read('contributions-3321/summary.json');cc=read('contributions-3321-patch-commit.json');cross=read('cross-repo-machine-summary.json');run=read('publisher-run.json');plan=read('repair-plan.json');rev=read('reader-commit.json')['commit'];accounting=read('context-and-alias-accounting.json')
 assert p['version']==3321 and p['status']=='published_and_anonymously_verified' and p['reader_commit']==rev and p['cn_patch_commit']==read('patch-commit.json')['commit']
 assert run['conclusion']=='success' and run['head_sha']==read('public-commit.json')['commit']
 assert v['complete_scenes_reviewed']==73 and v['new_complete_scenes']==71 and v['previous_complete_context_scenes']==2 and v['display_fields_reviewed']==4152 and v['new_reviewed_fields']==4044 and v['context_fields']==108
 assert v['body_fields_revised']==p['changed_chinese_fields']==2217 and p['changed_runtime_scripts']==70 and v['explicit_speaker_label_repairs']==v['restored_previously_empty_display_fields']==0
 assert v['new_complete_unchanged_scripts']==['510710-5_1DyhN']
 assert v['specialized_tests_passed']==23 and v['additional_missing_display_contract_tests']==17 and v['reader_txt_files']==20 and v['reader_txt_field_spans']==5650 and v['historical_full_section_baselines']==11
 assert h['source_revision']==rev and h['passed']==h['total'] and h['total']>=2245 and h['failed']==0 and h['authorized_196_all_covered']
 assert b['sourceRevision']==rev and b['passed'] and b['checks']==36 and edge['passed'] and edge['checks']==5
 assert q['source_revision']==rev and q['python_tests']==611 and q['python_skipped']==3 and q['python_failures']==0 and q['node_tests']==730 and q['node_failures']==0 and q['lint'] and q['typecheck'] and not q['source_or_test_code_modified_to_pass']
 assert u['canonical_commit']==rev and u['all_other_configurations_unchanged'] and a['release']['source_revision']==rev and a['release']['deployment']==u['canonical_url']
 assert c['confirmed_current_machine_scripts']==1079 and c['complete']==605 and c['remaining']==474 and c['pending_unindexed']==24
 assert cv['passed'] and cv['checks']==19 and cv['source_summary']==cs and cc['remote_verified'] and cc['ledger_sha256']==cv['ledger_sha256'] and cc['previous_snapshot_unchanged']
 assert cs['last_published_scenario_version']==3321 and cs['confirmed_ai_fully_reviewed']==605 and cs['completed_before_takeover']==48 and cs['completed_after_takeover']==557 and cs['legacy_unique_registered_ids']==498
 assert not cross['completed_scripts_with_player_body_differences'] and accounting['prior_proofs_preserved']==534 and accounting['new_unique_scripts']==71 and accounting['new_indexed_entries']==10 and accounting['changed_scripts']==70
 for repo,key in [('reader','reader_files'),('patch','runtime_files')]:
  git(repo,'fetch','origin','main');cur=tree(repo,'FETCH_HEAD');assert all(cur[x['path']]['sha']==x['after'] for x in plan[key])
  if repo=='reader':assert not any('/contributions/' in z or z.endswith('ai-only-census.json.gz') for z in cur)
  else:assert cur['docs/story-quality/contributions/ledger.json.gz']['sha']==blob((W/'contributions-3321/ledger.json.gz').read_bytes())
 ledger=read('current-confirmed-machine-ledger.json');rt=tree('reader','FETCH_HEAD');assert len(ledger)==1079 and all(rt[x['path']]['sha']==x['current_blob'] and rt[x['jp_path']]['sha']==x['jp_blob'] for x in ledger)
 for s in read('review-sources.json'):
  if s['already_complete_context_only'] or s['id']=='510710-5_1DyhN':assert rt[s['cn_path']]['sha']==s['cn_sha'] and not read('review/'+s['id']+'.edits.json')['edits']
 canonical={'repository':'HiiragiNemu/magireco-cn-patch','entry':'docs/story-quality/contributions/README.md','census':'docs/story-quality/20261002-ai-only-census.json.gz','commit':cc['commit'],'ledger_sha256':cc['ledger_sha256'],'rule':'CN patch only; no cumulative copies or cumulative ZIP contents in Reader/public'}
 state={'reader_source_commit':rev,'reader_data_commit':rev,'cn_patch_source_commit':p['cn_patch_commit'],'player_data_commit':p['cn_patch_commit'],'scenario_version':3321,'package':p['package'],'package_publication_run':run['id'],'reader_production_deployment':u['canonical_id'],'reader_site_uploaded':True,'reader_site_uploaded_for_active_batch':True,'adv_current_for_this_source_registered':True,'adv_registered_for_active_batch':True,'adv_record':a['release'],'game_device_verified':False};save('delivery-state.json',state)
 batch_accounting={k:z for k,z in accounting.items() if k!='prior_proofs_preserved'}
 core={'schema':1,'batch':'20261002-semantic-batch09-ai-only','verified_at':now,'translation':v,'delivery':state,'tests':q,'http':{k:z for k,z in h.items() if k!='results'},'browser':b,'edge_checks':edge,'package_receipt':p,'contribution_ledger_reference':canonical,'batch_accounting':batch_accounting,'unrelated_worktree_state_unchanged':True,'whole_corpus_complete':False,'device_gameplay_verified':False}
 full=core|{'confirmed_ai_counts':c,'cumulative_contributions':cs,'contribution_checks':cv,'cross_repo_summary':cross,'complete_accounting':accounting};save('final-receipt.json',full)
 nextq=read('next-ai-only-full-chapter-queue.json');nextid=nextq['queue'][0]['story_id'];nexttitle=nextq['queue'][0].get('title') or nextq['queue'][0].get('source_identity','');assert nextid not in {x['story_id'] for x in read('chapters.json')}
 headline=f'''# 3321 剧情校订交付回执

核验时间：{now}。开工前实际核对3320玩家两入口与Reader/ADV同源。本轮新修订独立发布3321，没有重发旧内容。

## 本轮校订

9个非重叠主话、73个独立片段、4152个正文字段完整对照日文。71个新完成片段／4044字段，另2个旧完成上下文片段／108字段只复读、不改动、不重计。70个片段修正2217个正文字段；510710-5全文准确，保留原字节，属于新完成复核但不是新改动片段。显示姓名标签、执行命令、演员身份、音频、新增显示事件均无改动。

覆盖510301《御魂的特训 月出里篇》全10节，5105《Mixed Summer！～梦幻的最佳镜头～》上下篇全20节，5106《Unknown Story～盛夏的魔法和明天的记忆～》四话全21节，5107《欢迎来到谣言水族馆～将回忆寄托在玉手箱中～》上下篇全22节。20份源TXT／网页配对文件完成5650处精确物理文本片段同步，11个历史正文基线逐整节核对。510601-04合辑同步，但重复引用21个片段，不另算独立剧情或贡献。

修正冰淇淋误作爱、泳圈误作浮点数、鼓手误作棍术，恢复拍摄分镜、排球配合、账号被冒用与真实行为的区别。Unknown Story中梦境、邀约记忆、真夏愿望与父母、UFO真伪的留白按原作顺序保留。水族馆篇纠正把不愿被遗忘错成求死、把费心照顾错成伤心、把关心和否定倒置等错误，保留人物对死亡、回忆与活过证明的不同理解。只修确认AI来源，不重译官方、确认人工或来源未明稿；不重分配原译者署名。

## 正式交付与验收

Reader数据main：`{rev}`；CN patch数据main：`{p['cn_patch_commit']}`。玩家latest与scenario-3321发布成功，工作流`{run['id']}`，GitHub与Cloudflare两条普通玩家版本入口均回传3321。Reader正式部署`{u['canonical_id']}`，ADV登记同一源码和部署。

玩家包{p['package']['size']}字节，SHA-256 `{p['package']['sha256']}`，MD5 `{p['package']['md5']}`。{p['unchanged_files']}个非目标文件逐字节未改；之前{p['previous_corrected_scripts']}个已发布修订中{p['previous_byte_identical']}个完全保留，{len(p['previous_exact_extensions'])}个仅叠加本轮有依据的正文修正。43V4、196授权中文、原工作树的已修改／未跟踪文件及暂存状态均保留。

23项文字拒绝测试、17项恢复边界测试、7项发布传输拒绝测试和73片段真实Reader解析通过。完整Python611项无失败、3项跳过；Node730项无失败；lint、typecheck通过。正式站{h['total']}项逐字节HTTP核验全通过，重试{h['retries']}；36项桌面／手机可见阅读检查含主话、合辑和旧回归，5项状态检查均通过。未改测试或运行源码来凑通过。未改L2D、AIO、APK、字体，游戏内逐幕动画尚未实机验收。

## 唯一累计台账与下一入口

累计贡献和完整已处理／待处理台账只在 `{canonical['repository']}:{canonical['entry']}`，本轮累计提交`{cc['commit']}`，19项独立核算通过。旧498个剧情ID、前AI贡献、已完成证据和旧版快照均保留；Reader与ProgettoMagius-1只保留本批证据及CN patch指针。

下一入口：`{nextid}`（{nexttitle}）。从CN patch刷新完整队列、三仓main、中日文blob和实际线上版本后继续，不重复发布3321。
'''
 fullmd=headline+f'''\n## CN patch核定累计数\n\n确认AI独立片段1079，已完整复核605，余474（包含24个未索引）。接手前48、接手后557。本轮71新完成，原534份完成证据逐项保留。Reader128个和客户端独有35个仍仅列来源调查，不擅自当作待重译。\n\n3301至3321发布实际改动按路径去重：{cs['published_unique_runtime_scripts_modified']}个片段，其中正文校订{cs['published_unique_runtime_scripts_with_body_correction']}个；不同正文字段地址{cs['published_unique_body_addresses_corrected']}。字段地址不是原创翻译句数。\n'''
 (W/'Reader_AI_3321_Delivery_20261002.md').write_text(fullmd,encoding='utf8');(W/'Reader_3321_Batch_Receipt.md').write_text(headline,encoding='utf8')
 progress=read('progress.json');progress.update(stage='delivered',closed_at=now,checkpoint='9主话73片段全文对照，71新完成/2旧上下文；70脚本2217正文修訂已交付3321、Reader与ADV，累计仅CN patch',active_sessions={},next=['从CN patch新队列继续确认AI整话，先核验中日文blob和线上版本','累计贡献和全量清单、恢复包仅CN patch','不要重复发布3321，不改官方/确认人工/来源未明稿']);save('progress.json',progress)
 safe=['collect.py','stage.py','decisions.py','record_raw.py','review_io.py','view_scripts.py','checkpoint.py','sync_text.py','exact_json.py','translation_rules.py','test_translation_rules.py','reader_check.cjs','reader_recovery_contract.cjs','test_reader_recovery.cjs','test_narrator_recovery.cjs','prepare_current_helpers.py','prepare_delivery.py','commit_sources.py','build_package.py','prepare_public.py','publish_scenario_3321.py','test_public_delivery_retry.py','prepare_build.py','run_full_qa.py','prepare_acceptance.py','browser_verify.cjs','accept_live.py','update_census.py','cross_repo_verify.py','queue_contract.py','generate_contributions.py','contribution_ledger.py','verify_contributions.py','commit_records.py','closeout.py','verify_final_state.py','release_after_build.py','progress.json','bases.json','baseline-census.json','review-sources.json','chapters.json','provenance.json','repair-plan.json','text-plan.json','historical-text-baselines.json','validation.json','reader-render-validation.json','missing-display-restoration.json','final-name-refinements.json','reader-commit.json','patch-commit.json','public-commit.json','publisher-run.json','published-package-receipt.json','post-package-version-checks.json','completed-machine-review-evidence.json','current-confirmed-machine-summary.json','cross-repo-machine-summary.json','next-ai-only-full-chapter-queue.json','Reader_AI_Full_Ledger_20261002.json.gz','delivery-state.json','final-receipt.json','Reader_AI_3321_Delivery_20261002.md','contributions-3321-patch-commit.json','context-and-alias-accounting.json','browser-targets.json','baseline-live-checks.json']
 safe+=sorted(f.name for f in W.glob('trusted-*.json'));safe+=sorted(f.name for f in W.glob('decisions-*.json'))
 dep=['build-steps.json','full-check-result.json','source-preservation-before-generation.json','source-preservation-after-generation.json','source-preservation-after-build.json','source-preservation-after-qa.json','online-exact-verification.json','online-exact-plan.json','edge-status-production-verified.json']
 archive=W/'20261002-ai-only-3321-recovery.zip';members=[]
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in safe:assert (W/n).is_file(),n;z.write(W/n,n);members.append(n)
  for n in dep:assert (D/n).is_file(),n;z.write(D/n,'delivery/'+n);members.append('delivery/'+n)
  for folder,pattern in [('review','*.edits.json'),('review','*.final.txt'),('review','*.aligned.json'),('contributions-3321','*')]:
   for f in sorted((W/folder).glob(pattern)):
    if f.is_file():z.write(f,f.relative_to(W).as_posix());members.append(f.relative_to(W).as_posix())
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 recovery={'repository':canonical['repository'],'path':'docs/story-quality/recovery/20261002-ai-only-3321.zip','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(members),'stored_in_reader':False,'stored_in_public':False};full['recovery']=recovery;save('recovery-metadata.json',recovery);save('final-receipt.json',full)
 pc=commit('patch',{'docs/story-quality/20261002-ai-only-batch09-published.md':fullmd.encode(),'docs/story-quality/20261002-ai-only-batch09-published.json':enc(full),recovery['path']:archive.read_bytes()},'final-handoff')
 root=f'''# Reader剧情质量接续入口\n\n更新：{now}\n\n本批9非重叠主话73片段4152字段全文对照，71新完成／2旧上下文分计，70脚本2217正文修订已发布3321。另1个新复核片段准确、未改字节。Reader数据`{rev}`，CN patch数据`{p['cn_patch_commit']}`，Reader正式部署`{u['canonical_id']}`，ADV同源。先读`docs/story-quality/20261002-ai-only-batch09-published.md`和`docs/story-quality/CONTINUATION_STATE.json`。不要重发3321。\n\n累计贡献、完整处理清单、含这些内容的恢复包只在CN patch：`{canonical['repository']}:{canonical['entry']}`；恢复包`{recovery['path']}`。Reader与发行仓只留单批证据及指针，不保存累计副本。前AI成果、旧498ID及旧快照持续保留。\n\n下一入口`{nextid}`（{nexttitle}）。刷新三仓main、线上版本和中日文blob后，仅审确认AI来源整话，不重译官方、确认人工或来源未明稿。保留43V4、196授权中文和并行脏树。既有main，不分支PR或强推；不改L2D/AIO/APK/字体。全项目未完成，实机动画未验收。\n\n工作区`{R}`，本批`{W}`，任务tsk_d2ffb230656927cb。AgentDock写入、执行、Git推送与Cloudflare部署均实际成功，不因单个只读接口误判整体权限。每个恢复断点和最终回复前更新交接。\n'''
 st=json.loads((R/'docs/story-quality/CONTINUATION_STATE.json').read_bytes());st.update(state,updated_at=now,checkpoint=progress['checkpoint'],active_batch=progress,task_id=progress['task_id'],project_status='long_term_in_progress_AI_only',pending=progress['next'],contribution_storage_policy='CN patch only',contribution_ledger=canonical,contribution_record_requirement=canonical,recovery_bundle=recovery,ai_only_scope={'canonical_repository':canonical['repository'],'entry':canonical['entry'],'census':canonical['census'],'unit':'unique runtime JSON fragment; cumulative counts only in CN patch'},delivery_receipt_commits={'reader_data':rev,'patch_data':p['cn_patch_commit'],'canonical_contributions':cc['commit'],'patch_closeout':pc});st['paths']['current_batch']=str(W)
 # Replace stale nested per-release acceptance from older handoffs as well as top-level source pointers.
 st['reader_exact_http']={k:z for k,z in h.items() if k!='results'};st['reader_browser']=b;st['reader_full_qa']=q;st['reader_edge_status']=edge
 st.setdefault('previous_batch_summaries',{})[progress['batch']]={'stage':'delivered','scenario_version':3321,'reader_source_commit':rev,'cn_patch_source_commit':p['cn_patch_commit'],'recovery_reference':recovery}
 cont=(R/'docs/story-quality/CONTINUATION.md').read_text(encoding='utf8');start='<!-- AI-ONLY-BATCH09-START -->';end='<!-- AI-ONLY-BATCH09-END -->';assert start in cont and end in cont;cont=cont[:cont.index(start)]+start+'\n'+root+'\n'+end+cont[cont.index(end)+len(end):]
 rc=commit('reader',{'STORY_QUALITY_HANDOFF.md':root.encode(),'docs/story-quality/CONTINUATION.md':cont.encode(),'docs/story-quality/CONTINUATION_STATE.json':enc(st),'docs/story-quality/20261002-ai-only-batch09.md':headline.encode(),'docs/story-quality/20261002-ai-only-batch09-published.md':headline.encode(),'docs/story-quality/20261002-ai-only-batch09-published.json':enc(core)},'final-handoff');dirty_guard()
 result={'reader':rc,'patch':pc,'contributions_only_patch':cc,'recovery_only_patch':recovery,'runtime_source_unchanged':True,'original_worktree_state_unchanged':True};save('final-handoff-commits.json',result)
 with (W/'Reader_AI_3321_Delivery_20261002.md').open('a',encoding='utf8') as f:f.write('\n最终交接提交：Reader `'+rc+'`；CN patch `'+pc+'`。\n恢复包只在CN patch：`'+recovery['path']+'`，'+str(recovery['files'])+'项文件，SHA256 `'+recovery['sha256']+'`。\n')
 print('FINAL_CN_PATCH_ONLY_HANDOFF_COMPLETE',json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
