"""Add71 source-bound full reviews, retaining534 prior proofs,2 old contexts and1 accurate unchanged script."""
from pathlib import Path
import json,gzip,datetime,copy,sys,unittest
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch08-ai-only-20261002';sys.path.insert(0,str(W));from commit_sources import git,tree
from queue_contract import refresh,ResumeQueueTests

def read(n):return json.loads((W/n).read_bytes())
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def save(n,x):(W/n).write_bytes(enc(x))
def main():
 old=read('baseline-census.json');rows=copy.deepcopy(old['scripts']);assert len(rows)==1079 and sum(x['complete'] for x in rows)==534
 sources={x['cn_path']:x for x in read('review-sources.json')};assert len(sources)==73
 new={p:x for p,x in sources.items() if not x['already_complete_context_only']};context=set(sources)-set(new);assert len(new)==71 and len(context)==2
 plan=read('repair-plan.json');changes={x['path']:x for x in plan['reader_files']};assert set(changes)<set(new) and len(changes)==70 and plan['changed_fields']==2217
 unchanged=set(new)-set(changes);assert [new[p]['id'] for p in unchanged]==['510710-5_1DyhN']
 revs={r:read(r+'-commit.json')['commit'] for r in ['reader','patch']};rt=tree('reader',revs['reader']);frozen=read('reader-tree.json')
 proof={x['path']:copy.deepcopy(x) for x in old['completed_evidence']};prior_proof=copy.deepcopy(proof);assert len(proof)==534
 now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 for row in rows:
  p=row['path'];assert frozen[p]==row['current_blob'] and rt[row['jp_path']]['sha']==row['jp_blob']
  assert rt[p]['sha']==(changes[p]['after'] if p in changes else row['current_blob'])
  if p in new:
   assert not row['complete'] and row['machine_output_pair_count']>0;s=new[p];d=read('review/'+s['id']+'.edits.json')
   assert d['reviewed_all_fields'] and d['source_cn_blob']==row['current_blob'] and d['source_jp_blob']==row['jp_blob'] and d['field_count']==s['cn_fields']
   if p in unchanged:assert not d['edits'] and rt[p]['sha']==d['source_cn_blob']
   row.update(current_blob=rt[p]['sha'],complete=True,status='machine_origin_full_review_complete')
   proof[p]={'path':p,'cn_blob':row['current_blob'],'jp_path':row['jp_path'],'jp_blob':row['jp_blob'],'evidence':{'batch':plan['batch'],'source_commit':revs['reader'],'report':'manifests/story_quality_semantic_batch09_ai_only_20261002_evidence.json.gz','script_id':s['id'],'full_fields':s['cn_fields'],'text_changed':p in changes}}
  if row['complete']:assert p in proof and proof[p]['cn_blob']==row['current_blob'] and proof[p]['jp_blob']==row['jp_blob']
 assert all(proof[p]==v for p,v in prior_proof.items()),'Do not rewrite or recount prior review evidence'
 assert all(p in proof for p in context)
 complete={x['path'] for x in rows if x['complete']};assert len(complete)==len(proof)==605
 summary=copy.deepcopy(old['summary']);summary.update(complete=605,remaining=474,source_revision=revs['reader'],new_complete_scripts=71,new_complete_chapters=9,new_reviewed_fields=4044,context_only_scripts=2,context_only_fields=108,full_read_fields_including_context=4152,new_complete_unchanged_scripts=1,changed_scripts_this_batch=70,verified_at=now)
 assert summary['pending_unindexed']==sum(not x['complete'] and not x['indexed'] for x in rows)==24
 entries=copy.deepcopy(old['indexed_entries']);selected_chapters={x['chapter_id'] for x in sources.values()};old_complete=sum(x['complete'] for x in entries);new_ids=[]
 for e in entries:
  was=e['complete'];done=set(e['done_paths'])|({p for p in e['paths'] if p in new})
  e.update(done_paths=[p for p in e['paths'] if p in done],complete=bool(e['paths']) and all(p in done for p in e['paths']))
  e['added_complete_this_batch']=not was and e['complete']
  if e['added_complete_this_batch']:new_ids.append(e['story_id'])
 extra=set(new_ids)-selected_chapters;assert selected_chapters<=set(new_ids) and extra=={'510601-04'}
 assert len(new_ids)==10 and sum(x['complete'] for x in entries)==old_complete+10
 counts={'indexed_candidate_entries':len(entries),'indexed_complete_entries':sum(x['complete'] for x in entries),'indexed_not_fully_complete_entries':sum(not x['complete'] for x in entries),'indexed_partial_entries':sum(bool(x['done_paths']) and not x['complete'] for x in entries),'new_complete_chapters':9,'new_full_review_scripts':71,'new_reviewed_fields':4044,'reread_context_scripts':2,'new_complete_unchanged_scripts':1,'changed_scripts':70,'derived_compilation_aliases_completed':sorted(extra),'new_complete_indexed_entries_including_aliases':10,'note':'510601-04 is a21script compilation alias. Count9primary chapters and71new complete scripts, not10independent chapters.70modified scripts excludes one newly reviewed accurate script.'}
 q=copy.deepcopy(old['next_full_chapter_queue']);q['source_revision']=revs['reader'];q['updated_at']=now;q=refresh(q,rows,rt)
 assert not set(new_ids)&{x['story_id'] for x in q['queue']};assert all(c['pending_scripts']>0 for c in q['next_complete_chapters'])
 tests=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ResumeQueueTests));assert tests.wasSuccessful() and tests.testsRun==7
 for n,obj in [('current-confirmed-machine-ledger.json',rows),('current-confirmed-machine-summary.json',summary),('completed-machine-review-evidence.json',list(proof.values())),('ai-candidate-ledger-after.json',entries),('completion.json',counts),('next-ai-only-full-chapter-queue.json',q)]:save(n,obj)
 bypath={x['path']:x for x in rows}
 for n in ['new-path-provenance-queue.json','machine-origin-script-ledger.json']:
  data=json.loads((O/n).read_bytes())
  if n=='machine-origin-script-ledger.json':
   for x in data:
    if x['path'] in bypath:
     y=bypath[x['path']];x.update(current_blob=y['current_blob'],complete=y['complete'],status=y['status'])
  save(n,data)
 old.update(source_revision=revs['reader'],patch_revision=revs['patch'],verified_at=now,summary=summary,completed_evidence=list(proof.values()),scripts=rows,indexed_entries=entries,next_full_chapter_queue=q)
 save('Reader_AI_Full_Ledger_20261002.json',old);(W/'Reader_AI_Full_Ledger_20261002.json.gz').write_bytes(gzip.compress(enc(old),mtime=0))
 save('context-and-alias-accounting.json',{'prior_proofs_preserved':534,'context_only_scripts':sorted(context),'new_unique_scripts':71,'changed_scripts':70,'new_complete_unchanged':sorted(unchanged),'new_primary_chapters':9,'new_indexed_entries':10,'derived_aliases':sorted(extra),'queue_tests':7})
 print('CONFIRMED_AI',json.dumps(summary,ensure_ascii=False),flush=True);print('INDEXED',json.dumps(counts,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
