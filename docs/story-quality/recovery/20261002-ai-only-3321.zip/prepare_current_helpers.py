"""Prepare source-pinned batch09 validators and delivery helpers. No publication here."""
from pathlib import Path
import json,re,ast,subprocess
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch08-ai-only-20261002';R=W.parent/'repo'
def read(n):return (O/n).read_text(encoding='utf8')
def save(n,s):
 if n.endswith('.py'):ast.parse(s)
 assert not (W/n).exists(),'Existing helper: inspect rather than overwrite '+n
 (W/n).write_text(s,encoding='utf8')
def ver(s):return s.replace('3319','__BASE__').replace('3320','3321').replace('__BASE__','3320').replace('semantic-batch08','semantic-batch09').replace('semantic_batch08','semantic_batch09').replace('AI-ONLY-BATCH08','AI-ONLY-BATCH09').replace('ai-only-batch08','ai-only-batch09')
def swap(s,a,b):assert a in s,a;return s.replace(a,b)
p=json.loads((W/'repair-plan.json').read_bytes());t=json.loads((W/'text-plan.json').read_bytes());source=json.loads((W/'review-sources.json').read_bytes())
assert len(source)==73 and len(p['reader_files'])==len(p['runtime_files'])==70 and p['reviewed_fields']==4152 and p['changed_fields']==2217
assert len(t['files'])==20 and t['physical_field_span_edits']==5650 and not t['holds'] and not t['missing']
context=[x for x in source if x['already_complete_context_only']];assert len(context)==2 and sum(x['cn_fields'] for x in context)==108
s=ver(read('prepare_delivery.py')).replace('==94','==73').replace('==91','==70').replace('==5341','==4152').replace('==2310','==2217').replace('==186','==108').replace('==18','==9').replace('len(context)==3','len(context)==2')
a=s.index(' anchors=');b=s.index(' for sid,terms in anchors.items():',a)
anchors={'510301-1':['五分之四','分数'],'510301-6':['新玛吉斯'],'510510-6_Hemql':['鼓手','海滨小店'],'510520-4_5XtSr':['相信你们'],'510520-10_5XtSr':['较真的样子'],'510602-3':['铁人三项'],'510602-5':['魔法！！好好吃棒'],'510603-3':['独自生活'],'510604-5':['冰红茶'],'510710-4_1DyhN':['双腿不能动'],'510710-11_1DyhN':['补充盐分和水分','小红花'],'510720-5_eP7q2':['既然死了就会被遗忘'],'510720-7_eP7q2':['活过的证明'],'510720-10_eP7q2':['还没到该打开的时候']}
s=s[:a]+' anchors='+repr(anchors)+'\n'+s[b:]
s=s.replace("'indexed_chapters_complete':18","'indexed_chapters_complete':9").replace("'scenes_full_read':94","'scenes_full_read':73").replace("'complete_scenes_reviewed':94","'complete_scenes_reviewed':73").replace("'new_complete_scenes':91","'new_complete_scenes':71").replace("'previous_complete_context_scenes':3","'previous_complete_context_scenes':2").replace("'new_reviewed_fields':5155","'new_reviewed_fields':4044").replace("'context_fields':186","'context_fields':108").replace("'display_fields_reviewed':5341","'display_fields_reviewed':4152").replace("'display_fields_revised':2310","'display_fields_revised':2217").replace("'actual_reader_parser_files':94","'actual_reader_parser_files':73")
s=swap(s," inputs=p['inputs']|t.get('inputs',{})"," unchanged_new=[x for x in source if not x['already_complete_context_only'] and x['cn_path'] not in changed]\n assert [x['id'] for x in unchanged_new]==['510710-5_1DyhN']\n for x in unchanged_new:\n  assert not decisions[x['id']]['edits'] and blob((W/'stage/reader'/x['cn_path']).read_bytes())==x['cn_sha']\n inputs=p['inputs']|t.get('inputs',{})")
s=swap(s," save('validation.json',v)"," v.update(changed_runtime_scripts=70,new_complete_unchanged_scripts=['510710-5_1DyhN'])\n save('validation.json',v)")
a=s.index(' report=f');b=s.index(" folder='manifests/",a)
s=s[:a]+''' report=f"""# Batch09 validated source evidence before3321

9 non-overlapping primary chapters;73 unique scripts and4152 display fields read in full against Japanese.71 newly completed scripts/4044 fields and2 previously-complete context scripts/108 fields.2217 body corrections in70 scripts. Newly completed510710-5 remains byte-identical because the inherited translation is accurate; it counts as a complete review, NOT a modified script. No speaker labels, new display events, executable commands, actor identities or audio changed.

Full event5103 Sudachi training,5105 Mixed Summer,5106 Unknown Story and5107 Aquarium.20 paired TXT files including510601-04 compilation;5650 exact physical spans and11 full-section historical baselines. Compilation aliases do not count as additional independent chapters or scripts.23 translation and17 recovery refusal tests plus73 actual Reader parser checks.43V4,196authorized Chinese sources and original unrelated dirty files preserved. Model-assisted proofreading does not reassign official/human authorship. No L2D/AIO/APK/font changes.

Cumulative contributions and full processed/pending inventories reside ONLY in HiiragiNemu/magireco-cn-patch. This source-validation evidence is not a publication receipt or gameplay verification.
"""
'''+s[b:]
a=s.index(" progress=read('progress.json')");s=s[:a]+" progress=read('progress.json');progress.update(stage='validated',validation=v,checkpoint='9整话73片段4152字段全文复核，71新完成/2旧上下文；70脚本2217正文修订与20TXT5650片段验证通过，待3321及Reader/ADV交付',next=['仅既有main提交新文字','3320基线发布3321并核验玩家入口','独立干净Reader构建部署与ADV登记','累计清单仅CN patch']);save('progress.json',progress);S.close();print('VALIDATED',json.dumps(v,ensure_ascii=False),flush=True)\nif __name__=='__main__':main()\n";save('prepare_delivery.py',s)
s=ver(read('commit_sources.py'));a=s.index("  message='");b=s.index('\n  commit=',a);s=s[:a]+"  message='fix(story): review9 AI chapters,71 new full scenes and2217 body corrections [stage-only] [skip ci]\\n\\n73 scripts/4152 fields read.2 prior complete contexts and1 newly reviewed accurate script remain byte-identical.70 runtime scripts corrected.20 TXT mirrors incl compilation synchronized. Preserve43V4/196authorized and all unrelated worktree edits.\\n'"+s[b:];save('commit_sources.py',s)
s=ver(read('build_package.py')).replace('len(specs)==91','len(specs)==70').replace('==2310','==2217').replace('>=731','>=822')
for a,b in [('changed_runtime_scripts=91','changed_runtime_scripts=70'),('full_scenes_read=94','full_scenes_read=73'),('reviewed_complete_scenes=94','reviewed_complete_scenes=73'),('new_complete_scenes=91','new_complete_scenes=71'),('previous_complete_context_scenes=3','previous_complete_context_scenes=2'),('new_reviewed_fields=5155','new_reviewed_fields=4044'),('context_fields=186','context_fields=108'),('complete_indexed_chapters=18','complete_indexed_chapters=9'),('reviewed_fields=5341','reviewed_fields=4152'),('changed_chinese_fields=2310','changed_chinese_fields=2217'),('body_fields_changed=2310','body_fields_changed=2217'),('reviewed_execution_identities_preserved=94','reviewed_execution_identities_preserved=73')]:s=swap(s,a,b)
s=s.replace('Ninety-four reads,91 new complete scenes,18 nonoverlapping chapters','73 full reads,71 new completions,70 modified scripts,9 nonoverlapping chapters');save('build_package.py',s)
s=ver(read('prepare_public.py')).replace('==2310','==2217')
for a,b in [("'changed_runtime_scripts':91","'changed_runtime_scripts':70"),("'full_scenes_read':94","'full_scenes_read':73"),("'complete_scenes_reviewed':94","'complete_scenes_reviewed':73"),("'new_complete_scenes':91","'new_complete_scenes':71"),("'previous_complete_context_scenes':3","'previous_complete_context_scenes':2"),("'complete_indexed_chapters':18","'complete_indexed_chapters':9"),("'reviewed_fields':5341","'reviewed_fields':4152"),("'changed_fields':2310","'changed_fields':2217"),("'body_fields_changed':2310","'body_fields_changed':2217")]:s=swap(s,a,b)
s=s.replace('eighteen','nine').replace('18整话91新增脚本的2310','9整话71新完成脚本的2217');save('prepare_public.py',s)
s=ver(read('publish_scenario_3320.py')).replace("plan['changed_runtime_scripts']==91","plan['changed_runtime_scripts']==70").replace("plan['reviewed_fields']==5341","plan['reviewed_fields']==4152").replace("plan['changed_fields']==2310","plan['changed_fields']==2217").replace("plan['complete_scenes_reviewed']==94","plan['complete_scenes_reviewed']==73")
a=s.index("'body':'18 non-overlapping");b=s.index("','draft':False",a)
s=s[:a]+"'body':'9 full primary chapters;73 complete Japanese comparisons/4152 fields.71 new complete scripts,2 previously-complete context scripts unchanged;1 newly reviewed accurate script unchanged.70 runtime scripts with2217 body corrections.20 paired exports incl510601-04 compilation synchronized exactly. No duplicate contribution counting. No new display events,labels,commands,actors,audio or execution layout.43V4/196authorized sources preserved. Cumulative inventory only in CN patch. Proofreading is not original human authorship; gameplay not verified."+s[b:];s=s.replace('eighteen complete','nine complete');save('publish_scenario_3321.py',s)
for n in ['prepare_build.py','run_full_qa.py','inspect_publisher.py','cross_repo_verify.py','queue_contract.py','release_after_build.py','verify_final_state.py','commit_records.py','generate_contributions.py']:
 s=ver(read(n)) if n not in ['cross_repo_verify.py','queue_contract.py','run_full_qa.py'] else read(n)
 if n=='inspect_publisher.py':s=s.replace('==2310','==2217').replace('==94','==73')
 if n in ['commit_records.py','generate_contributions.py']:s=s.replace('==534','==605').replace('==545','==474').replace('==486','==557')
 if n=='release_after_build.py':s=s[:s.index("run('final-closeout'")]+"print('READER_PRODUCTION_AND_ADV_VERIFIED_CLOSEOUT_PENDING',flush=True)\n"
 save(n,s)
# Publisher retry tests bind to this version; no production writes.
f=W/'test_public_delivery_retry.py';s=f.read_text(encoding='utf8');assert 'publish_scenario_3321' in s
for target,path in [('contribution_ledger.py','tools/story_quality_contributions.py'),('verify_contributions.py','tools/verify_story_quality_contributions.py')]:
 s=subprocess.check_output(['git','--git-dir=A:/StoryQuality-20260930-1739/patch.git','show','FETCH_HEAD:'+path],cwd=R).decode('utf8');save(target,s)
print('PREPARED_BATCH09_HELPERS_NO_PUBLISH',flush=True)
