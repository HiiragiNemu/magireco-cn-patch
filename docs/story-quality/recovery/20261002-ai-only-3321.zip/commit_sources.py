from pathlib import Path
import subprocess,json,os,datetime,sys
W=Path(__file__).resolve().parent;R=W.parent/'repo';P='A:/StoryQuality-20260930-1739/patch.git';sys.path.insert(0,str(W.parent/'control-authority-20260930'))
from exact_json import blob

def git(repo,*args,data=None,env=None):
 result=subprocess.run(['git',*(['--git-dir='+P] if repo=='patch' else []),*args],cwd=R,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=90)
 if result.returncode:raise RuntimeError(result.stderr.decode(errors='replace'))
 return result.stdout

def tree(repo,ref):
 result={}
 for row in git(repo,'ls-tree','-r','-z',ref).split(b'\0'):
  if row:
   meta,p=row.split(b'\t',1);mode,kind,sha=meta.decode().split()
   if kind=='blob':result[p.decode()]={'sha':sha,'mode':mode}
 return result

def main():
 repo=sys.argv[1];root=W/'stage'/repo;plan=json.loads((W/'repair-plan.json').read_bytes());baseline=json.loads((W/(repo+'-tree.json')).read_bytes())
 inputs=json.loads((W/'reader-inputs.json').read_bytes()) if repo=='reader' else {s['path']:s['before'] for s in plan['runtime_files']}
 if repo=='patch':
  reader=json.loads((W/'reader-commit.json').read_bytes())['commit'];p=root/'manifests/story_quality_semantic_batch09_ai_only_20261002.json';obj=json.loads(p.read_bytes());obj['reader_commit']=reader;p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
 payload={f.relative_to(root).as_posix():f.read_bytes() for f in root.rglob('*') if f.is_file() and blob(f.read_bytes())!=baseline.get(f.relative_to(root).as_posix())};assert payload and not any(x.endswith('.pyc') for x in payload)
 assert not any('/contributions/' in x or 'ai-only-census' in x for x in payload)
 for attempt in range(4):
  git(repo,'fetch','origin','main');head=git(repo,'rev-parse','FETCH_HEAD').decode().strip();current=tree(repo,head)
  for p,sha in inputs.items():assert current.get(p,{}).get('sha')==sha,('Reviewed source changed',p)
  for p in payload:assert current.get(p,{}).get('sha')==baseline.get(p),('Concurrent target change',p)
  env=os.environ.copy()|{'GIT_INDEX_FILE':str(W/(repo+'-index-'+datetime.datetime.now().strftime('%H%M%S%f')))};git(repo,'read-tree',head,env=env);rows=[]
  for path,data in payload.items():
   sha=git(repo,'hash-object','-w','--stdin',data=data).decode().strip();assert sha==blob(data);rows.append(('100644 '+sha+'\t'+path+'\0').encode())
  git(repo,'update-index','-z','--index-info',data=b''.join(rows),env=env);newtree=git(repo,'write-tree',env=env).decode().strip();env|={'GIT_AUTHOR_NAME':'HiiragiNemu','GIT_AUTHOR_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com','GIT_COMMITTER_NAME':'HiiragiNemu','GIT_COMMITTER_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com'}
  message='fix(story): review9 AI chapters,71 new full scenes and2217 body corrections [stage-only] [skip ci]\n\n73 scripts/4152 fields read.2 prior complete contexts and1 newly reviewed accurate script remain byte-identical.70 runtime scripts corrected.20 TXT mirrors incl compilation synchronized. Preserve43V4/196authorized and all unrelated worktree edits.\n'
  commit=git(repo,'commit-tree',newtree,'-p',head,data=message.encode(),env=env).decode().strip();result=tree(repo,commit)
  assert all(result[p]['sha']==blob(data) for p,data in payload.items());assert all(result[p]==v for p,v in current.items() if p not in payload)
  try:git(repo,'push','origin',commit+':refs/heads/main')
  except RuntimeError:
   if attempt==3:raise
   continue
  git(repo,'fetch','origin','main');remote=tree(repo,'FETCH_HEAD');assert all(remote[p]['sha']==blob(data) for p,data in payload.items())
  if repo=='reader':git(repo,'merge','--ff-only',commit)
  record={'repository':repo,'parent':head,'commit':commit,'files':len(payload),'remote_rechecked':True,'non_target_content_preserved':True};(W/(repo+'-commit.json')).write_text(json.dumps(record,indent=2),encoding='utf-8');print('COMMITTED',record,flush=True);return
 raise RuntimeError('No stable main')
if __name__=='__main__':main()
