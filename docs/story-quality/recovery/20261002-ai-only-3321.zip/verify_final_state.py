"""Final read-only independent check of release pointers and sole ledger location."""
from pathlib import Path
import json,subprocess,hashlib,urllib.request,datetime,gzip,zipfile,io,sys
W=Path(__file__).resolve().parent;R=W.parent/'repo';sys.path.insert(0,str(W));from commit_records import dirty_guard

def git(repo,*a):return subprocess.check_output(['git',*(['--git-dir=A:/StoryQuality-20260930-1739/'+repo+'.git'] if repo!='reader' else []),*a],cwd=R,timeout=180)
def enc(x):return(json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def main():
 final=json.loads((W/'final-handoff-commits.json').read_bytes());receipt=json.loads((W/'published-package-receipt.json').read_bytes());rev=receipt['reader_commit'];out={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'heads':{},'public':[],'cumulative_storage':{},'reader_archives':[]}
 for repo in ['reader','patch','public']:
  git(repo,'fetch','origin','main');h=git(repo,'rev-parse','FETCH_HEAD').decode().strip();out['heads'][repo]=h;t={}
  for row in git(repo,'ls-tree','-rz',h).split(b'\0'):
   if row:m,p=row.split(b'\t');t[p.decode()]=m.decode().split()[2]
  cumulative=[p for p in t if p.startswith('docs/story-quality/contributions/') or p.endswith('ai-only-census.json.gz')]
  out['cumulative_storage'][repo]=cumulative
  if repo!='patch':assert not cumulative,(repo,cumulative)
  else:
   assert 'docs/story-quality/contributions/ledger.json.gz' in t
   for n in ['ledger.json.gz','summary.json','processed-runtime-scripts.tsv','pending-ai-scripts.tsv','full-reviewed-ai-scripts.tsv','legacy-registered-stories.tsv']:
    assert git(repo,'show',h+':docs/story-quality/contributions/'+n)==(W/'contributions-3321'/n).read_bytes(),n
   raw=git(repo,'show',h+':'+final['recovery_only_patch']['path']);assert hashlib.sha256(raw).hexdigest()==final['recovery_only_patch']['sha256']
   with zipfile.ZipFile(io.BytesIO(raw)) as z:assert z.testzip() is None and len(z.namelist())==final['recovery_only_patch']['files']
  if repo=='reader':
   for p in t:
    if p.startswith('docs/story-quality/recovery/') and p.endswith('.zip'):
     with zipfile.ZipFile(io.BytesIO(git(repo,'show',h+':'+p))) as z:
      bad=[n for n in z.namelist() if 'contribution' in n.lower() or 'Full_Ledger' in n or 'confirmed-machine-ledger' in n]
     assert not bad,(p,bad);out['reader_archives'].append({'path':p,'no_cumulative_copy':True})
 for url in ['https://magireco-personal-release.pages.dev/version_scenario.json','https://github.com/HiiragiNemu/ProgettoMagius-1/releases/download/latest/version_scenario.json','https://magireader.pages.dev/adv-release-build.json','https://magireader.pages.dev/api/adv/release']:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'Accept-Encoding':'identity','User-Agent':'Final-3321-Ordinary-Player-Verification'}),timeout=90) as r:
   obj=json.load(r);assert r.status==200
  if 'version_scenario' in url:assert obj=={'version':3321,'size':receipt['package']['size'],'md5':receipt['package']['md5']}
  else:assert obj['source_revision']==rev
  out['public'].append({'url':url,'status':200,'data':obj})
 dirty_guard();out['original_worktree_unchanged']=True;out['passed']=True;(W/'final-independent-verification.json').write_bytes(enc(out));print('FINAL_INDEPENDENT_VERIFICATION',json.dumps(out,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
