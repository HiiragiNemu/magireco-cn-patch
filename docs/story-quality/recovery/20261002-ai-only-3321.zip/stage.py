"""Stage only explicitly read/reviewed scene edits; preserve JSON bytes outside scalars."""
from pathlib import Path
import sys,json,re,hashlib
W=Path(__file__).resolve().parent;ROOT=W.parent;R=ROOT/'repo'
sys.path[:0]=[str(ROOT/'control-authority-20260930'),str(ROOT/'severe-5109-20261001')]
from exact_json import apply,blob
from control_safety import no_added_undefined_references
from collect_review import raw,fields,shape,CTRL,NAME
from copy import deepcopy
from stage_and_validate import expanded,canonical_tags

def save(name,obj):
 p=W/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def main():
 sources=json.loads((W/'review-sources.json').read_bytes());delivery=json.loads((W/'baseline-delivery.json').read_bytes())
 plan={'schema':1,'batch':'20261002-semantic-batch09-ai-only','base_version':delivery['scenario_version'],'target_version':delivery['scenario_version']+1,'base_package_sha256':delivery['package']['sha256'],'bases':json.loads((W/'bases.json').read_bytes()),'reader_files':[],'runtime_files':[],'reviewed_stories':[],'inputs':{},'execution_changes':0,'whole_corpus_review_complete':False,'review_method':'model_assisted_full_scene_Japanese_comparison_not_official_human_source'}
 for s in sources:
  full=W/'review'/(s['id']+'.revised.txt');sparse=W/'review'/(s['id']+'.edits.json')
  if not full.exists() and not sparse.exists():continue
  assert not (full.exists() and sparse.exists()),s['id']
  assert s['reader_player_bytes_equal'],s['id']
  aligned=json.loads((W/'review'/(s['id']+'.aligned.json')).read_bytes())
  decision={}
  note='逐句对照全篇原文校订；未变行经审读保留。'
  if full.exists():lines=full.read_text(encoding='utf-8').splitlines()
  else:
   decision=json.loads(sparse.read_bytes());assert decision['reviewed_all_fields'] is True;note=decision['review_note'];lines=[CTRL.sub('§',a['cn']) for a in aligned]
   for n,value in decision['edits'].items():assert 0<=int(n)<len(lines);lines[int(n)]=value
  assert decision.get('source_cn_blob',s['cn_sha'])==s['cn_sha'] and decision.get('source_jp_blob',s['jp_sha'])==s['jp_sha']
  manual=decision.get('manual_jp_correspondence')
  if manual:
   allowed={'510088-2':('ebe9a2b02852249cbad736767c13ba84093702bc','69f146861a5ca5d3f46d0e390a19a27c8acd13e6'),'510089-2':('f17491ac210fb622ad874343de000fbe66e529f1','b60570c88bfbb503cbafc7b7deaa6ca997d975c0'),'510089-3':('8d0c8519cbdd6e1c5f637e425f9afb86e19a0b65','dccf0a58b063e5ed855f926e185d7187a6af1282')}
   assert allowed.get(s['id'])==(s['cn_sha'],s['jp_sha'])
   jf=json.loads((W/'review'/(s['id']+'.jp-fields.json')).read_bytes())
   assert len(manual)==len(aligned) and set(i for ids in manual for i in ids)==set(range(len(jf)))
   for row,ids in zip(aligned,manual):
    row['jp_correspondence']=[{'ordinal':i,**jf[i]} for i in ids]
    row['jp']=' | '.join(jf[i]['text'] for i in ids)
  else:
   assert s['same_field_addresses'] and s['nontext_diff_count']==0,s['id']
  assert len(lines)==len(aligned),(s['id'],len(lines),len(aligned))
  operations=[];records=[]
  for row,line in zip(aligned,lines):
   try:new=expanded(row['cn'],line)
   except Exception as e:raise ValueError((s['id'],row['ordinal'],str(e))) from e
   assert canonical_tags(new)==canonical_tags(row['cn']),(s['id'],row['ordinal'],'CN tag change')
   if new!=row['cn']:
    assert new.strip() and '\ufffd' not in new and '§' not in new
    operations.append([row['address'],row['cn'],new]);records.append({'ordinal':row['ordinal'],'address':row['address'],'speaker':row['cn_name'],'jp':row['jp'],'before':row['cn'],'after':new})
  body_changed=len(operations)
  original=raw('reader',s['cn_sha']);cnobj=json.loads(original);jpobj=json.loads(raw('reader',s['jp_sha']))
  for e in decision.get('name_edits',[]):
   a=e['address'];assert a[-1] in NAME
   jnode=jpobj;cnode=cnobj
   for key in a:jnode=jnode[key];cnode=cnode[key]
   assert jnode==e['jp'] and cnode==e['before'] and e['after']!=e['before']
   assert not any(c in e['after'] for c in '\n\r[]')
   operations.append([a,e['before'],e['after']]);records.append({'address':a,'jp':e['jp'],'before':e['before'],'after':e['after'],'field_kind':'speaker_label','reason':e['reason']})
  candidate=apply(original,operations);newobj=json.loads(candidate)
  names_restored=deepcopy(newobj)
  for e in decision.get('name_edits',[]):
   node=names_restored
   for key in e['address'][:-1]:node=node[key]
   node[e['address'][-1]]=e['before']
  assert shape(cnobj)==shape(newobj)
  assert [(f['address'],f['name'],f['actor_id']) for f in fields(cnobj)]==[(f['address'],f['name'],f['actor_id']) for f in fields(names_restored)]
  no_added_undefined_references(original,candidate)
  plan['inputs'].update({s['cn_path']:s['cn_sha'],s['jp_path']:s['jp_sha']})
  for repo,path,sha in [('reader',s['cn_path'],s['cn_sha']),('patch',s['patch_path'],s['patch_sha'])]:
   b=raw(repo,sha);assert b==original
   for folder,data in [('originals',b),('stage',candidate)]:
    p=W/folder/repo/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
   if operations:plan['reader_files' if repo=='reader' else 'runtime_files'].append({'path':path,'before':sha,'after':blob(candidate),'operations':operations,'jp_path':s['jp_path'],'jp_sha':s['jp_sha'],'reader_paths':[s['cn_path']]})
  (W/'review'/(s['id']+'.final.txt')).write_text('\n'.join(lines)+'\n',encoding='utf-8')
  plan['reviewed_stories'].append(s|{'fields_reviewed':len(aligned),'fields_changed':len(operations),'body_fields_changed':body_changed,'name_fields_changed':len(operations)-body_changed,'review_note':note,'semantic_complete':decision.get('semantic_complete',True),'manual_jp_correspondence':manual,'unresolved':decision.get('unresolved',[]),'aligned_review':records})
  print(s['id'],'reviewed',len(aligned),'changed',len(operations),flush=True)
 plan['reviewed_fields']=sum(s['fields_reviewed'] for s in plan['reviewed_stories']);plan['changed_fields']=sum(s['fields_changed'] for s in plan['reviewed_stories'])
 plan['completed_review_stories']=[x['id'] for x in plan['reviewed_stories'] if x['semantic_complete']]
 plan['pending_adjudication_stories']=[x['id'] for x in plan['reviewed_stories'] if not x['semantic_complete']]
 save('repair-plan.json',plan)
 progress=json.loads((W/'progress.json').read_bytes());progress.update(stage='review',reviewed=[{'id':s['id'],'fields':s['fields_reviewed'],'changed':s['fields_changed']} for s in plan['reviewed_stories']],reviewed_fields=plan['reviewed_fields'],changed_fields=plan['changed_fields'],target_version=plan['target_version'],checkpoint=f"已完整审读{len(plan['reviewed_stories'])}篇{plan['reviewed_fields']}字段，其中{len(plan['completed_review_stories'])}篇可结案、{len(plan['pending_adjudication_stories'])}篇保留来源裁决；精确暂存{plan['changed_fields']}处校订；结构/说话人/命令保持，尚未提交运行稿或发布")
 save('progress.json',progress);print('TOTAL',len(plan['reviewed_stories']),plan['reviewed_fields'],plan['changed_fields'])
if __name__=='__main__':main()
