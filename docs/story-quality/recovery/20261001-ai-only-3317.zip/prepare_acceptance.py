"""Prepare publication acceptance against the exact new Reader snapshot."""
from pathlib import Path
import json,ast
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch04-ai-only-20261001';D=W/'delivery'
rev=json.loads((W/'reader-commit.json').read_bytes())['commit'];assert (D/'source-revision.txt').read_text().strip()==rev
p=D/'deploy_verified_snapshot.py';s=p.read_text(encoding='utf8');old="assert changed and set(changed)<=allowed,'Non-handoff source changed after build'";assert old in s
s=s.replace(old,"assert changed and all(p=='STORY_QUALITY_HANDOFF.md' or p.startswith('docs/story-quality/') for p in changed),'Non-handoff source changed after build'");ast.parse(s);p.write_text(s,encoding='utf8')
old=json.loads((O/'delivery/online-verification-targets.json').read_bytes());plan=json.loads((W/'repair-plan.json').read_bytes());text=json.loads((W/'text-plan.json').read_bytes())
old.update(source_revision=rev,changed_paths=sorted(set(old['changed_paths'])|{x['path'] for x in plan['reader_files']}),committed_txt_paths=sorted(set(old['committed_txt_paths'])|{x['path'] for x in text['files'] if x['path'].startswith('website/public/')}))
(D/'online-verification-targets.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
s=(O/'browser_verify.cjs').read_text(encoding='utf8');a=s.index('const targets=');b=s.index('.map(([sid,text])',a)
targets=[['310462-2','老爹当时想宰了他'],['310463-4','可婚事不就是这样的吗'],['310473-4','搭讪'],['310493-3','一个人行动了'],['310502-2','伊斯维克遭到袭击时'],['310512-3','她就被“魔”附身了'],['310521-2','现在叫也'],['310523-3','舔舔'],['310533-3','在银或锡上贴合了玻璃的'],['311022-4','被放鸽子了'],['311023-3','只责罚我一个人'],['311023-4','一起创造回忆']]
s=s[:a]+'const targets='+json.dumps(targets,ensure_ascii=False)+s[b:];s=s.replace('results.length===16','results.length===24');(W/'browser_verify.cjs').write_text(s,encoding='utf8')
print('ACCEPTANCE_READY',len(targets)*2,'browser checks',len(old['changed_paths']),'source targets',len(old['committed_txt_paths']),'web texts',flush=True)
