"""Read one current publisher state; do not rerun or mutate releases."""
from pathlib import Path
import json,sys,base64,subprocess,datetime
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W.parent));from closeout_reader import api
repo='HiiragiNemu/ProgettoMagius-1';expected=json.loads((W/'public-commit.json').read_bytes())['commit']
runs=api(repo,'actions/workflows/publish-story-quality-3317.yml/runs?per_page=10')['workflow_runs'];matches=[r for r in runs if r['head_sha']==expected];assert matches,'No matching source-pinned workflow run'
r=matches[0];brief={k:r.get(k) for k in ['id','status','conclusion','head_sha','created_at','html_url']};(W/'publisher-run.json').write_text(json.dumps(brief,indent=2),encoding='utf8');print('PUBLISHER',json.dumps(brief),flush=True)
jobs=api(repo,'actions/runs/'+str(r['id'])+'/jobs')['jobs'];summary=[{'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'steps':[{k:x.get(k) for k in ['name','status','conclusion','number']} for x in j['steps']]} for j in jobs];(W/'publisher-jobs.json').write_text(json.dumps(summary,indent=2),encoding='utf8');print('JOBS',json.dumps(summary),flush=True)
if r['status']=='completed':
 assert r['conclusion']=='success','Inspect matching publisher logs before any action'
 b=api(repo,'contents/story-quality/releases/3317.json?ref=main');p=json.loads(base64.b64decode(b['content']));assert p['version']==3317 and p['changed_chinese_fields']==720 and p['reviewed_complete_scenes']==97
 assert p['reader_commit']==json.loads((W/'reader-commit.json').read_bytes())['commit'] and p['cn_patch_commit']==json.loads((W/'patch-commit.json').read_bytes())['commit']
 assert p['status']=='published_and_anonymously_verified';(W/'published-package-receipt.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 results=[]
 for u in ['https://magireco-personal-release.pages.dev/version_scenario.json','https://github.com/HiiragiNemu/ProgettoMagius-1/releases/download/latest/version_scenario.json']:
  z=subprocess.run(['curl.exe','-fsSL','--retry','2','--max-time','40',u],capture_output=True,timeout=140);assert z.returncode==0,(u,z.stderr.decode(errors='replace'))
  data=json.loads(z.stdout);assert data=={'version':3317,'size':p['package']['size'],'md5':p['package']['md5']},(u,data)
  results.append({'url':u,'status':200,'data':data,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 (W/'post-package-version-checks.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('PUBLISHED_VERIFIED',json.dumps({k:v for k,v in p.items() if k!='files'},ensure_ascii=False),flush=True)
