"""Validate source-bound semantic review and reversible runtime/text edits before publication."""
from pathlib import Path
import sys,json,gzip,hashlib,subprocess,datetime
W=Path(__file__).resolve().parent;ROOT=W.parent;R=ROOT/'repo'
sys.path[:0]=[str(W),str(ROOT/'semantic-batch03-20261001'),str(ROOT/'control-authority-20260930'),str(ROOT/'severe-5109-20261001')]
from exact_json import apply,blob
from translation_rules import validate,execution_tokens,color_types
from collect_review import fields
from census import Store
READER_STORE=Store()
def raw(repo,sha):
 assert repo=='reader'
 return READER_STORE.get(sha)

def load(n):return json.loads((W/n).read_bytes())
def dump(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def save(n,x):p=W/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(dump(x))
def main():
 p=load('repair-plan.json');t=load('text-plan.json');rt=load('reader-tree.json');pt=load('patch-tree.json');render=load('reader-render-validation.json')
 assert len(p['reviewed_stories'])==97 and len(p['completed_review_stories'])==97 and p['pending_adjudication_stories']==[]
 assert len(p['reader_files'])==len(p['runtime_files'])==61 and p['reviewed_fields']==5124 and p['changed_fields']==720
 assert render['passed'] and render['actualParser'] and len(render['files'])==61 and not t['holds'] and not t['missing']
 tests=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(W),'-p','test_translation_rules.py','-v'],cwd=W,capture_output=True,text=True,encoding='utf-8');(W/'translation-tests.log').write_text(tests.stdout+tests.stderr,encoding='utf-8');assert tests.returncode==0 and 'Ran 23 tests' in tests.stderr
 decision={x['id']:load('review/'+x['id']+'.edits.json') for x in p['reviewed_stories']};placeholders=0
 for s in p['reader_files']:
  a=(W/'originals/reader'/s['path']).read_bytes();b=(W/'stage/reader'/s['path']).read_bytes();ops=s['operations'];d=decision[Path(s['path']).stem]
  authorized_names=[[x['address'],x['before'],x['after']] for x in d.get('name_edits',[])]
  assert blob(a)==s['before'] and blob(b)==s['after'];validate(a,b,ops,allowed_name_operations=authorized_names);assert apply(b,[[at,new,old] for at,old,new in ops])==a
  af=fields(json.loads(a));bf=fields(json.loads(b));assert len(af)==len(bf)
  for old,new in zip(af,bf):
   assert old['text'].count('userName')==new['text'].count('userName');placeholders+=old['text'].count('userName')
   assert execution_tokens(old['text'])==execution_tokens(new['text']) and color_types(old['text'])==color_types(new['text'])
 for s in t['files']:
  a=raw('reader',s['before']);b=(W/'stage/reader'/s['path']).read_bytes();assert blob(b)==s['after'];bom=b'\xef\xbb\xbf' if b.startswith(b'\xef\xbb\xbf') else b'';undo=b[len(bom):].decode()
  for e in sorted(s['edits'],key=lambda x:x['after_start'],reverse=True):
   assert undo[e['after_start']:e['after_end']]==e['after_text'];undo=undo[:e['after_start']]+e['before_text']+undo[e['after_end']:]
  assert bom+undo.encode()==a
 authorized=json.loads((R/'docs/reader-availability-local-20260929.json').read_bytes())['protected_source_failure']['paths'];assert len(authorized)==196
 changed={x['path'] for x in p['reader_files']}|{x['path'] for x in t['files']};assert not set(authorized)&changed
 for path in authorized:assert blob((R/path).read_bytes())==rt[path],path
 v4=json.loads((R/'manifests/authoritative_scenario_runtime_repairs.v1.json').read_bytes())['entries'];assert len(v4)==43;protected={}
 for x in v4:
  path=x['target_path'];assert path not in changed and blob((R/path).read_bytes())==rt[path]
  peers=[z for z in pt if z.startswith('madomagi/resource/scenario/json/adv/') and Path(z).name==Path(path).name];assert len(peers)==1;protected[peers[0]]=pt[peers[0]]
 assert not set(protected)&{x['path'] for x in p['runtime_files']}
 anchors={'310462-2':['老爹当时想宰了他'],'310462-4':['好痛'],'310473-4':['搭讪','自己收到的温柔'],'310512-3':['她就被“魔”附身了'],'310521-2':['现在叫也'],'310523-3':['舔舔'],'310533-3':['在银或锡上貼合了玻璃的'.replace('貼','贴')],'311021-3':['原来是这样'],'311022-4':['被放鸽子了'],'311023-3':['只责罚我一个人'],'311023-4':['一起创造回忆']}
 for sid,terms in anchors.items():
  text=(W/'review'/(sid+'.final.txt')).read_text(encoding='utf-8').replace('@','')
  for term in terms:assert term in text,(sid,term)
 for path,h in load('dirty-tracked-hashes.json').items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==h,path
 inputs=p['inputs']|t.get('inputs',{})
 for path in authorized:inputs[path]=rt[path]
 for x in v4:inputs[x['target_path']]=rt[x['target_path']]
 for path in ['docs/reader-availability-local-20260929.json','manifests/authoritative_scenario_runtime_repairs.v1.json']:inputs[path]=rt[path]
 save('reader-inputs.json',inputs);save('protected-v4.json',protected)
 now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')
 v={'schema':2,'batch':p['batch'],'validated_at':now,'indexed_chapters_complete':24,'scenes_full_read':97,'complete_scenes_reviewed':97,'pending_source_adjudication':[],'display_fields_reviewed':5124,'display_fields_revised':720,'body_fields_revised':720,'explicit_speaker_label_repairs':0,'display_only':True,'exact_reverse_to_original_bytes':True,'nontext_structure_actor_identity_and_audio_unchanged':True,'AI_import_source_verified':True,'executable_tags_and_highlight_types_unchanged':True,'player_name_placeholders_preserved':placeholders,'actual_reader_parser_files':61,'actual_reader_events_and_audio_metadata_unchanged':True,'specialized_tests_passed':23,'reader_txt_files':len(t['files']),'reader_txt_field_spans':t['physical_field_span_edits'],'historical_full_section_baselines':len(load('historical-text-baselines.json')),'multiline_artifact_spans':t['multiline_artifact_spans'],'txt_missing_fields':0,'txt_alignment_holds':0,'protected_v4_unchanged':43,'protected_authorized_cn_unchanged':196,'unrelated_dirty_paths_unchanged':True,'review_method':p['review_method'],'official_or_human_provenance_not_asserted':True,'published':False,'whole_corpus_complete':False,'device_gameplay_verified':False}
 save('validation.json',v)
 evidence={'validation':v,'plan':p,'text_plan':t,'historical_baselines':load('historical-text-baselines.json'),'decisions':decision,'provenance':load('provenance.json'),'chapters':load('chapters.json'),'export_preservation_exception':[]}
 report="# 20261001 AI-only semantic batch05: validated source changes\n\n24 complete indexed chapters / 97 independent runtime scripts / 5124 body fields were fully compared to Japanese. 720 body fields were corrected in 61 scripts; 36 fully reviewed scripts remain byte-identical. Zero speaker-label, actor, audio, layout or runtime-command changes. All targets had current-blob-bound evidence in the 1079 confirmed AI corpus before review. Human/official and unverified-source-only stories are excluded.\n\nChapters: Chizuru 310461-463; Kuro 310471-473; Olga 310491-493; Gunhild 310501-503; Heruka 310511-513; Toyo 310521-523; Amaryllis 310531-533; Yachiyo/Mifuyu (Origin) 311021-023. Correct inherited text and valid phonetic distinctions were preserved rather than retranslated wholesale.\n\nSevere errors include: father targeting his own daughter instead of an escaped criminal; pain cries converted into a location; battle continuation converted into discarding a card; secondhand words converted into resale; a rejected date converted into being scratched; creating memories converted into making a storage device; spurious character names; inverted subject and negation. Toyo's pet name is repaired only where the same Japanese name matches the name explicitly established earlier in that story. Original harsh dialogue, fictional beliefs, and uncertainties are not rewritten.\n\nCorresponding TXT/source/web exports were synchronized only after full-section exact current/historical matching, with reversible spans. Exact counts, full field decisions, source blobs, parsed-event equality and protection checks are in the adjacent manifest/evidence. 43 V4 repairs, 196 authorized Chinese source files and unrelated dirty worktree files remain untouched.\n\nThis is source validation, not proof of publication. Player 3317, Reader deployment, and ADV registration require separate live receipts. Model-assisted proofreading is not human-authorship reclassification. No game-device playback verification is asserted.\n"
 folder='manifests/story_quality_semantic_batch05_ai_only_20261001';files={folder+'.json':dump(v),folder+'_evidence.json.gz':gzip.compress(dump(evidence),mtime=0),'docs/story-quality/20261001-semantic-batch05-validated.md':report.encode()}
 for repo in ('reader','patch'):
  for path,b in files.items():out=W/'stage'/repo/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 for f in (W/'review').glob('*.final.txt'):
  out=W/'stage/reader/docs/story-quality/reviewed/20261001-semantic-batch05-ai-only'/f.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(f.read_bytes())
 progress=load('progress.json');progress.update(stage='validated',checkpoint='24整话97脚本5124字段完整审读；720正文修订通过结构、反向字节、控制标签及61脚本真实解析验证；待3317与Reader/ADV交付',validation=v,next=['只提交两仓现有main','在3316精确基线上构建并验证3317','干净快照构建部署Reader并登记ADV','更新1079确认AI台账和逐篇证据'])
 save('progress.json',progress);print('VALIDATED',json.dumps(v,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
