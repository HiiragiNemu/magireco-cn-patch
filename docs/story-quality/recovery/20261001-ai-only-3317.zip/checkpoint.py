"""Persist stage evidence and current delivery state without overwriting other work."""
from pathlib import Path
import json,sys,subprocess,datetime
W=Path(__file__).resolve().parent;R=W.parent/'repo'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,timeout=90)
def write(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def main():
 note=sys.argv[1];now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 p=json.loads((W/'progress.json').read_bytes());p.update(checkpoint=note,updated_at=now);write(W/'progress.json',p)
 git('fetch','origin','main');head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse','origin/main').decode().strip(),'Reconcile concurrent main before handoff'
 paths=['STORY_QUALITY_HANDOFF.md','docs/story-quality/CONTINUATION.md','docs/story-quality/CONTINUATION_STATE.json','docs/story-quality/20261001-ai-only-batch05.md']
 assert not git('diff','--name-only','--',*paths).strip(),'Uncommitted handoff changes'
 st=json.loads((R/paths[2]).read_bytes());st.update(updated_at=now,checkpoint=note,active_batch=p,task_id=p['task_id']);st['paths']['current_batch']=str(W)
 if (W/'delivery-state.json').exists():st.update(json.loads((W/'delivery-state.json').read_bytes()))
 st['pending']=['仅继续已确认AI机翻的完整剧情；官方/人工和来源不明稿不重译','当前批次计数详见active_batch，暂存审读不等于已经发布','Reader128及客户端35来源未明项只做来源调查，不纳入自动重译','玩家包、Reader网站、ADV登记分开验证，不重复发行3316']
 write(R/paths[2],st)
 count=len(p.get('reviewed',[]));fields=p.get('reviewed_fields',0);changed=p.get('changed_fields',0)
 root=f'''# Reader／CN patch：AI剧情质量接续入口\n\n更新：{now}\n\n{note}\n\n工作区 `{R}`；当前批次 `{W}`；任务 `{p['task_id']}`。\n\n本批选择{p.get('selected_chapters')}整话、{p.get('selected_scenes')}独立脚本、{p.get('selected_cn_fields')}正文显示字段。目前完整审读{count}脚本、{fields}字段，精确修订{changed}字段；实际交付以STATE四环节记录为准，不把暂存当发布。\n\n先读 docs/story-quality/20261001-ai-only-batch05.md、CONTINUATION_STATE.json 和 CONTINUATION.md 的最新BATCH05区。上一批3316已交付；已有确认AI台账1079片段、完成178、待901，新批审读完成量需与目标版本绑定后才累加。旧22/278、10907全库分母作废。\n\n只处理确证AI/机翻，官方、国服和确认人工稿排除，来源未明不自动重译。保持43 V4、196授权中文与原有工作树变更，不动L2D/AIO/APK/字体，仅现有main，不分支/PR/强推。每个有价值断点与最终回复前更新并提交交接。\n'''
 (R/paths[0]).write_text(root,encoding='utf8')
 cont=(R/paths[1]).read_text(encoding='utf8');start='<!-- AI-ONLY-BATCH05-START -->';end='<!-- AI-ONLY-BATCH05-END -->';block=start+'\n## 最新断点：AI-only第五批\n\n'+root+'\n以下内容为历史记录，不覆盖本区当前状态。\n'+end
 if start in cont:cont=cont[:cont.index(start)]+block+cont[cont.index(end)+len(end):]
 else:first,rest=cont.split('\n',1);cont=first+'\n\n'+block+'\n'+rest
 (R/paths[1]).write_text(cont,encoding='utf8')
 report=f'''# AI机翻第五批：可恢复进度\n\n{now}：{note}\n\n来源：3d463befe7a10d4cb72034378ce2a6f23c377abb的机器翻译测试导入；每个目标必须在已确认AI台账中有机器输出匹配证据、未完成状态和未变的中日文blob。官方/人工及保护稿排除。\n\n本轮{p.get('selected_chapters')}话，{p.get('selected_scenes')}脚本，{p.get('selected_cn_fields')}字段。当前真实审读{count}脚本、{fields}字段，修订{changed}字段；仅调整有原文依据的错误，正确旧稿保留。运行结构、说话角色、音频及控制码不改变。\n\n当前阶段：{p.get('stage')}。正式交付以CONTINUATION_STATE.json、发布回执及公开接口读回为准；未写入新delivery-state时保持3316旧生产状态。\n\n证据位于 `{W}`：review-sources.json、provenance.json、review/*.edits.json、repair-plan.json；恢复使用最新main交接，不运行旧版本固定发布脚本。\n'''
 (R/paths[3]).write_text(report,encoding='utf8')
 import gzip
 recovery_path='docs/story-quality/recovery/20261001-ai-only-batch05-checkpoint.json.gz'
 assert not git('diff','--name-only','--',recovery_path).strip(),'Uncommitted recovery edits'
 ev={'schema':1,'updated_at':now,'progress':p,'bases':json.loads((W/'bases.json').read_bytes()),'review_sources':json.loads((W/'review-sources.json').read_bytes()),'decisions':{f.stem:json.loads(f.read_bytes()) for f in (W/'review').glob('*.edits.json')},'plan':json.loads((W/'repair-plan.json').read_bytes()) if (W/'repair-plan.json').exists() else None,'helpers':{n:(W/n).read_text(encoding='utf8') for n in ['collect.py','decisions.py','stage.py','review_io.py','checkpoint.py']}}
 (R/recovery_path).parent.mkdir(parents=True,exist_ok=True);(R/recovery_path).write_bytes(gzip.compress((json.dumps(ev,ensure_ascii=False,indent=2)+'\n').encode('utf8'),mtime=0));paths.append(recovery_path)
 git('add','--',*paths);git('commit','--only','-m','docs(handoff): '+note+' [skip ci]','--',*paths);git('push','origin','HEAD:refs/heads/main');c=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==c
 write(W/'checkpoint-commit.json',{'commit':c,'at':now,'note':note});print('CHECKPOINT',c,note,flush=True)
if __name__=='__main__':main()
