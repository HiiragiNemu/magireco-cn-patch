"""Verified docs-only closeout; never rebuild or republish scenario3317."""
from pathlib import Path
import sys,json,os,datetime,gzip,zipfile,hashlib
W=Path(__file__).resolve().parent;R=W.parent/'repo';D=W/'delivery';REV=json.loads((W/'reader-commit.json').read_bytes())['commit']
sys.path.insert(0,str(W));from commit_sources import git,tree

def read(n):return json.loads((W/n).read_bytes())
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode('utf8')
def save(n,x):(W/n).write_bytes(enc(x))
def sha(x):return hashlib.sha256(x).hexdigest()
def blob(x):return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
def dirty_guard():
 for p,h in read('dirty-tracked-hashes.json').items():assert sha((R/p).read_bytes())==h,p
 for name,args in [('initial-diff.bin',('diff','--binary')),('initial-staged.bin',('diff','--cached','--binary')),('initial-status-z.bin',('status','--porcelain=v1','-z'))]:assert git('reader',*args)==(W/name).read_bytes(),name

def commit_docs(repo,files):
 git(repo,'fetch','origin','main');base=git(repo,'rev-parse','FETCH_HEAD').decode().strip();baseline=tree(repo,base)
 if repo=='reader':assert git(repo,'rev-parse','HEAD').decode().strip()==base
 expected={p:baseline.get(p,{}).get('sha') for p in files}
 for p in files:assert p.startswith('docs/story-quality/') or p=='STORY_QUALITY_HANDOFF.md',p
 for attempt in range(3):
  git(repo,'fetch','origin','main');head=git(repo,'rev-parse','FETCH_HEAD').decode().strip();current=tree(repo,head)
  assert all(current.get(p,{}).get('sha')==v for p,v in expected.items()),'Concurrent handoff change'
  key='reader_files' if repo=='reader' else 'runtime_files'
  assert all(current[x['path']]['sha']==x['after'] for x in read('repair-plan.json')[key]),'Concurrent scenario change'
  env=os.environ.copy()|{'GIT_INDEX_FILE':str(W/(repo+'-closeout-index-'+datetime.datetime.now().strftime('%H%M%S%f')))};git(repo,'read-tree',head,env=env);records=[]
  for p,b in files.items():
   h=git(repo,'hash-object','-w','--stdin',data=b).decode().strip();assert h==blob(b);records.append(('100644 '+h+'\t'+p+'\0').encode())
  git(repo,'update-index','-z','--index-info',data=b''.join(records),env=env);t=git(repo,'write-tree',env=env).decode().strip()
  env|={'GIT_AUTHOR_NAME':'HiiragiNemu','GIT_AUTHOR_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com','GIT_COMMITTER_NAME':'HiiragiNemu','GIT_COMMITTER_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com'}
  c=git(repo,'commit-tree',t,'-p',head,data=b'docs(handoff): verified AI-only3317 delivery and source-bound1079-script census [skip ci]\n',env=env).decode().strip();new=tree(repo,c)
  assert all(new[p]['sha']==blob(b) for p,b in files.items()) and all(new[p]==v for p,v in current.items() if p not in files)
  try:git(repo,'push','origin',c+':refs/heads/main')
  except RuntimeError:
   if attempt==2:raise
   continue
  git(repo,'fetch','origin','main');remote=tree(repo,'FETCH_HEAD');assert all(remote[p]['sha']==blob(b) for p,b in files.items())
  if repo=='reader':git(repo,'merge','--ff-only',c)
  save('closeout-'+repo+'-commit.json',{'commit':c,'parent':head,'files':len(files),'non_target_tree_preserved':True,'remote_readback_passed':True});print('DOCS_COMMITTED',repo,c,flush=True);return c
 raise RuntimeError('Unable to safely advance main')

def main():
 assert not (W/'closeout-reader-commit.json').exists(),'Already closed: verify instead of repeating'
 dirty_guard();now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 v=read('validation.json');p=read('published-package-receipt.json');h=read('delivery/online-exact-verification.json');b=read('browser-verification.json');a=read('delivery/adv-release-published.json');u=read('delivery/production-upload.json');q=read('delivery/full-check-result.json');edge=read('delivery/edge-status-production-verified.json');count=read('current-confirmed-machine-summary.json');run=read('publisher-run.json')
 assert v['display_fields_revised']==720 and v['complete_scenes_reviewed']==97 and v['body_fields_revised']==720 and v['explicit_speaker_label_repairs']==0
 assert p['version']==3317 and p['reader_commit']==REV and p['status']=='published_and_anonymously_verified'
 assert run['conclusion']=='success' and run['head_sha']==read('public-commit.json')['commit']
 assert h['source_revision']==REV and h['passed']==h['total'] and h['failed']==0 and h['total']>=1800 and h['authorized_196_all_covered']
 assert b['sourceRevision']==REV and b['passed'] and b['checks']==24 and edge['passed'] and edge['checks']==5
 assert q['python_tests']==611 and q['python_failures']==0 and q['node_tests']==730 and q['node_failures']==0
 assert a['release']['source_revision']==REV and a['release']['deployment']==u['canonical_url'] and u['canonical_commit']==REV
 assert count['confirmed_current_machine_scripts']==1079 and count['complete']==275 and count['remaining']==804
 cross=read('cross-repo-machine-summary.json');assert not cross['completed_scripts_with_player_body_differences']
 proof=read('completed-machine-review-evidence.json');ledger=read('current-confirmed-machine-ledger.json');assert len(proof)==275 and len(ledger)==1079
 for repo in ('reader','patch'):
  git(repo,'fetch','origin','main');current=tree(repo,'FETCH_HEAD');key='reader_files' if repo=='reader' else 'runtime_files'
  assert all(current[x['path']]['sha']==x['after'] for x in read('repair-plan.json')[key]),'Current source moved'
  if repo=='reader':
   for x in ledger:assert current[x['path']]['sha']==x['current_blob'] and current[x['jp_path']]['sha']==x['jp_blob'],x['path']
 versions=read('post-package-version-checks.json');assert len(versions)==2 and all(x['status']==200 and x['data']['version']==3317 and x['data']['md5']==p['package']['md5'] for x in versions)
 state={'reader_source_commit':REV,'reader_data_commit':REV,'cn_patch_source_commit':p['cn_patch_commit'],'scenario_version':3317,'package':p['package'],'package_publication_run':run['id'],'reader_production_deployment':u['canonical_id'],'reader_site_uploaded':True,'reader_site_uploaded_for_active_batch':True,'reader_exact_http':{k:v for k,v in h.items() if k!='results'},'reader_browser_checks':b,'adv_current_for_this_source_registered':True,'adv_registered_for_active_batch':True,'adv_record':a['release'],'game_device_verified':False};save('delivery-state.json',state)
 progress=read('progress.json');progress.update(stage='delivered',closed_at=now,checkpoint=f"24话97脚本5124字段/720正文修订已交付3317、Reader {u['canonical_id'][:8]}与ADV；{h['total']} HTTP及24浏览器检查通过；确认AI1079片段已复核275、待804",active_sessions={},whole_corpus_complete=False,next=['按next-ai-only-full-chapter-queue.json继续确认AI完整剧情，写前刷新中日文blob并排除人工','804待完整复核含24未索引；不得将机器扫描或单节命中计为整话完成','Reader128和客户端35来源未明仅做来源调查，不直接重译','3317、Reader和ADV已经交付，重接不重复发行；此批版本限定脚本不得原样套用于下一批']);save('progress.json',progress)
 receipt={'schema':2,'verified_at':now,'batch':progress['batch'],'delivery':state,'translation':v,'tests':q,'edge_checks':edge,'counts':count,'indexed_candidate_counts':read('completion.json'),'cross_repo_binding':cross,'package_receipt':p,'ordinary_player_version_checks':versions,'original_uncommitted_state_unchanged':True,'whole_corpus_complete':False,'device_gameplay_verified':False,'source_provenance_holds':{'reader':128,'client_only':35,'automatically_retranslate':False}};save('final-receipt.json',receipt)
 gaps=read('Reader_AI_Full_Ledger_20261001.json');gaps.update(verified_at=now,summary=count,cross_repo_summary=cross,client_extra_queue=read('patch-only-provenance-queue.json'),delivery={'scenario_version':3317,'reader_source':REV,'patch_source':p['cn_patch_commit'],'reader_deployment':u['canonical_id'],'adv_release':a['release']});save('Reader_AI_Full_Ledger_20261001.json',gaps);compressed=gzip.compress(enc(gaps),mtime=0);(W/'Reader_AI_Full_Ledger_20261001.json.gz').write_bytes(compressed)
 doc=f'''# Reader／CN patch：3317 AI剧情校订交付回执

核验时间：{now}。本轮已交付，不是源代码待发布状态。

## 实际完成

完整对照日文审读24话、97个独立运行脚本、5124个正文显示字段，修复720处正文。61个脚本有实际修改，36个完整审读后保持原样，发言者标签修改0处。同步42份源TXT／网页配对副本，共1474个精确文本片段；16节旧导出通过全文历史底稿匹配后同步，4处物理换行污染得到修正；无缺失、无模糊对齐。

覆盖千鹤、小黑、奥尔加、冈希尔德、赫露迦、台与、阿玛琉莉丝、八千代·美冬（起始）各三话。每份目标均在当前确认AI台账中有机器输出与日文匹配证据；官方／确认人工和仅来源不明稿不纳入重译。正确继承译文、原作笑点与不同称呼的有意区分保持，不追求改写率。

修正例：父亲要杀逃犯被译成父亲要杀女儿；喊痛被译成地点；乘胜追击变成弃牌；引用他人的话变成二手买卖；失去亲友的罗刹女被魔附身却被写成亲友被附身；约会被放鸽子变成被刮伤；共同创造回忆变成制作存储器；对话凭空插入忧、莎奈等人名。宠物舔舔只按本篇明确取名及对应日文精确修正，不进行跨库盲目替换。

## 四环节交付

- Reader剧情数据：`{REV}`，既有main。
- CN patch剧情数据：`{p['cn_patch_commit']}`，既有main。
- 玩家包：3317，latest和scenario-3317，工作流`{run['id']}`成功；两条普通玩家版本入口已读回一致。
- Reader正式部署：`{u['canonical_id']}`，源码`{REV}`。
- ADV公开登记：`{a['release']['deployment']}`，源码与上述一致。

玩家包字节数：{p['package']['size']}。SHA-256：`{p['package']['sha256']}`。MD5：`{p['package']['md5']}`。

## 验证与无损边界

23项专项拒绝性／结构测试通过；61个实际改动脚本通过真实Reader解析，正文以外的结构、角色身份、姓名标签、动作、音频、控制标签及强调类型均保持。全部JSON和TXT文本修改均可精确反向恢复到原始字节。

Python {q['python_tests']}项，失败0，跳过{q['python_skipped']}；Node {q['node_tests']}项，失败0。原有lint、typecheck、feature policy和生产依赖审计通过，未改测试来使其通过。正式站{h['total']}项内容逐字节检查：通过{h['passed']}、失败{h['failed']}、有重试的目标{h['retries']}。桌面／手机浏览器24项阅读检查与5项状态接口回归通过。

玩家包{p['unchanged_files']}个非目标文件逐字节未变。先前{p['previous_corrected_scripts']}份修订中，{p['previous_byte_identical']}份保持原样，另{len(p['previous_exact_extensions'])}份只叠加有依据的新文字修正。43份V4兼容、196份授权中文和原工作树未提交状态均保持。未改L2D、AIO、APK、字体或非剧情JS。未进行Totentanz实机动画验收，网页检查不替代设备验收。

## 全部确认范围与剩余

以一份独立剧情运行JSON作为一个片段，Reader、TXT和玩家包镜像不重复计数：确认AI来源共1079个，完整复核275个（此前178＋本轮97），尚待804个，其中已含24个未索引片段。待复核不等于已确定有错。

另有Reader128个、客户端独有35个正文仍仅是来源调查事项；不自动标为AI，不对其重新翻译。300个广义来源候选目录条目现有84个整话完成、216个未整话完成，它们不是纯AI分母，不与1079片段混算。旧10907全库分母和22／278口径均已废弃。

完整逐篇台账：`docs/story-quality/20261001-ai-only-census.json.gz`。包含每个片段路径、中日文blob、完成依据、未完成项、跨仓对应、来源不明项和后续整话队列。

## 继续工作

固定入口仍为`STORY_QUALITY_HANDOFF.md`、`docs/story-quality/CONTINUATION.md`、`CONTINUATION_STATE.json`。当前回执为`docs/story-quality/20261001-ai-only-batch05-published.md`及同名JSON。下一批读取完整队列并重新核对main及真实生产；不要因换窗口再次发行3317。全库AI校订尚未完成。
'''
 (W/'Reader_AI_3317_Delivery_20261001.md').write_text(doc,encoding='utf8')
 safe=['collect.py','decisions.py','review_io.py','stage.py','sync_text.py','translation_rules.py','test_translation_rules.py','reader_check.cjs','exact_json.py','prepare_delivery.py','commit_sources.py','build_package.py','prepare_public.py','publish_scenario_3317.py','prepare_build.py','update_census.py','cross_repo_verify.py','checkpoint.py','browser_verify.cjs','prepare_acceptance.py','run_full_qa.py','inspect_publisher.py','closeout.py','bases.json','review-sources.json','chapters.json','provenance.json','progress.json','validation.json','repair-plan.json','text-plan.json','historical-text-baselines.json','reader-commit.json','patch-commit.json','public-commit.json','publisher-run.json','published-package-receipt.json','post-package-version-checks.json','completed-machine-review-evidence.json','current-confirmed-machine-summary.json','cross-repo-machine-summary.json','next-ai-only-full-chapter-queue.json','delivery-state.json','final-receipt.json','Reader_AI_3317_Delivery_20261001.md','Reader_AI_Full_Ledger_20261001.json.gz','browser-verification.json']
 dep=['build-steps.json','full-check-result.json','source-preservation-before-generation.json','source-preservation-after-generation.json','source-preservation-after-build.json','source-preservation-after-qa.json','online-exact-verification.json','online-exact-plan.json','edge-status-production-verified.json'];members=[];archive=W/'20261001-ai-only-3317-recovery.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in safe:assert (W/n).is_file(),n;z.write(W/n,n);members.append(n)
  for n in dep:assert (D/n).is_file(),n;z.write(D/n,'delivery/'+n);members.append('delivery/'+n)
  for glob in ['*.edits.json','*.final.txt']:
   for f in sorted((W/'review').glob(glob)):z.write(f,f.relative_to(W).as_posix());members.append(f.relative_to(W).as_posix())
 recovery={'path':'docs/story-quality/recovery/20261001-ai-only-3317.zip','sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(members)};save('recovery-metadata.json',recovery);receipt['recovery']=recovery;save('final-receipt.json',receipt)
 st=json.loads((R/'docs/story-quality/CONTINUATION_STATE.json').read_bytes());previous=st.get('active_batch',{});st.update(state,updated_at=now,checkpoint=progress['checkpoint'],active_batch=progress,task_id=progress['task_id'],recovery_bundle=recovery,project_status='long_term_in_progress_AI_only_not_corpus_complete',pending=progress['next']);st['paths']['current_batch']=str(W)
 st['ai_only_scope']={'confirmed_machine_scripts':1079,'complete':275,'pending':804,'unit':'distinct runtime JSON fragment; source/TXT/player copies not duplicated','pending_unindexed_included':24,'new_whole_chapters':24,'new_full_review_scripts':97,'broad_candidate_indexed_entries':300,'broad_candidate_complete':84,'broad_candidate_pending':216,'broad_candidates_not_all_proven_AI':True,'reader_provenance_only_holds':128,'client_only_provenance_holds':35,'previous_22_and_278_claim_invalid':True,'ledger':'docs/story-quality/20261001-ai-only-census.json.gz','rule':'Official/human text excluded; unknown provenance is not automatic permission to retranslate.'}
 st.setdefault('previous_batch_summaries',{})['20261001-semantic-batch05-ai-only']={'stage':'delivered','scenario_version':3317,'reader_source_commit':REV,'cn_patch_source_commit':p['cn_patch_commit'],'recovery':recovery}
 root=f'''# Reader／CN patch：AI剧情质量接续入口

更新：{now}

{progress['checkpoint']}。Reader数据提交`{REV}`，CN patch数据提交`{p['cn_patch_commit']}`。玩家3317；Reader和ADV均为`{u['canonical_id']}`。后续交接文档提交不是新运行版本。

先读`docs/story-quality/20261001-ai-only-batch05-published.md`及同名JSON，再读CONTINUATION_STATE.json。全量台账`docs/story-quality/20261001-ai-only-census.json.gz`；恢复包`{recovery['path']}`。

只处理确认AI／机翻；官方、国服、确认人工排除。1079片段已复核275、待804（含24未索引）。Reader128和客户端35仅做来源调查。旧10907／22／278统计已废弃，不混用片段、整话和镜像副本。

工作区`{R}`；当前批次`{W}`；任务`{progress['task_id']}`。按next-ai-only-full-chapter-queue.json继续完整剧情并重新核对当前source blobs。3317已交付，不重发，旧版本限定脚本不可直接复用。

仅现有main，不分支、PR或强推。保留43V4、196授权中文及所有并行未提交状态；不动L2D、AIO、APK、字体。每个可恢复断点及最终答复前提交最新交接。实机动画未验收，全库未完成。
'''
 cont=(R/'docs/story-quality/CONTINUATION.md').read_text(encoding='utf8');start='<!-- AI-ONLY-BATCH05-START -->';end='<!-- AI-ONLY-BATCH05-END -->';assert start in cont and end in cont
 block=start+'\n## 最新断点：AI-only3317已交付\n\n'+root+'\n以下旧段仅为历史，不覆盖上面的最新状态。\n'+end;cont=cont[:cont.index(start)]+block+cont[cont.index(end)+len(end):]
 scope='''# AI-only scope after3317

Only confirmed machine/AI-derived story content is subject to semantic repair. Official, licensed and confirmed-human translations are excluded. Unknown provenance is investigated, not automatically retranslated.

The old22-complete/278-remaining claim was invalid because arbitrary subscript hits were counted as whole chapters and previous completions/unindexed paths were missed.10,907 was whole-corpus inventory, never the AI task denominator.

Current source-bound ledger:1079 machine-origin runtime fragments;275 complete;804 pending including24 unindexed. Reader128 and client35 further bodies have unresolved provenance. Broad indexed provenance candidates:300,84 whole entries complete,216 incomplete; not a pure-AI denominator.

Batch05 delivered24 full chapters/97scripts/5124fields read/720body corrections; player3317,Reader/ADV source f1955c691d7747fe1ead58af3fe6847c4c62525c. Full current receipt:20261001-ai-only-batch05-published.md/.json; complete ledger:20261001-ai-only-census.json.gz. Model-assisted correction never grants human authorship.
'''
 files={'STORY_QUALITY_HANDOFF.md':root.encode(),'docs/story-quality/CONTINUATION.md':cont.encode(),'docs/story-quality/CONTINUATION_STATE.json':enc(st),'docs/story-quality/20261001-ai-only-scope.md':scope.encode(),'docs/story-quality/20261001-ai-only-batch05.md':doc.encode(),'docs/story-quality/20261001-ai-only-batch05-published.md':doc.encode(),'docs/story-quality/20261001-ai-only-batch05-published.json':enc(receipt),'docs/story-quality/20261001-ai-only-census.json.gz':compressed,recovery['path']:archive.read_bytes()}
 for path,data in files.items():f=W/'closeout-stage/reader'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 pfiles={path:data for path,data in files.items() if path.startswith('docs/story-quality/') and path not in ['docs/story-quality/CONTINUATION.md','docs/story-quality/CONTINUATION_STATE.json','docs/story-quality/20261001-ai-only-scope.md']}
 pc=commit_docs('patch',pfiles);st['delivery_receipt_commits']={'reader_data':REV,'patch_data':p['cn_patch_commit'],'patch_closeout':pc,'reader_closeout_note':'the commit containing this final handoff'};files['docs/story-quality/CONTINUATION_STATE.json']=enc(st);rc=commit_docs('reader',files);dirty_guard()
 save('final-handoff-commits.json',{'reader':rc,'patch':pc,'runtime_source_unchanged':True,'original_dirty_and_staged_state_unchanged':True,'recovery':recovery})
 with (W/'Reader_AI_3317_Delivery_20261001.md').open('a',encoding='utf8') as f:f.write('\n最终交接提交：Reader `'+rc+'`；CN patch `'+pc+'`。\n')
 print('FINAL_HANDOFF_COMPLETE',rc,pc,json.dumps(recovery),flush=True)
if __name__=='__main__':main()
