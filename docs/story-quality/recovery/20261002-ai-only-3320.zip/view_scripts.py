"""Read every display field of selected scripts; collapse executable tag runs to immutable placeholders only."""
from pathlib import Path
import json,sys
W=Path(__file__).resolve().parent;sys.path.insert(0,str(W.parent/'severe-5109-20261001'));from collect_review import CTRL
selected=set(sys.argv[1:]);sources=json.loads((W/'review-sources.json').read_bytes())
for s in sources:
 if s['id'] not in selected and s['chapter_id'] not in selected:continue
 rows=json.loads((W/'review'/(s['id']+'.aligned.json')).read_bytes());print('\n###',s['id'],'FIELDS',len(rows),'###')
 for r in rows:print(str(r['ordinal'])+' '+str(r['cn_name'])+' | J:'+json.dumps(CTRL.sub('§',r['jp']),ensure_ascii=False)+' | C:'+json.dumps(CTRL.sub('§',r['cn']),ensure_ascii=False))
 print('### END',s['id'],'###')
