"""Bounded live browser/status acceptance of the just-uploaded production source."""
from pathlib import Path
import json,time,subprocess,os
W=Path(__file__).resolve().parent;D=W/'delivery';rev=json.loads((W/'reader-commit.json').read_bytes())['commit']
for i in range(120):
 p=D/'production-upload.json'
 if p.exists():
  d=json.loads(p.read_bytes());assert d['canonical_commit']==rev and d['all_other_configurations_unchanged'];break
 time.sleep(5)
else:raise TimeoutError('No verified production upload yet')
env=os.environ.copy()|{'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8'}
with (W/'browser-verification.log').open('w',encoding='utf8') as out:
 r=subprocess.run(['node',str(W/'browser_verify.cjs')],cwd=W,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=1000)
assert r.returncode==0,(W/'browser-verification.log').read_text(encoding='utf8')[-4000:]
b=json.loads((W/'browser-verification.json').read_bytes());assert b['checks']==36 and b['passed'];print('BROWSER_PASS',36,rev,flush=True)
r=subprocess.run(['python','-X','utf8',str(D/'verify_edge_status.py')],cwd=W,env=env,capture_output=True,timeout=240)
(D/'edge-status-verification.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr.decode(errors='replace')
e=json.loads((D/'edge-status-production-verified.json').read_bytes());assert e['passed'] and e['checks']==5;print('EDGE_STATUS_PASS',5,rev,flush=True)
