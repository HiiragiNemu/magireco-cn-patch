"""Close only fully verified3320 delivery; publish cumulative inventory/recovery to CN patch alone."""
from pathlib import Path
import sys,json,gzip,zipfile,hashlib,datetime,subprocess
W=Path(__file__).resolve().parent;R=W.parent/'repo';D=W/'delivery';sys.path.insert(0,str(W));from commit_records import commit,dirty_guard,enc,git,tree,blob

def read(n):return json.loads((W/n).read_bytes())
def save(n,d):(W/n).write_bytes(enc(d))
def main():
 assert not (W/'final-handoff-reader-commit.json').exists(),'Already closed; verify only'
 dirty_guard();now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 v=read('validation.json');p=read('published-package-receipt.json');h=read('delivery/online-exact-verification.json');b=read('browser-verification.json');q=read('delivery/full-check-result.json');edge=read('delivery/edge-status-production-verified.json');a=read('delivery/adv-release-published.json');u=read('delivery/production-upload.json');c=read('current-confirmed-machine-summary.json');cv=read('contributions-3320/verification.json');cs=read('contributions-3320/summary.json');cc=read('contributions-3320-patch-commit.json');cross=read('cross-repo-machine-summary.json');run=read('publisher-run.json');plan=read('repair-plan.json');rev=read('reader-commit.json')['commit'];accounting=read('context-and-alias-accounting.json');cap=read('capability-verification.json')
 assert p['version']==3320 and p['status']=='published_and_anonymously_verified' and p['reader_commit']==rev and p['cn_patch_commit']==read('patch-commit.json')['commit']
 assert run['conclusion']=='success' and run['head_sha']==read('public-commit.json')['commit']
 assert v['complete_scenes_reviewed']==94 and v['new_complete_scenes']==91 and v['previous_complete_context_scenes']==3 and v['display_fields_reviewed']==5341 and v['new_reviewed_fields']==5155
 assert v['body_fields_revised']==p['changed_chinese_fields']==2310 and p['changed_runtime_scripts']==91 and v['explicit_speaker_label_repairs']==0 and v['restored_previously_empty_display_fields']==0
 assert v['specialized_tests_passed']==23 and v['additional_missing_display_contract_tests']==17 and v['reader_txt_files']==40 and v['reader_txt_field_spans']==7738
 assert h['source_revision']==rev and h['passed']==h['total'] and h['total']>=2135 and h['failed']==0 and h['authorized_196_all_covered']
 assert b['sourceRevision']==rev and b['passed'] and b['checks']==36 and edge['passed'] and edge['checks']==5
 assert q['source_revision']==rev and q['python_tests']==611 and q['python_skipped']==3 and q['python_failures']==0 and q['node_tests']==730 and q['node_failures']==0 and not q['source_or_test_code_modified_to_pass']
 assert u['canonical_commit']==rev and u['all_other_configurations_unchanged'] and a['release']['source_revision']==rev and a['release']['deployment']==u['canonical_url']
 assert c['confirmed_current_machine_scripts']==1079 and c['complete']==534 and c['remaining']==545 and c['pending_unindexed']==24
 assert cv['passed'] and cv['checks']==19 and cv['source_summary']==cs and cc['remote_verified'] and cc['ledger_sha256']==cv['ledger_sha256'] and cc['previous_snapshot_unchanged']
 assert cs['last_published_scenario_version']==3320 and cs['confirmed_ai_fully_reviewed']==534 and cs['completed_before_takeover']==48 and cs['completed_after_takeover']==486 and cs['legacy_unique_registered_ids']==498
 assert not cross['completed_scripts_with_player_body_differences'] and accounting['prior_proofs_preserved']==443 and accounting['new_unique_scripts']==91 and accounting['new_indexed_entries']==20
 assert cap['execute_and_write_verified'] and all(x['permissions']['push'] and x['permissions']['admin'] for x in cap['repositories'])
 for repo,key in [('reader','reader_files'),('patch','runtime_files')]:
  git(repo,'fetch','origin','main');cur=tree(repo,'FETCH_HEAD');assert all(cur[x['path']]['sha']==x['after'] for x in plan[key])
  if repo=='reader':assert not any('/contributions/' in z or z.endswith('ai-only-census.json.gz') for z in cur)
  else:assert cur['docs/story-quality/contributions/ledger.json.gz']['sha']==blob((W/'contributions-3320/ledger.json.gz').read_bytes())
 ledger=read('current-confirmed-machine-ledger.json');rt=tree('reader','FETCH_HEAD');assert len(ledger)==1079 and all(rt[x['path']]['sha']==x['current_blob'] and rt[x['jp_path']]['sha']==x['jp_blob'] for x in ledger)
 for s in read('review-sources.json'):
  if s['already_complete_context_only']:assert rt[s['cn_path']]['sha']==s['cn_sha'] and not read('review/'+s['id']+'.edits.json')['edits']
 canonical={'repository':'HiiragiNemu/magireco-cn-patch','entry':'docs/story-quality/contributions/README.md','census':'docs/story-quality/20261002-ai-only-census.json.gz','commit':cc['commit'],'ledger_sha256':cc['ledger_sha256'],'rule':'CN patch only; no duplicate cumulative files or cumulative ZIP contents in Reader/public'}
 state={'reader_source_commit':rev,'reader_data_commit':rev,'cn_patch_source_commit':p['cn_patch_commit'],'scenario_version':3320,'package':p['package'],'package_publication_run':run['id'],'reader_production_deployment':u['canonical_id'],'reader_site_uploaded':True,'reader_site_uploaded_for_active_batch':True,'adv_current_for_this_source_registered':True,'adv_registered_for_active_batch':True,'adv_record':a['release'],'game_device_verified':False};save('delivery-state.json',state)
 core={'schema':1,'batch':'20261002-semantic-batch08-ai-only','verified_at':now,'translation':v,'delivery':state,'tests':q,'http':{k:z for k,z in h.items() if k!='results'},'browser':b,'edge_checks':edge,'package_receipt':p,'contribution_ledger_reference':canonical,'capability_verification':cap,'context_and_alias_accounting':accounting,'unrelated_worktree_state_unchanged':True,'whole_corpus_complete':False,'device_gameplay_verified':False}
 full=core|{'confirmed_ai_counts':c,'cumulative_contributions':cs,'contribution_checks':cv,'cross_repo_summary':cross};save('final-receipt.json',full)
 nextq=read('next-ai-only-full-chapter-queue.json');nextid=nextq['queue'][0]['story_id'];nexttitle=nextq['queue'][0].get('title') or nextq['queue'][0].get('source_identity','');assert nextid not in {x['story_id'] for x in read('chapters.json')}
 headline=f'''# 3320 剧情校订交付回执

核验时间：{now}。开工前已从普通玩家入口确认3319；本轮新修订另行发布3320，没有重复抬版本发行旧内容。

## 实际完成范围

18个非重叠整话、94个独立片段、5341个正文字段完整对照日文。其中91个新完成片段／5155字段，另3个已经完成的上下文片段／186字段只复读、不改动、不重复计数。修改2310个正文字段，显示姓名标签0处，新增显示事件0处。覆盖月出里、怜、七香的记忆博物馆各一话，5100《空虚的心中绽放之花》上下篇全20片段，5102《传说的终章，光辉的尽头～魔法少女贞德～》全13章62片段。

40份源TXT／网页配对文件同步7738个精确文本片段；25个历史正文基线逐整节核对，无模糊对齐、无遗漏。两条合辑510201-09与510210-13也同步完成，但合辑重复引用同一批62个片段，因此不能把18个独立整话算成20篇新增故事，也不能把合辑再作为额外片段累加贡献。

主要修复：消逝的光芒误成闪耀；不能死误成必须死；国王要求杀死母亲误成自杀；帝王、姊妹与朋友的施受关系；梦境、照片、记忆与历史改变的因果和先后；优奈对圣女和心魔之石的误解、知花的侦察及友情；拖挂房车和温柔行为笔记的语境错误。原作中的猜测、反证及后续揭示均分阶段保留，不预先用后面的真相改写人物当时的误解。不重译官方、确认人工或来源不明内容。

## 权限结论与实际入口

AgentDock可执行系统命令、写入文件，当前三个仓库凭据都有push/admin权限。已经实际通过临时Git索引、commit-tree和非强制push推进既有main；Cloudflare认证与本次正式部署也均已成功。不存在整个环境仅能本地读取的限制。本轮没有为此扩大权限、更换密钥或改动服务配置。一个只读工具接口的限制不能推导为AgentDock整体只读。

## 发布与保全

Reader数据main：`{rev}`；CN patch数据main：`{p['cn_patch_commit']}`。玩家latest与scenario-3320均发布成功，工作流`{run['id']}`，两条普通玩家版本入口均回传3320。Reader正式部署`{u['canonical_id']}`，ADV登记同一源码与部署。

玩家包{p['package']['size']}字节，SHA-256 `{p['package']['sha256']}`，MD5 `{p['package']['md5']}`。{p['unchanged_files']}个非目标文件逐字节未改；以前{p['previous_corrected_scripts']}个已发布修订中{p['previous_byte_identical']}个完全保留，{len(p['previous_exact_extensions'])}个仅叠加本批有依据的正文改动。43V4、196授权中文、原工作树未提交和未知改动保留。

23项文字拒绝测试、17项恢复边界测试、7项发布传输拒绝测试及94片段真实Reader解析通过。完整Python611项无失败、3项跳过，Node730项无失败；lint、typecheck通过。正式站{h['total']}项逐字节HTTP核验全部通过，重试{h['retries']}；36项桌面/手机可见阅读检查（含分话、合辑与旧版回归）及5项状态检查通过。没有为通过验收修改原测试或运行源码。未改L2D、AIO、APK、字体；实机动画未验收。

## 唯一累计记录位置

累计贡献、接手前后记录及完整已处理/待处理清单只在 `{canonical['repository']}:{canonical['entry']}`。本轮累计提交`{cc['commit']}`，19项独立核算检查通过。旧版快照、旧498个剧情ID及以前完整复核证据未清零；游戏贡献界面和原译者署名未修改。Reader与ProgettoMagius-1只保存单批证据及CN patch指针。

下一入口：`{nextid}`（{nexttitle}）。从CN patch重新获取完整队列，刷新三仓main、实际线上版本和中日文blob后继续；不要重复发布3320。
'''
 readerdoc=headline
 fullmd=headline+f'''\n## CN patch核定累计数\n\n确认AI独立片段1079，已完整复核534，余545（已含24个未索引）。接手前48、接手后486，本轮只新增91。旧443份完成证据逐项保留。Reader128个与客户端独有35个仍仅属于来源调查，不擅自计为待重译。\n\n3301至3320已发布实际改动按路径去重：{cs['published_unique_runtime_scripts_modified']}个片段；其中有正文校订的{cs['published_unique_runtime_scripts_with_body_correction']}个，不同正文字段地址{cs['published_unique_body_addresses_corrected']}。字段地址不等于原创翻译句数，运行兼容、原稿恢复、姓名和全文复核分项记录。\n'''
 (W/'Reader_AI_3320_Delivery_20261002.md').write_text(fullmd,encoding='utf8');(W/'Reader_3320_Batch_Receipt.md').write_text(readerdoc,encoding='utf8')
 progress=read('progress.json');progress.update(stage='delivered',closed_at=now,checkpoint='18整话94片段全文对照，91新增/3旧上下文分计，2310正文修订已交付3320、Reader与ADV；累计只在CN patch',active_sessions={},next=['从CN patch当前队列继续确认AI整话，先核验中日文blob与实际生产','累计贡献与全量清单、恢复包仅CN patch','不要重复发布3320，不改官方/确认人工/来源未明稿']);save('progress.json',progress)
 safe=['bootstrap.py','collect.py','stage.py','decisions.py','record_raw.py','review_io.py','view_scripts.py','checkpoint.py','exact_json.py','translation_rules.py','test_translation_rules.py','reader_check.cjs','reader_recovery_contract.cjs','test_reader_recovery.cjs','test_narrator_recovery.cjs','prepare_current_helpers.py','prepare_delivery.py','commit_sources.py','build_package.py','prepare_public.py','publish_scenario_3320.py','test_public_delivery_retry.py','prepare_build.py','run_full_qa.py','prepare_acceptance.py','browser_verify.cjs','accept_live.py','update_census.py','cross_repo_verify.py','queue_contract.py','generate_contributions.py','contribution_ledger.py','verify_contributions.py','commit_records.py','closeout.py','verify_final_state.py','release_after_build.py','progress.json','bases.json','selection.json','review-sources.json','chapters.json','provenance.json','repair-plan.json','text-plan.json','historical-text-baselines.json','validation.json','reader-render-validation.json','missing-display-restoration.json','final-name-refinements.json','reader-commit.json','patch-commit.json','public-commit.json','publisher-run.json','published-package-receipt.json','post-package-version-checks.json','completed-machine-review-evidence.json','current-confirmed-machine-summary.json','cross-repo-machine-summary.json','next-ai-only-full-chapter-queue.json','Reader_AI_Full_Ledger_20261002.json.gz','delivery-state.json','final-receipt.json','Reader_AI_3320_Delivery_20261002.md','contributions-3320-patch-commit.json','context-and-alias-accounting.json','capability-verification.json','browser-targets.json']
 safe+=sorted(f.name for f in W.glob('trusted-*.json'));safe+=sorted(f.name for f in W.glob('decisions-*.json'))
 dep=['build-steps.json','full-check-result.json','source-preservation-before-generation.json','source-preservation-after-generation.json','source-preservation-after-build.json','source-preservation-after-qa.json','online-exact-verification.json','online-exact-plan.json','edge-status-production-verified.json']
 archive=W/'20261002-ai-only-3320-recovery.zip';members=[]
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in safe:assert (W/n).is_file(),n;z.write(W/n,n);members.append(n)
  for n in dep:assert (D/n).is_file(),n;z.write(D/n,'delivery/'+n);members.append('delivery/'+n)
  for folder,glob in [('review','*.edits.json'),('review','*.final.txt'),('review','*.aligned.json'),('contributions-3320','*')]:
   for f in sorted((W/folder).glob(glob)):
    if f.is_file():z.write(f,f.relative_to(W).as_posix());members.append(f.relative_to(W).as_posix())
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(members)
 recovery={'repository':canonical['repository'],'path':'docs/story-quality/recovery/20261002-ai-only-3320.zip','sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'files':len(members),'stored_in_reader':False,'stored_in_public':False};full['recovery']=recovery;save('recovery-metadata.json',recovery);save('final-receipt.json',full)
 pc=commit('patch',{'docs/story-quality/20261002-ai-only-batch08-published.md':fullmd.encode(),'docs/story-quality/20261002-ai-only-batch08-published.json':enc(full),recovery['path']:archive.read_bytes()},'final-handoff')
 root=f'''# Reader剧情质量接续入口\n\n更新：{now}\n\n本批18非重叠整话、94片段5341字段全文对照，91新增/3旧上下文分计，2310正文修订已发布3320。Reader数据`{rev}`；CN patch数据`{p['cn_patch_commit']}`；Reader正式部署`{u['canonical_id']}`，ADV同源。先读`docs/story-quality/20261002-ai-only-batch08-published.md`与`docs/story-quality/CONTINUATION_STATE.json`，不要重发3320。\n\n累计贡献和完整已处理/待处理台账只在CN patch：`{canonical['repository']}:{canonical['entry']}`。完整恢复包只在`{recovery['path']}`。Reader与发行仓不保存累计副本或含累计数据的ZIP。前AI成果、498历史ID与旧快照持续保留。\n\n下一入口`{nextid}`（{nexttitle}）。完整队列从CN patch获取，先刷新三仓main、生产和中日文blob，确认AI才审；不重译官方、人工作品或未知来源。保留43V4、196授权与并行脏树。既有main，不分支PR/强推；不改L2D/AIO/APK/字体。全项目未完成，实机动画未验收。\n\nAgentDock执行和写入、三仓push/admin、实际现有main推送及Cloudflare部署均验证通过；单个只读接口不等于整体只读，不因误判停工。\n\n工作区`{R}`，本批`{W}`，任务tsk_3bc51860c956a005。中途断点和最终回复前更新本入口；Reader只留本批交接与CN patch指针。\n'''
 st=json.loads((R/'docs/story-quality/CONTINUATION_STATE.json').read_bytes());st.update(state,updated_at=now,checkpoint=progress['checkpoint'],active_batch=progress,task_id=progress['task_id'],project_status='long_term_in_progress_AI_only',pending=progress['next'],contribution_storage_policy='CN patch only',contribution_ledger=canonical,contribution_record_requirement=canonical,recovery_bundle=recovery,ai_only_scope={'canonical_repository':canonical['repository'],'entry':canonical['entry'],'census':canonical['census'],'unit':'unique runtime JSON fragment; cumulative counts only in CN patch'},capability_verification=cap,delivery_receipt_commits={'reader_data':rev,'patch_data':p['cn_patch_commit'],'canonical_contributions':cc['commit'],'patch_closeout':pc});st['paths']['current_batch']=str(W)
 st.setdefault('previous_batch_summaries',{})[progress['batch']]={'stage':'delivered','scenario_version':3320,'reader_source_commit':rev,'cn_patch_source_commit':p['cn_patch_commit'],'recovery_reference':recovery}
 cont=(R/'docs/story-quality/CONTINUATION.md').read_text(encoding='utf8');start='<!-- AI-ONLY-BATCH08-START -->';end='<!-- AI-ONLY-BATCH08-END -->';assert start in cont and end in cont;cont=cont[:cont.index(start)]+start+'\n'+root+'\n'+end+cont[cont.index(end)+len(end):]
 rc=commit('reader',{'STORY_QUALITY_HANDOFF.md':root.encode(),'docs/story-quality/CONTINUATION.md':cont.encode(),'docs/story-quality/CONTINUATION_STATE.json':enc(st),'docs/story-quality/20261002-ai-only-batch08.md':readerdoc.encode(),'docs/story-quality/20261002-ai-only-batch08-published.md':readerdoc.encode(),'docs/story-quality/20261002-ai-only-batch08-published.json':enc(core)},'final-handoff');dirty_guard()
 result={'reader':rc,'patch':pc,'contributions_only_patch':cc,'recovery_only_patch':recovery,'runtime_source_unchanged':True,'original_worktree_state_unchanged':True};save('final-handoff-commits.json',result)
 with (W/'Reader_AI_3320_Delivery_20261002.md').open('a',encoding='utf8') as f:f.write('\n最终交接提交：Reader `'+rc+'`；CN patch `'+pc+'`。\n恢复包仅CN patch：`'+recovery['path']+'`，'+str(recovery['files'])+'项文件，SHA256 `'+recovery['sha256']+'`。\n')
 print('FINAL_CN_PATCH_ONLY_HANDOFF_COMPLETE',json.dumps(result,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
