"""Adapt previously inspected good release helpers to frozen batch08 counters. Does not publish."""
from pathlib import Path
import json,re,ast
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch07-ai-only-20261002';R=W.parent/'repo'
def read(n):return (O/n).read_text(encoding='utf8')
def save(n,s):
 if n.endswith('.py'):ast.parse(s)
 (W/n).write_text(s,encoding='utf8')
def swap(s,a,b):assert a in s,a;return s.replace(a,b)
def ver(s):return s.replace('3318','__BASE__').replace('3319','3320').replace('__BASE__','3319').replace('semantic-batch07','semantic-batch08').replace('semantic_batch07','semantic_batch08').replace('AI-ONLY-BATCH07','AI-ONLY-BATCH08').replace('ai-only-batch07','ai-only-batch08')
p=json.loads((W/'repair-plan.json').read_bytes());assert len(p['reader_files'])==91 and p['changed_fields']==2310 and p['reviewed_fields']==5341
s=ver(read('prepare_delivery.py')).replace('==96','==94').replace('==5202','==5341').replace('==3033','==2310').replace('==24','==18').replace("restoredPreviouslyEmptyDisplayFields']==5","restoredPreviouslyEmptyDisplayFields']==0")
s=swap(s,"len(p['reader_files'])==len(p['runtime_files'])==94","len(p['reader_files'])==len(p['runtime_files'])==91")
a=s.index(' anchors=');b=s.index(' inputs=',a)
anchors={'420171-4':['篠目夜鹤','拖挂房车'],'420271-2':['增加了约一成'],'420371-3':['当时的我的推测'],'510010-9_9UlG8':['南凪海'],'510020-9_U7gkv':['新的花朵'],'510204-3_m4VmX':['杀了她'],'510207-4_m4VmX':['地狱之门'],'510208-1_kssXu':['消逝的光芒'],'510208-6_kssXu':['不能死'],'510209-1_kssXu':['媒介'],'510211-5_kssXu':['不受任何魔法少女'],'510213-1_kssXu':['既非生者','光的尽头']}
s=s[:a]+f" anchors={anchors!r}\n for sid,terms in anchors.items():\n  text=(W/'review'/(sid+'.final.txt')).read_text(encoding='utf8').replace('@','')\n  for term in terms:assert term in text,(sid,term)\n context=[x for x in source if x.get('already_complete_context_only')];assert len(context)==3 and sum(x['cn_fields'] for x in context)==186\n for x in context:\n  assert not decisions[x['id']]['edits'] and x['cn_path'] not in changed\n  assert blob((W/'stage/reader'/x['cn_path']).read_bytes())==x['cn_sha']\n"+s[b:]
s=s.replace("'indexed_chapters_complete':24","'indexed_chapters_complete':18").replace("'scenes_full_read':96","'scenes_full_read':94").replace("'complete_scenes_reviewed':96","'complete_scenes_reviewed':94,'new_complete_scenes':91,'previous_complete_context_scenes':3,'new_reviewed_fields':5155,'context_fields':186").replace("'display_fields_reviewed':5202","'display_fields_reviewed':5341").replace("'display_fields_revised':3033","'display_fields_revised':2310").replace("'actual_reader_parser_files':96","'actual_reader_parser_files':94").replace("'restored_previously_empty_display_fields':5","'restored_previously_empty_display_fields':0")
s=re.sub(r"'restored_display_explanation':'[^']*'","'restored_display_explanation':'No new previously-empty Reader display event. Existing missing/mistranslated visible words are corrected inside already displayed fields; execution identities preserved.'",s)
s=s.replace("'trusted_term_evidence':read('trusted-names.json')","'trusted_term_evidence':{f.name:json.loads(f.read_bytes()) for f in W.glob('trusted-*.json')}")
a=s.index(' report=f');b=s.index(" folder='manifests/",a)
s=s[:a]+''' report=f"""# Batch08 validated sources before3320

18 non-overlapping primary chapters,94 independent scripts,5341 body fields read in full against Japanese.91 newly completed scripts/5155 fields and3 unchanged previously-complete context scripts/186 fields.2310 body corrections in91 scripts,0 speaker-label or execution-layout changes. Two overlapping event compilation routes are synchronized but never counted as new physical scripts. No new previously-empty display events.

Sudachi/Rei/Nanaka Memory Museum, all20 segments of event5100 and all62 segments of event5102. Preserve accurate prior translations, original authorship, progressive revelations, uncertainty and causal order.40 paired TXT files,7738 exact physical spans,25 complete historical section baselines. Full-section matching only; no fuzzy alignment.23 translation and17 recovery refusal tests plus actual parser checks for all94 scripts.43V4,196authorized sources and unrelated dirty files preserved.

Cumulative contribution and full processed/pending inventories remain ONLY in HiiragiNemu/magireco-cn-patch. This is single-batch evidence, not publication or device verification. No L2D/AIO/APK/font changes.
"""
'''+s[b:]
s=s.replace("checkpoint='24整话96片段5202字段完整复核，3033正文修訂与5条既有漏拟声恢复、48TXT通过验证；待两仓main和3320/Reader/ADV交付'","checkpoint='18整话94片段5341字段完整复核，91新增和3旧上下文分开；2310正文修订/40TXT精确同步通过验证，待3320/Reader/ADV交付'")
s=s.replace('including explicit labels and one recovered lost utterance','including unchanged previously-complete context without double counting');save('prepare_delivery.py',s)
s=ver(read('commit_sources.py'));a=s.index("  message='");b=s.index('\n  commit=',a);s=s[:a]+"  message='fix(story): review18 AI chapters,91 new full scenes and2310 body corrections [stage-only] [skip ci]\\n\\n94 scripts/5341 fields read,3 prior complete context scripts unchanged. No new display events, speaker labels, execution nodes or audio changes. Preserve43V4/196authorized and unknown worktree edits.\\n'"+s[b:]
s=s.replace("payload={f.relative_to(root).as_posix():f.read_bytes() for f in root.rglob('*') if f.is_file()}","payload={f.relative_to(root).as_posix():f.read_bytes() for f in root.rglob('*') if f.is_file() and blob(f.read_bytes())!=baseline.get(f.relative_to(root).as_posix())}")
s=swap(s,"assert payload and not any(x.endswith('.pyc') for x in payload)","assert payload and not any(x.endswith('.pyc') for x in payload)\n assert not any('/contributions/' in x or 'ai-only-census' in x for x in payload)");save('commit_sources.py',s)
s=ver(read('build_package.py')).replace('len(specs)==96','len(specs)==91').replace('==3033','==2310').replace('>=635','>=731').replace('changed_runtime_scripts=96','changed_runtime_scripts=91').replace('full_scenes_read=96','full_scenes_read=94').replace('reviewed_complete_scenes=96','reviewed_complete_scenes=94,new_complete_scenes=91,previous_complete_context_scenes=3,new_reviewed_fields=5155,context_fields=186').replace('complete_indexed_chapters=24','complete_indexed_chapters=18').replace('reviewed_fields=5202','reviewed_fields=5341').replace('changed_chinese_fields=3033','changed_chinese_fields=2310').replace('body_fields_changed=3033','body_fields_changed=2310').replace('restored_previously_empty_display_fields=5','restored_previously_empty_display_fields=0').replace('reviewed_execution_identities_preserved=96','reviewed_execution_identities_preserved=94')
s=s.replace('Ninety-six machine-origin scene reads, twenty-four complete indexed chapters','Ninety-four reads,91 new complete scenes,18 nonoverlapping chapters');save('build_package.py',s)
s=ver(read('prepare_public.py')).replace('==3033','==2310').replace("'changed_runtime_scripts':96","'changed_runtime_scripts':91").replace("'full_scenes_read':96","'full_scenes_read':94").replace("'complete_scenes_reviewed':96","'complete_scenes_reviewed':94,'new_complete_scenes':91,'previous_complete_context_scenes':3").replace("'complete_indexed_chapters':24","'complete_indexed_chapters':18").replace("'reviewed_fields':5202","'reviewed_fields':5341").replace("'changed_fields':3033","'changed_fields':2310").replace("'body_fields_changed':3033","'body_fields_changed':2310").replace('twenty-four','eighteen').replace('24整话96脚本的3033','18整话91新增脚本的2310')
s=s.replace("'test_translation_rules.py')","'test_translation_rules.py','test_public_delivery_retry.py')");save('prepare_public.py',s)
s=ver(read('publish_scenario_3319.py')).replace("plan['changed_runtime_scripts']==96","plan['changed_runtime_scripts']==91").replace("plan['reviewed_fields']==5202","plan['reviewed_fields']==5341").replace("plan['changed_fields']==3033","plan['changed_fields']==2310").replace("plan['complete_scenes_reviewed']==96","plan['complete_scenes_reviewed']==94")
a=s.index("'body':'Twenty-four");b=s.index("','draft':False",a)
s=s[:a]+"'body':'18 non-overlapping chapters;94 full bilingual scene reads/5341 fields,including3 unchanged previously-complete context scenes.91 new completed scenes and2310 body corrections.40 paired exports including2 compilation aliases synchronized exactly; no duplicate contribution counting. No new display events,speaker labels,commands,actors,audio or execution-layout changes.43V4 and196authorized sources preserved. Cumulative contribution inventory only in CN patch. Model-assisted review is not original human authorship. Device gameplay not verified."+s[b:];s=s.replace('twenty-four complete','eighteen complete');save('publish_scenario_3320.py',s)
s=ver(read('test_public_delivery_retry.py'));save('test_public_delivery_retry.py',s)
for n in ['prepare_build.py','run_full_qa.py','inspect_publisher.py','cross_repo_verify.py','queue_contract.py','release_after_build.py','verify_final_state.py']:
 s=ver(read(n)) if n not in ['cross_repo_verify.py','queue_contract.py','run_full_qa.py'] else read(n)
 if n=='inspect_publisher.py':s=s.replace("==3033","==2310").replace("==96","==94")
 save(n,s)
s=ver(read('commit_records.py')).replace("==443","==534")
s=s.replace("for n in ['20261001-ai-only-census.json.gz','20261002-ai-only-census.json.gz']","for n in ['20261001-ai-only-census.json.gz','20261002-ai-only-census.json.gz']")
s=s.replace("assert json.loads(oldsnap)['last_published_scenario_version']==3319","assert json.loads(oldsnap)['last_published_scenario_version']==3319");save('commit_records.py',s)
s=ver(read('generate_contributions.py')).replace('==443','==534').replace('==636','==545').replace('==395','==486');save('generate_contributions.py',s)
# The canonical generator is in CN patch. No duplicated generator in Reader/public.
import subprocess
for target,source in [('contribution_ledger.py','tools/story_quality_contributions.py'),('verify_contributions.py','tools/verify_story_quality_contributions.py')]:
 s=subprocess.check_output(['git','--git-dir=A:/StoryQuality-20260930-1739/patch.git','show','FETCH_HEAD:'+source],cwd=R).decode('utf8');save(target,s)
# Check all94 through the actual parser, including the3 unchanged context scenes.
f=W/'reader_check.cjs';s=f.read_text(encoding='utf8');old='for (const file of plan.reader_files) {';assert old in s
s=s.replace(old,"const sources=JSON.parse(fs.readFileSync(path.join(__dirname,'review-sources.json')));\n  const files=sources.map(s=>plan.reader_files.find(f=>f.path===s.cn_path)||{path:s.cn_path,before:s.cn_sha,operations:[]});\n  for (const file of files) {");f.write_text(s,encoding='utf8')
(W/'final-name-refinements.json').write_text(json.dumps({'scope':'All94 scenes fully read; named corrections and references retained in per-scene notes and trusted-*.json','context_preserved':['420171-1','420171-2','420171-3'],'missing_display_events':0,'targeted_remaining_suspects':[]},ensure_ascii=False,indent=2),encoding='utf8')
print('CURRENT_HELPERS_READY_NO_PUBLICATION')
