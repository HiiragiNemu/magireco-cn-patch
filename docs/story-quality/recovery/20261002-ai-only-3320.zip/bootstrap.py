"""Freeze this batch from canonical CN patch data; copied helpers are inspected before use."""
from pathlib import Path
import json,gzip,subprocess,ast,re,datetime,urllib.request,hashlib
W=Path(__file__).resolve().parent;R=W.parent/'repo';O=W.parent/'semantic-batch07-ai-only-20261002'
def git(repo,*args):return subprocess.check_output(['git',*(['--git-dir=A:/StoryQuality-20260930-1739/'+repo+'.git'] if repo!='reader' else []),*args],cwd=R,timeout=150)
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def save(n,d):(W/n).write_bytes(enc(d))
heads={r:git(r,'rev-parse','FETCH_HEAD').decode().strip() for r in ['reader','patch','public']};assert heads['reader']==git('reader','rev-parse','HEAD').decode().strip()
c=json.loads(gzip.decompress(git('patch','show',heads['patch']+':docs/story-quality/20261002-ai-only-census.json.gz')));assert c['summary']['complete']==443 and c['summary']['remaining']==636
save('baseline-census.json',c)
ids=['420171','420271','420371','510010','510020']+[str(x) for x in range(510201,510214)]
q={x['story_id']:x for x in c['next_full_chapter_queue']['queue']};assert all(i in q for i in ids)
paths=[s['path'] for i in ids for s in q[i]['sources']];assert len(paths)==len(set(paths))==94
save('selection.json',{'ids':ids,'chapters':18,'unique_scripts':94,'new_pending_scripts':sum(not s['complete'] for i in ids for s in q[i]['sources']),'reported_fields':sum(q[i]['fields'] for i in ids),'aggregate_routes_excluded_from_new_work_counts':['510201-09','510210-13'],'prior_complete_context_scripts':[s['path'] for i in ids for s in q[i]['sources'] if s['complete']]})
for n in ['collect.py','stage.py','decisions.py','record_raw.py','review_io.py','exact_json.py','translation_rules.py','test_translation_rules.py','reader_check.cjs','reader_recovery_contract.cjs','test_reader_recovery.cjs','test_narrator_recovery.cjs','sync_text.py','checkpoint.py']:
 s=(O/n).read_text(encoding='utf8').replace('semantic-batch07','semantic-batch08').replace('semantic_batch07','semantic_batch08').replace('AI-ONLY-BATCH07','AI-ONLY-BATCH08').replace('ai-only-batch07','ai-only-batch08')
 if n=='collect.py':
  s=re.sub(r'^SELECTED=.*$', 'SELECTED='+repr(ids),s,flags=re.M)
  s=s.replace("PREVIOUS=ROOT/'semantic-batch06-ai-only-20261002'","PREVIOUS=ROOT/'semantic-batch07-ai-only-20261002'")
  s=s.replace("CONFIRMED={x['path']:x for x in json.loads((PREVIOUS/'current-confirmed-machine-ledger.json').read_bytes())}","CONFIRMED={x['path']:x for x in json.loads((W/'baseline-census.json').read_bytes())['scripts']}")
  s=s.replace("assert not proof['complete'] and proof['machine_output_pair_count']>0","assert proof['machine_output_pair_count']>0\n   assert not proof['complete'] or sid=='420171','Previously completed scenes only read for full-chapter context'")
  s=s.replace("'provenance':{'report_commit'","'already_complete_context_only':proof['complete'],'provenance':{'report_commit'")
  s=s.replace('==3318','==3319').replace("'target_version':3319","'target_version':3320").replace('tsk_5e7fda84b1837188','tsk_3bc51860c956a005').replace('Frozen 24 complete','Frozen 18 complete')
 if n=='checkpoint.py':
  s=s.replace('3319','NEXT_VER_MARK').replace('3318','3319').replace('NEXT_VER_MARK','3320')
 if n.endswith('.py'):ast.parse(s)
 (W/n).write_text(s,encoding='utf8')
receipt=json.loads(git('public','show',heads['public']+':story-quality/releases/3319.json'));assert receipt['status']=='published_and_anonymously_verified'
checks=[]
for url in ['https://magireco-personal-release.pages.dev/version_scenario.json','https://github.com/HiiragiNemu/ProgettoMagius-1/releases/download/latest/version_scenario.json','https://magireader.pages.dev/adv-release-build.json','https://magireader.pages.dev/api/adv/release']:
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Story-3320-preflight','Accept-Encoding':'identity'}),timeout=90) as resp:d=json.load(resp);assert resp.status==200
 checks.append({'url':url,'status':200,'data':d})
for x in checks[:2]:assert x['data']=={'version':3319,'size':receipt['package']['size'],'md5':receipt['package']['md5']}
for x in checks[2:]:assert x['data']['source_revision']==receipt['reader_commit']
for repo in ['reader','public']:
 paths=git(repo,'ls-tree','-r','--name-only',heads[repo]).decode().splitlines();assert not any(p.startswith('docs/story-quality/contributions/') for p in paths)
save('preflight.json',{'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'heads':heads,'live':checks,'previous_receipt':receipt,'sole_ledger_storage_verified':True,'shell_execution':True,'local_write_read_roundtrip':json.loads((W/'selection.json').read_bytes())['unique_scripts']==94,'service_config_change_required':False})
print('CURRENT_PRODUCTION',3319,receipt['reader_commit'],'HEADS',heads,flush=True)
print('SELECTED',json.dumps(json.loads((W/'selection.json').read_bytes()),ensure_ascii=False),flush=True)
