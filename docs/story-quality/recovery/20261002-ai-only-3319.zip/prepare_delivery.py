"""Validate the fully read AI-only batch, including explicit labels and one recovered lost utterance."""
from pathlib import Path
import sys,json,gzip,hashlib,subprocess,datetime
W=Path(__file__).resolve().parent;ROOT=W.parent;R=ROOT/'repo'
sys.path[:0]=[str(W),str(ROOT/'semantic-batch03-20261001'),str(ROOT/'control-authority-20260930'),str(ROOT/'severe-5109-20261001')]
from exact_json import apply,blob
from translation_rules import validate,execution_tokens,color_types
from collect_review import fields
from census import Store
S=Store()
def read(n):return json.loads((W/n).read_bytes())
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def save(n,x):(W/n).write_bytes(enc(x))
def main():
 p=read('repair-plan.json');t=read('text-plan.json');rt=read('reader-tree.json');pt=read('patch-tree.json');render=read('reader-render-validation.json');source=read('review-sources.json')
 assert len(source)==len(p['reviewed_stories'])==len(p['completed_review_stories'])==96 and not p['pending_adjudication_stories']
 assert len(p['reader_files'])==len(p['runtime_files'])==96 and p['reviewed_fields']==5202 and p['changed_fields']==3033
 assert len({s['chapter_id'] for s in source})==24 and sum(s['cn_fields'] for s in source)==5202
 assert render['passed'] and render['actualParser'] and len(render['files'])==96 and render['restoredPreviouslyEmptyDisplayFields']==5
 assert not t['holds'] and not t['missing']
 tests=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(W),'-p','test_translation_rules.py','-v'],cwd=W,capture_output=True,text=True,encoding='utf8');(W/'translation-tests.log').write_text(tests.stdout+tests.stderr,encoding='utf8');assert tests.returncode==0 and 'Ran 23 tests' in tests.stderr
 tests2=subprocess.run(['node','--test',str(W/'test_reader_recovery.cjs'),str(W/'test_narrator_recovery.cjs')],cwd=W,capture_output=True,text=True,encoding='utf8');(W/'reader-recovery-tests.log').write_text(tests2.stdout+tests2.stderr,encoding='utf8');assert tests2.returncode==0 and 'tests 17' in tests2.stdout and 'fail 0' in tests2.stdout
 decisions={s['id']:read('review/'+s['id']+'.edits.json') for s in source};names=0;body=0;placeholders=0
 for s in source:
  d=decisions[s['id']];assert d['reviewed_all_fields'] and d['source_cn_blob']==s['cn_sha'] and d['source_jp_blob']==s['jp_sha'] and d['field_count']==s['cn_fields']
 for f in p['reader_files']:
  a=(W/'originals/reader'/f['path']).read_bytes();b=(W/'stage/reader'/f['path']).read_bytes();d=decisions[Path(f['path']).stem]
  allowed=[[x['address'],x['before'],x['after']] for x in d.get('name_edits',[])];names+=len(allowed);body+=len(f['operations'])-len(allowed)
  assert blob(a)==f['before'] and blob(b)==f['after'];validate(a,b,f['operations'],allowed_name_operations=allowed);assert apply(b,[[at,new,old] for at,old,new in f['operations']])==a
  af,bf=fields(json.loads(a)),fields(json.loads(b));assert len(af)==len(bf)
  for x,y in zip(af,bf):
   assert x['address']==y['address'] and x['text'].count('userName')==y['text'].count('userName');placeholders+=x['text'].count('userName')
   assert execution_tokens(x['text'])==execution_tokens(y['text']) and color_types(x['text'])==color_types(y['text'])
 assert body==3033 and names==0
 for f in t['files']:
  a=S.get(f['before']);b=(W/'stage/reader'/f['path']).read_bytes();assert blob(b)==f['after'];bom=b'\xef\xbb\xbf' if b.startswith(b'\xef\xbb\xbf') else b'';undo=b[len(bom):].decode()
  for e in sorted(f['edits'],key=lambda x:x['after_start'],reverse=True):
   assert undo[e['after_start']:e['after_end']]==e['after_text'];undo=undo[:e['after_start']]+e['before_text']+undo[e['after_end']:]
  assert bom+undo.encode()==a
 authorized=json.loads((R/'docs/reader-availability-local-20260929.json').read_bytes())['protected_source_failure']['paths'];assert len(authorized)==196
 changed={x['path'] for x in p['reader_files']}|{x['path'] for x in t['files']};assert not set(authorized)&changed
 for path in authorized:assert blob((R/path).read_bytes())==rt[path]
 v4=json.loads((R/'manifests/authoritative_scenario_runtime_repairs.v1.json').read_bytes())['entries'];assert len(v4)==43;protected={}
 for f in v4:
  path=f['target_path'];assert path not in changed and blob((R/path).read_bytes())==rt[path]
  peer=[z for z in pt if z.startswith('madomagi/resource/scenario/json/adv/') and Path(z).name==Path(path).name];assert len(peer)==1;protected[peer[0]]=pt[peer[0]]
 assert not set(protected)&{f['path'] for f in p['runtime_files']}
 for path,h in read('dirty-tracked-hashes.json').items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==h
 anchors={'340271-2':['我们在场的话'],'340272-4':['留下一'], '340281-2':['三只'],'340361-2':['大一轮'],'340362-3':['霞一华'],'340612-3':['爱实'],'340613-3':['为了保护弱者'],'340623-4':['点心'],'341213-1':['灵魂'],'341221-3':['弗雷什']}
 anchors.pop('340272-4')
 for sid,terms in anchors.items():
  text=(W/'review'/(sid+'.final.txt')).read_text(encoding='utf8').replace('@','')
  for term in terms:assert term in text,(sid,term)
 inputs=p['inputs']|t.get('inputs',{})
 for path in authorized:inputs[path]=rt[path]
 for f in v4:inputs[f['target_path']]=rt[f['target_path']]
 for path in ['docs/reader-availability-local-20260929.json','manifests/authoritative_scenario_runtime_repairs.v1.json']:inputs[path]=rt[path]
 save('reader-inputs.json',inputs);save('protected-v4.json',protected)
 now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 v={'schema':3,'batch':p['batch'],'validated_at':now,'indexed_chapters_complete':24,'scenes_full_read':96,'complete_scenes_reviewed':96,'pending_source_adjudication':[],'display_fields_reviewed':5202,'display_fields_revised':3033,'body_fields_revised':body,'explicit_speaker_label_repairs':names,'display_only':True,'exact_reverse_to_original_bytes':True,'nontext_structure_actor_identity_and_audio_unchanged':True,'AI_import_source_verified':True,'executable_tags_and_highlight_types_unchanged':True,'player_name_placeholders_preserved':placeholders,'actual_reader_parser_files':96,'actual_reader_events_and_audio_metadata_unchanged_except_source_proven_missing_display':True,'restored_previously_empty_display_fields':5,'restored_display_explanation':'Five existing narration SFX strings erased by machine translation restored from exact Japanese and initial fallback log. Original nodes, sound controls and staged actors unchanged; validated with strict narrator and character refusal contracts.','specialized_tests_passed':23,'additional_missing_display_contract_tests':17,'reader_txt_files':len(t['files']),'reader_txt_field_spans':t['physical_field_span_edits'],'historical_full_section_baselines':len(read('historical-text-baselines.json')),'multiline_artifact_spans':t['multiline_artifact_spans'],'txt_missing_fields':0,'txt_alignment_holds':0,'protected_v4_unchanged':43,'protected_authorized_cn_unchanged':196,'unrelated_dirty_paths_unchanged':True,'review_method':p['review_method'],'official_or_human_provenance_not_asserted':True,'published':False,'whole_corpus_complete':False,'device_gameplay_verified':False}
 save('validation.json',v)
 evidence={'validation':v,'plan':p,'text_plan':t,'historical_baselines':read('historical-text-baselines.json'),'decisions':decisions,'provenance':read('provenance.json'),'chapters':read('chapters.json'),'explicit_name_repairs':[],'missing_display_restoration':read('missing-display-restoration.json'),'second_pass':read('final-name-refinements.json'),'trusted_term_evidence':read('trusted-names.json')}
 report=f"""# AI-only batch07: source validation before3319

24 complete chapters /96 independent runtime scripts /5202 original body fields read in full against Japanese.3033 body corrections,0 speaker-label edits. Five existing sound-effect narration texts erased by machine output are restored from the exact Japanese and import fallback log; no new execution node, control, sound or staged actor.23 translation refusal tests plus17 recovery refusal tests and real Reader parser checks pass.

Lapine,Tart Final,Perenelle,Tsubaki,Chisato,Takina,Isabeau witch-version and Isabeau: three chapters each. Only confirmed machine-origin scripts; official/human and unresolved provenance excluded. Correct inherited wording retained; no source authorship reclassification.

JSON and TXT updates are exactly reversible. {len(t['files'])} paired TXT files with {t['physical_field_span_edits']} exact field spans synchronized using complete-section matching, including validated historical baselines.43V4,196authorized Chinese sources and unrelated dirty files preserved.

Cumulative contributions and complete processed/pending inventories are kept ONLY in HiiragiNemu/magireco-cn-patch:docs/story-quality/contributions/. Reader and ProgettoMagius-1 keep references and this single-batch delivery evidence, not duplicate cumulative ledgers. This validation is not a publication receipt. Device animation remains unverified.
"""
 folder='manifests/story_quality_semantic_batch07_ai_only_20261002';files={folder+'.json':enc(v),folder+'_evidence.json.gz':gzip.compress(enc(evidence),mtime=0),'docs/story-quality/20261002-semantic-batch07-validated.md':report.encode()}
 for repo in ['reader','patch']:
  for path,b in files.items():q=W/'stage'/repo/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 for f in (W/'review').glob('*.final.txt'):
  q=W/'stage/reader/docs/story-quality/reviewed/20261002-semantic-batch07-ai-only'/f.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
 progress=read('progress.json');progress.update(stage='validated',validation=v,checkpoint='24整话96片段5202字段完整复核，3033正文修訂与5条既有漏拟声恢复、48TXT通过验证；待两仓main和3319/Reader/ADV交付',next=['仅既有main提交新文字','3318基线发行3319并读回普通玩家入口','独立干净Reader构建测试部署与ADV登记','累计贡献和全量清单只提交CN patch']);save('progress.json',progress);S.close();print('VALIDATED',json.dumps(v,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
