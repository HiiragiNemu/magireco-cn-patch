const test=require('node:test'),assert=require('node:assert/strict');const {applyProvenRecovery}=require('./reader_recovery_contract.cjs');
function sample(){const a={story:{group_1:[{textRight:'[se:123]'}]}};const j={story:{group_1:[{textRight:'[se:123]きゃっきゃ'}]}};const address=['story','group_1',0,'textRight'];const f={path:'a.json',before:'oldsha',operations:[[address,'[se:123]','[se:123]咯咯']]};const p={path:'a.json',cn_blob:'oldsha',actor_id:1,jp_actor_id:1,address,before:'[se:123]',japanese:'[se:123]きゃっきゃ',after:'[se:123]咯咯',original_machine_log_match:[{japanese:'[se:123]きゃっきゃ',chinese:'[se:123]'}]};return {a,j,f,p};}
function run(s){const expected=structuredClone(s.a);applyProvenRecovery(expected,s.a,s.j,s.f,s.p);return expected;}
test('exact source-erased speech restored without adding source command',()=>{const s=sample();assert.equal(run(s).story.group_1.length,1);assert.equal(run(s).story.group_1[0].textRight,'[se:123]咯咯');assert.equal(s.a.story.group_1[0].textRight,'[se:123]');});
test('new address rejected',()=>{const s=sample();s.p.address[2]=1;assert.throws(()=>run(s));});
test('nonempty old speech cannot masquerade as recovery',()=>{const s=sample();s.a.story.group_1[0].textRight=s.p.before='[se:123]旧';assert.throws(()=>run(s));});
test('empty Japanese source rejected',()=>{const s=sample();s.j.story.group_1[0].textRight=s.p.japanese='[se:123]';assert.throws(()=>run(s));});
test('changed actor rejected',()=>{const s=sample();s.p.jp_actor_id=2;assert.throws(()=>run(s));});
test('changed executable tag rejected',()=>{const s=sample();s.p.after='[se:124]咯咯';assert.throws(()=>run(s));});
test('unreviewed operation rejected',()=>{const s=sample();s.f.operations=[];assert.throws(()=>run(s));});
test('missing provenance log rejected',()=>{const s=sample();s.p.original_machine_log_match=[];assert.throws(()=>run(s));});
test('wrong frozen source rejected',()=>{const s=sample();s.p.cn_blob='other';assert.throws(()=>run(s));});
