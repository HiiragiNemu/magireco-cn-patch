"""Current-source and all previous published-target acceptance; run after build's initial source guard."""
from pathlib import Path
import json,ast
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch06-ai-only-20261002';D=W/'delivery'
rev=json.loads((W/'reader-commit.json').read_bytes())['commit'];assert (D/'source-revision.txt').read_text().strip()==rev
p=D/'deploy_verified_snapshot.py';s=p.read_text(encoding='utf8');old="assert changed and set(changed)<=allowed,'Non-handoff source changed after build'";assert old in s
s=s.replace(old,"assert changed and all(p=='STORY_QUALITY_HANDOFF.md' or p.startswith('docs/story-quality/') for p in changed),'Non-handoff source changed after build'");ast.parse(s);p.write_text(s,encoding='utf8')
assert (D/'source-preservation-after-build.json').exists(),'Do not race before-generation target writer'
old=json.loads((O/'delivery/online-verification-targets.json').read_bytes());plan=json.loads((W/'repair-plan.json').read_bytes());text=json.loads((W/'text-plan.json').read_bytes())
old.update(source_revision=rev,changed_paths=sorted(set(old['changed_paths'])|{x['path'] for x in plan['reader_files']}),committed_txt_paths=sorted(set(old['committed_txt_paths'])|{x['path'] for x in text['files'] if x['path'].startswith('website/public/')}))
(D/'online-verification-targets.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
s=(O/'browser_verify.cjs').read_text(encoding='utf8');a=s.index('const targets=');b=s.index('.map(([sid,text])',a)
targets=[['340271-2','我们在场的话'],['340272-4','唰！'],['340273-2','唰！'],['340283-3','感受到了珍妮特'],['340292-4','无法指望'],['340293-4','只属于我的贤者之石'],['340361-2','大一轮'],['340363-4','赖子妈妈'],['340612-3','爱实'],['340613-3','为了保护弱者'],['340621-2','员工餐'],['340623-4','我留着的点心'],['341212-4','法国就这样被一分为二'],['341221-3','弗雷什'],['341222-4','里舍蒙'],['311133-4','明日香的表妹']]
for sid,t in targets:
 if (W/'review'/(sid+'.final.txt')).exists():assert t in (W/'review'/(sid+'.final.txt')).read_text(encoding='utf8').replace('@',''),(sid,t)
s=s[:a]+'const targets='+json.dumps(targets,ensure_ascii=False)+s[b:];s=s.replace('results.length===24','results.length===32');(W/'browser_verify.cjs').write_text(s,encoding='utf8')
s=(O/'accept_live.py').read_text(encoding='utf8').replace("b['checks']==24","b['checks']==32").replace("'BROWSER_PASS',24","'BROWSER_PASS',32");ast.parse(s);(W/'accept_live.py').write_text(s,encoding='utf8')
print('ACCEPTANCE_READY',len(targets)*2,'browser checks',len(old['changed_paths']),'source targets',len(old['committed_txt_paths']),'web texts',flush=True)
