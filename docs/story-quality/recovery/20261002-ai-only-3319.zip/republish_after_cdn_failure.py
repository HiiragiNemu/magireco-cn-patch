"""Commit the bounded transport-only publisher repair after verified3318 rollback."""
from pathlib import Path
import sys,json,subprocess,urllib.request,base64,hashlib
W=Path(__file__).resolve().parent;R=W.parent/'repo';sys.path.insert(0,str(W.parent));from closeout_reader import api,commit_files
repo='HiiragiNemu/ProgettoMagius-1';prefix='story-quality/20261002-semantic-batch07-ai-only/'
first=json.loads((W/'public-commit.json').read_bytes());run=json.loads((W/'publisher-run.json').read_bytes());assert run['conclusion']=='failure'
oldp=(W/'publisher-before-network-retry.py.txt').read_bytes();live=api(repo,'contents/'+prefix+'publish_scenario_3319.py?ref=main');assert base64.b64decode(live['content'])==oldp,'Publisher changed concurrently'
with urllib.request.urlopen('https://github.com/'+repo+'/releases/download/latest/version_scenario.json',timeout=60) as r:v=json.load(r)
assert v=={'version':3318,'size':193607913,'md5':'82c59f550c988ac32b289faa27212238'},v
latest=api(repo,'releases/tags/latest');assets=api(repo,'releases/'+str(latest['id'])+'/assets?per_page=100');a={x['name']:x for x in assets};assert a['cn_scenario_update.zip']['digest']=='sha256:73f3ad012ad63ee8955edfb646a713c2294d1ac2e97aa77d5e10e260336b95e6'
arch=api(repo,'releases/tags/scenario-3319');aa={x['name']:x for x in api(repo,'releases/'+str(arch['id'])+'/assets?per_page=100')};assert aa['cn_scenario_update.zip']['digest']=='sha256:17f67f928bfaa445fe28a3b6e8b8cd92ea9a4d59b5a10b10a8b82ebed35f4afd'
subprocess.run(['python','-X','utf8',str(W/'test_public_delivery_retry.py')],cwd=W,check=True,timeout=120)
files={prefix+'publish_scenario_3319.py':(W/'publish_scenario_3319.py').read_bytes(),prefix+'test_public_delivery_retry.py':(W/'test_public_delivery_retry.py').read_bytes()}
c=commit_files(repo,files,'fix(release): keep ordinary-byte gate closed through stale CDN redirects')
(W/'public-first-attempt.json').write_text(json.dumps({'source':first,'run':run,'ordinary_version_after_rollback':v,'base_archive_sha256':a['cn_scenario_update.zip']['digest'],'immutable3319_sha256':aa['cn_scenario_update.zip']['digest'],'cause':'Ordinary mutable URL returned partial/old bytes, then stale redirect404;3319 gate never opened;3318 restored','repair':'Catch transport failures within existing bounded ordinary-URL hash verification; no cache-bust/auth bypass'},ensure_ascii=False,indent=2),encoding='utf8')
first['commit']=c;first['network_retry_only']=True;(W/'public-commit.json').write_text(json.dumps(first,indent=2),encoding='utf8');print('RETRY_PUBLISHER_COMMITTED',c,flush=True)
