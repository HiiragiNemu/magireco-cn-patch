"""Keep the ordinary-URL byte gate closed through transient stale redirects; no weaker acceptance."""
from pathlib import Path
import ast
W=Path(__file__).resolve().parent;p=W/'publish_scenario_3319.py';s=p.read_text(encoding='utf8');a=s.index('  for attempt in range(13):');b=s.index(" print('ANONYMOUS_VERIFIED'",a)
old=s[a:b];(W/'publisher-before-network-retry.py.txt').write_text(s,encoding='utf8')
new='''  for attempt in range(13):
   error=None;actual=None
   try:
    download(assets[p.name]['browser_download_url'],target)
    actual=identity(target)
   except (urllib.error.URLError,TimeoutError,OSError) as exc:
    error=type(exc).__name__
   if error is None and actual==expected:break
   print('PUBLIC_URL_NOT_YET_CONSISTENT',tag,p.name,attempt+1,
         'expected',expected,'received',actual,'transport_error',error,flush=True)
   # A stale redirect can return404 while the new API asset is already live.
   # Always revalidate the intended asset identity before bounded retry.
   current=api.assets(api.call('releases/tags/'+tag))
   if current.get(p.name,{}).get('digest')!='sha256:'+expected['sha256']:
    raise RuntimeError('Release changed during public verification: '+p.name)
   if attempt==12:raise RuntimeError('Ordinary public URL did not converge: '+p.name)
   time.sleep(10)
'''
s=s[:a]+new+s[b:];ast.parse(s);p.write_text(s,encoding='utf8')
print('ORDINARY_URL_GATE_NETWORK_RETRY_FIXED_WITHOUT_RELAXING_HASHES')
