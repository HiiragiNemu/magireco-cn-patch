"""Extend the existing confirmed-AI ledger only with current-blob-bound complete reads."""
from pathlib import Path
import json,gzip,datetime,copy,sys
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch06-ai-only-20261002'
sys.path.insert(0,str(W));from commit_sources import git,tree

def read(p):return json.loads(p.read_bytes())
def save(n,d):(W/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def main():
 base=read(W/'bases.json')['patch'];old=json.loads(gzip.decompress(git('patch','show',base+':docs/story-quality/20261002-ai-only-census.json.gz')))
 rows=copy.deepcopy(old['scripts']);assert len(rows)==1079 and sum(x['complete'] for x in rows)==347
 selected={x['cn_path']:x for x in read(W/'review-sources.json')};assert len(selected)==96
 plan=read(W/'repair-plan.json');changes={x['path']:x for x in plan['reader_files']};assert len(changes)==96
 revs={r:read(W/(r+'-commit.json'))['commit'] for r in ['reader','patch']}
 trees={r:tree(r,revs[r]) for r in revs};rt=trees['reader'];frozen=read(W/'reader-tree.json')
 proof={x['path']:copy.deepcopy(x) for x in old['completed_evidence']};assert len(proof)==347
 now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 for row in rows:
  path=row['path'];assert frozen[path]==row['current_blob'];assert rt[row['jp_path']]['sha']==row['jp_blob']
  assert rt[path]['sha']==(changes[path]['after'] if path in changes else row['current_blob'])
  if path in selected:
   assert not row['complete'] and row['machine_output_pair_count']>0
   s=selected[path];d=read(W/'review'/(s['id']+'.edits.json'))
   assert d['reviewed_all_fields'] and d['source_cn_blob']==row['current_blob'] and d['source_jp_blob']==row['jp_blob'] and d['field_count']==s['cn_fields']
   row.update(current_blob=rt[path]['sha'],complete=True,status='machine_origin_full_review_complete')
   proof[path]={'path':path,'cn_blob':row['current_blob'],'jp_path':row['jp_path'],'jp_blob':row['jp_blob'],'evidence':{'batch':plan['batch'],'source_commit':revs['reader'],'report':'manifests/story_quality_semantic_batch07_ai_only_20261002_evidence.json.gz','script_id':s['id'],'full_fields':s['cn_fields']}}
  if row['complete']:
   assert path in proof and proof[path]['cn_blob']==row['current_blob'] and proof[path]['jp_blob']==row['jp_blob']
 assert set(selected)<={x['path'] for x in rows}
 complete={x['path'] for x in rows if x['complete']};assert len(complete)==len(proof)==443
 summary=copy.deepcopy(old['summary']);summary.update(complete=443,remaining=636,source_revision=revs['reader'],new_complete_scripts=96,new_complete_chapters=24,new_reviewed_fields=5202,verified_at=now)
 assert summary['pending_unindexed']==sum(not x['complete'] and not x['indexed'] for x in rows)==24
 entries=copy.deepcopy(old['indexed_entries']);selected_chapters={x['chapter_id'] for x in selected.values()}
 old_complete=sum(x['complete'] for x in entries)
 for e in entries:
  done=set(e['done_paths'])|({p for p in e['paths'] if p in selected})
  e.update(done_paths=[p for p in e['paths'] if p in done],complete=bool(e['paths']) and all(p in done for p in e['paths']),added_complete_this_batch=e['story_id'] in selected_chapters)
 assert sum(x['complete'] for x in entries)==old_complete+24
 counts={'indexed_candidate_entries':len(entries),'indexed_complete_entries':sum(x['complete'] for x in entries),'indexed_not_fully_complete_entries':sum(not x['complete'] for x in entries),'indexed_partial_entries':sum(bool(x['done_paths']) and not x['complete'] for x in entries),'new_complete_chapters':24,'new_full_review_scripts':96,'new_reviewed_fields':5202,'note':'Broad provenance candidate entries are not a pure AI denominator; scripts and whole indexed chapters are distinct units.'}
 q=copy.deepcopy(read(O/'next-ai-only-full-chapter-queue.json'));q['queue']=[x for x in q['queue'] if x['story_id'] not in selected_chapters];q['source_revision']=revs['reader'];q['updated_at']=now;q['remaining_queued_whole_chapters']=len(q['queue'])
 from refresh_resume_queue import refresh
 q=refresh(q,rows,rt)
 for x in q['queue']:
  assert not {z['path'] for z in x['sources']}&selected.keys()
 save('current-confirmed-machine-ledger.json',rows);save('current-confirmed-machine-summary.json',summary);save('completed-machine-review-evidence.json',list(proof.values()));save('ai-candidate-ledger-after.json',entries);save('completion.json',counts);save('next-ai-only-full-chapter-queue.json',q)
 for n in ['new-path-provenance-queue.json','machine-origin-script-ledger.json']:
  data=read(O/n)
  if n=='machine-origin-script-ledger.json':
   for x in data:
    if x['path'] in selected:x.update(current_blob=rt[x['path']]['sha'],complete=True,status='machine_origin_full_review_complete')
  save(n,data)
 old.update(source_revision=revs['reader'],patch_revision=revs['patch'],verified_at=now,summary=summary,completed_evidence=list(proof.values()),scripts=rows,indexed_entries=entries,next_full_chapter_queue=q)
 save('Reader_AI_Full_Ledger_20261002.json',old)
 (W/'Reader_AI_Full_Ledger_20261002.json.gz').write_bytes(gzip.compress((json.dumps(old,ensure_ascii=False,indent=2)+'\n').encode(),mtime=0))

 print('CONFIRMED_AI',json.dumps(summary,ensure_ascii=False),flush=True);print('INDEXED',json.dumps(counts,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
