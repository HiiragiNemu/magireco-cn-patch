const test=require('node:test'),assert=require('node:assert/strict');const {applyProvenRecovery}=require('./reader_recovery_contract.cjs');
function sample(){const address=['story','group_1',0,'narration'];const a={story:{group_1:[{nameNarration:'',narration:'[se:3001_chara_damage]',chara:[{id:402700,motion:0}]}]}};const j=structuredClone(a);j.story.group_1[0].narration+='ザシュッ';const p={kind:'narrator_sfx',path:'a.json',cn_blob:'sha',actor_id:null,jp_actor_id:null,speaker_name:'',jp_speaker_name:'',address,before:a.story.group_1[0].narration,japanese:j.story.group_1[0].narration,after:'[se:3001_chara_damage]唰！'};p.original_machine_log_match=[{type:'fallback',japanese:p.japanese,chinese:p.before}];const f={path:'a.json',before:'sha',operations:[[address,p.before,p.after]]};return{a,j,p,f};}
function run(s){const out=structuredClone(s.a);applyProvenRecovery(out,s.a,s.j,s.f,s.p);return out;}
test('narrator sound source recovery retains all staged character effects',()=>{const s=sample(),r=run(s);assert.deepEqual(r.story.group_1[0].chara,s.a.story.group_1[0].chara);assert.equal(r.story.group_1[0].narration,s.p.after);assert.equal(r.story.group_1.length,1)});
test('narrator positive speaking actor rejected',()=>{const s=sample();s.p.actor_id=s.p.jp_actor_id=402700;assert.throws(()=>run(s))});
test('narrator differing staged actor rejected',()=>{const s=sample();s.j.story.group_1[0].chara[0].id=1;assert.throws(()=>run(s))});
test('narrator differing scene effect rejected',()=>{const s=sample();s.j.story.group_1[0].bgEffect='shakeLarge';assert.throws(()=>run(s))});
test('narrator mismatched speaker rejected',()=>{const s=sample();s.p.jp_speaker_name='某人';assert.throws(()=>run(s))});
test('narrator invented sound translation rejected',()=>{const s=sample();s.p.after='[se:3001_chara_damage]新的台词';s.f.operations[0][2]=s.p.after;assert.throws(()=>run(s))});
test('narrator no machine fallback pair rejected',()=>{const s=sample();s.p.original_machine_log_match=[];assert.throws(()=>run(s))});
test('character speech cannot use narrator bypass',()=>{const s=sample();s.p.kind='character';assert.throws(()=>run(s))});
