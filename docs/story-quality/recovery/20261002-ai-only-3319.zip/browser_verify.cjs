const fs=require('node:fs'),path=require('node:path');
const W=__dirname,ROOT=path.join(W,'delivery'),R=path.join(ROOT,'repo'),{chromium}=require(path.join(W,'..','qa/node_modules/playwright-core'));
const index=JSON.parse(fs.readFileSync(path.join(R,'website/public/story_index.json'),'utf8'));
const targets=[["340271-2", "我们在场的话"], ["340272-4", "唰！"], ["340273-2", "唰！"], ["340283-3", "感受到了珍妮特"], ["340292-4", "无法指望"], ["340293-4", "只属于我的贤者之石"], ["340361-2", "大一轮"], ["340363-4", "赖子妈妈"], ["340612-3", "爱实"], ["340613-3", "为了保护弱者"], ["340621-2", "员工餐"], ["340623-4", "我留着的点心"], ["341212-4", "法国就这样被一分为二"], ["341221-3", "弗雷什"], ["341222-4", "里舍蒙"], ["311133-4", "明日香的表妹"]].map(([sid,text])=>{const s=index.find(s=>(s.json_sources_cn||[]).some(p=>path.basename(p)===sid+'.json'));if(!s)throw Error('No exact route '+sid);return{sid,text,route:s.id,url:'https://magireader.pages.dev/reader/'+encodeURIComponent(s.id)+'?cn='+encodeURIComponent(s.path_cn)+'&jp='+encodeURIComponent(s.path_jp)}});
(async()=>{const browser=await chromium.launch({executablePath:'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',headless:true});const results=[];
 try{for(const mobile of [false,true]){
  const context=await browser.newContext({viewport:mobile?{width:390,height:844}:{width:1440,height:1000},isMobile:mobile,hasTouch:mobile,locale:'zh-CN'});const page=await context.newPage();let errors=[];page.on('pageerror',e=>errors.push(String(e)));
  for(const t of targets){errors=[];const response=await page.goto(t.url,{waitUntil:'domcontentloaded',timeout:45000});if(response.status()!==200)throw Error('HTTP '+response.status());
   if(mobile)await page.getByRole('button',{name:'打开剧情目录',exact:true}).click({timeout:30000});
   await page.getByText(t.sid,{exact:true}).first().click({timeout:30000});
   let pageTurns=0,loc;
   for(;;){
    try{
     // textContent may include an offscreen/pre-rendered page. Accept only an
     // actually visible locator, rechecked after scrolling has settled.
     loc=page.getByText(t.text,{exact:false}).filter({visible:true}).last();
     await loc.waitFor({state:'visible',timeout:4000});
     await loc.scrollIntoViewIfNeeded({timeout:15000});
     await page.waitForTimeout(300);
     if(!await loc.isVisible())throw Error('Target disappeared during page transition');
     break;
    }catch(error){
     if(pageTurns>=8)throw error;
     const next=page.getByRole('button',{name:'下一页',exact:true}).filter({visible:true}).first();
     if(!await next.count()||await next.isDisabled())throw error;
     await next.click();pageTurns++;
    }
   }
   const body=await page.locator('body').innerText();if(body.includes('调节器使者')||body.includes('我-我-我-我-我-我-我-我-一月'))throw Error('Stale machine text still visible');
   if(errors.length)throw Error(errors.join(';'));
   const image=(mobile?'mobile':'desktop')+'-'+t.sid+'-'+require('node:crypto').createHash('sha256').update(t.text).digest('hex').slice(0,8)+'.png';await page.screenshot({path:path.join(W,image),fullPage:false});
   const result={id:t.sid,route:t.route,viewport:mobile?'mobile':'desktop',expected:t.text,visible:await loc.isVisible(),pageTurns,pageErrors:errors.slice(),screenshot:image};if(!result.visible)throw Error('Not actually visible at capture: '+t.sid+' '+t.text);results.push(result);console.log('BROWSER_ACCEPTED',JSON.stringify(result));
  }await context.close();
 }}finally{await browser.close()}
 const report={sourceRevision:fs.readFileSync(path.join(ROOT,'source-revision.txt'),'utf8').trim(),checks:results.length,passed:results.length===32&&results.every(x=>x.visible&&!x.pageErrors.length),results};fs.writeFileSync(path.join(W,'browser-verification.json'),JSON.stringify(report,null,2));if(!report.passed)throw Error('Incomplete browser acceptance');
})().catch(e=>{fs.writeFileSync(path.join(W,'browser-error.txt'),String(e.stack||e));console.error(e);process.exitCode=1});
