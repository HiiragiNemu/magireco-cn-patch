const assert=require('node:assert/strict');
const bodyKeys=new Set(['textLeft','textRight','textCenter','textAvLeft','textAvRight','textAvCenter','narration','Fnarration','fnarration','progressNarration','progressFnarration','textSelect']);
const tokens=s=>s.match(/\[[^\[\]]*\]/g)||[];
const visible=s=>s.replace(/\[[^\[\]]*\]/g,'').replace(/@/g,'').trim();
function at(obj,address){let node=obj;for(const k of address){assert(node&&Object.hasOwn(node,k),'Existing source address required');node=node[k];}return node;}
function applyProvenRecovery(expected,original,japanese,file,proof){
 assert.equal(proof.path,file.path);assert.equal(proof.cn_blob,file.before);
 assert.equal(proof.actor_id,proof.jp_actor_id);assert(proof.actor_id>0);
 assert(Array.isArray(proof.address)&&proof.address[0]==='story'&&bodyKeys.has(proof.address.at(-1)));
 assert.equal(at(original,proof.address),proof.before);assert.equal(at(japanese,proof.address),proof.japanese);
 assert.equal(visible(proof.before),'','Only a source-erased visible string can be recovered');
 assert(visible(proof.japanese).length>0,'Japanese must contain the missing speech');assert(visible(proof.after).length>0);
 assert.deepEqual(tokens(proof.before),tokens(proof.after));assert.deepEqual(tokens(proof.before),tokens(proof.japanese));
 assert(file.operations.some(([address,before,after])=>JSON.stringify(address)===JSON.stringify(proof.address)&&before===proof.before&&after===proof.after),'Recovery must be an explicitly reviewed exact text operation');
 assert(proof.original_machine_log_match.some(x=>x.japanese===proof.japanese&&x.chinese===proof.before),'Original machine-output omission proof required');
 let node=expected;for(const k of proof.address.slice(0,-1))node=node[k];node[proof.address.at(-1)]=proof.after;
}
module.exports={applyProvenRecovery};
