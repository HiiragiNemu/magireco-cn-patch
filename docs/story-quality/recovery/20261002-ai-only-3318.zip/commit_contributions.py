"""Publish only generated contribution records/helpers, preserving concurrent runtime and worktree changes."""
from pathlib import Path
import json,subprocess,sys,os,datetime,hashlib
W=Path(__file__).resolve().parent;R=W.parent/'repo'
STORES={'reader':None,'patch':'A:/StoryQuality-20260930-1739/patch.git','public':'A:/StoryQuality-20260930-1739/public.git'}
def git(repo,*args,data=None,env=None):
 p=subprocess.run(['git',*(['--git-dir='+STORES[repo]] if STORES[repo] else []),*args],cwd=R,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=150)
 if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace'))
 return p.stdout
def tree(repo,ref):
 result={}
 for row in git(repo,'ls-tree','-r','-z',ref).split(b'\0'):
  if row:
   m,path=row.split(b'\t',1);result[path.decode()]=m.decode()
 return result
def main():
 repo=sys.argv[1];folder=Path(sys.argv[2]);v=json.loads((folder/'verification.json').read_bytes());assert v['passed'] and v['checks']==19
 version=v['source_summary']['last_published_scenario_version'];root='docs/story-quality/contributions/'
 payload={root+p.relative_to(folder).as_posix():p.read_bytes() for p in folder.rglob('*') if p.is_file()}
 payload[root+f'snapshots/{version}-summary.json']=(folder/'summary.json').read_bytes()
 if repo in ('reader','patch'):
  payload['tools/story_quality_contributions.py']=(W/'contribution_ledger.py').read_bytes();payload['tools/verify_story_quality_contributions.py']=(W/'verify_contributions.py').read_bytes()
 assert all(p.startswith(root) or p in ['tools/story_quality_contributions.py','tools/verify_story_quality_contributions.py'] for p in payload)
 git(repo,'fetch','origin','main');start=git(repo,'rev-parse','FETCH_HEAD').decode().strip();original=tree(repo,start);expected={p:original.get(p) for p in payload}
 for attempt in range(4):
  git(repo,'fetch','origin','main');head=git(repo,'rev-parse','FETCH_HEAD').decode().strip();current=tree(repo,head)
  assert all(current.get(p)==old for p,old in expected.items()),'Concurrent contribution change; refresh and reconcile'
  env=os.environ.copy()|{'GIT_INDEX_FILE':str(W/(repo+'-contribution-index-'+datetime.datetime.now().strftime('%H%M%S%f')))};git(repo,'read-tree',head,env=env)
  records=[];shas={}
  for path,b in payload.items():
   sha=git(repo,'hash-object','-w','--stdin',data=b).decode().strip();shas[path]=sha;records.append(('100644 '+sha+'\t'+path+'\0').encode())
  git(repo,'update-index','-z','--index-info',data=b''.join(records),env=env);t=git(repo,'write-tree',env=env).decode().strip();env|={'GIT_AUTHOR_NAME':'HiiragiNemu','GIT_AUTHOR_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com','GIT_COMMITTER_NAME':'HiiragiNemu','GIT_COMMITTER_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com'}
  c=git(repo,'commit-tree',t,'-p',head,data=(f'docs(story): preserve cumulative pre/post-takeover contribution ledger through {version} [skip ci]\n').encode(),env=env).decode().strip();new=tree(repo,c)
  assert all(new[p].split()[2]==sha for p,sha in shas.items()) and all(new[p]==old for p,old in current.items() if p not in payload),'Non-target tree preservation failed'
  try:git(repo,'push','origin',c+':refs/heads/main')
  except RuntimeError:
   if attempt==3:raise
   continue
  git(repo,'fetch','origin','main');remote=tree(repo,'FETCH_HEAD');assert all(remote[p].split()[2]==sha for p,sha in shas.items())
  if repo=='reader':
   git(repo,'merge','--ff-only',c)
   assert git(repo,'diff','--binary')==(W/'initial-diff.bin').read_bytes()
   assert git(repo,'diff','--cached','--binary')==(W/'initial-staged.bin').read_bytes()
  rec={'repository':repo,'version':version,'parent':head,'commit':c,'files':len(payload),'remote_verified':True,'runtime_and_other_files_unchanged':True,'ledger_sha256':v['ledger_sha256']}
  (W/(f'contributions-{version}-{repo}-commit.json')).write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('CONTRIBUTIONS_COMMITTED',json.dumps(rec),flush=True);return
 raise RuntimeError('No stable main')
if __name__=='__main__':main()
