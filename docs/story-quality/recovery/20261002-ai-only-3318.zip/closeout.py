"""Verified docs-only closeout; never rebuild or republish scenario3318."""
from pathlib import Path
import sys,json,os,datetime,gzip,zipfile,hashlib
W=Path(__file__).resolve().parent;R=W.parent/'repo';D=W/'delivery';REV=json.loads((W/'reader-commit.json').read_bytes())['commit']
sys.path.insert(0,str(W));from commit_sources import git,tree

def read(n):return json.loads((W/n).read_bytes())
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode('utf8')
def save(n,x):(W/n).write_bytes(enc(x))
def sha(x):return hashlib.sha256(x).hexdigest()
def blob(x):return hashlib.sha1(b'blob '+str(len(x)).encode()+b'\0'+x).hexdigest()
def dirty_guard():
 for p,h in read('dirty-tracked-hashes.json').items():assert sha((R/p).read_bytes())==h,p
 for name,args in [('initial-diff.bin',('diff','--binary')),('initial-staged.bin',('diff','--cached','--binary')),('initial-status-z.bin',('status','--porcelain=v1','-z'))]:assert git('reader',*args)==(W/name).read_bytes(),name

def commit_docs(repo,files):
 git(repo,'fetch','origin','main');base=git(repo,'rev-parse','FETCH_HEAD').decode().strip();baseline=tree(repo,base)
 if repo=='reader':assert git(repo,'rev-parse','HEAD').decode().strip()==base
 expected={p:baseline.get(p,{}).get('sha') for p in files}
 for p in files:assert p.startswith('docs/story-quality/') or p=='STORY_QUALITY_HANDOFF.md',p
 for attempt in range(3):
  git(repo,'fetch','origin','main');head=git(repo,'rev-parse','FETCH_HEAD').decode().strip();current=tree(repo,head)
  assert all(current.get(p,{}).get('sha')==v for p,v in expected.items()),'Concurrent handoff change'
  key='reader_files' if repo=='reader' else 'runtime_files'
  assert all(current[x['path']]['sha']==x['after'] for x in read('repair-plan.json')[key]),'Concurrent scenario change'
  env=os.environ.copy()|{'GIT_INDEX_FILE':str(W/(repo+'-closeout-index-'+datetime.datetime.now().strftime('%H%M%S%f')))};git(repo,'read-tree',head,env=env);records=[]
  for p,b in files.items():
   h=git(repo,'hash-object','-w','--stdin',data=b).decode().strip();assert h==blob(b);records.append(('100644 '+h+'\t'+p+'\0').encode())
  git(repo,'update-index','-z','--index-info',data=b''.join(records),env=env);t=git(repo,'write-tree',env=env).decode().strip()
  env|={'GIT_AUTHOR_NAME':'HiiragiNemu','GIT_AUTHOR_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com','GIT_COMMITTER_NAME':'HiiragiNemu','GIT_COMMITTER_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com'}
  c=git(repo,'commit-tree',t,'-p',head,data=b'docs(handoff): verified AI-only3318 delivery and source-bound1079-script census [skip ci]\n',env=env).decode().strip();new=tree(repo,c)
  assert all(new[p]['sha']==blob(b) for p,b in files.items()) and all(new[p]==v for p,v in current.items() if p not in files)
  try:git(repo,'push','origin',c+':refs/heads/main')
  except RuntimeError:
   if attempt==2:raise
   continue
  git(repo,'fetch','origin','main');remote=tree(repo,'FETCH_HEAD');assert all(remote[p]['sha']==blob(b) for p,b in files.items())
  if repo=='reader':git(repo,'merge','--ff-only',c)
  save('closeout-'+repo+'-commit.json',{'commit':c,'parent':head,'files':len(files),'non_target_tree_preserved':True,'remote_readback_passed':True});print('DOCS_COMMITTED',repo,c,flush=True);return c
 raise RuntimeError('Unable to safely advance main')

def main():
 assert not (W/'closeout-reader-commit.json').exists(),'Already closed; verify rather than repeat'
 dirty_guard();now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 v=read('validation.json');p=read('published-package-receipt.json');h=read('delivery/online-exact-verification.json');b=read('browser-verification.json');a=read('delivery/adv-release-published.json');u=read('delivery/production-upload.json');q=read('delivery/full-check-result.json');edge=read('delivery/edge-status-production-verified.json');count=read('current-confirmed-machine-summary.json');run=read('publisher-run.json');cross=read('cross-repo-machine-summary.json');proof=read('completed-machine-review-evidence.json');ledger=read('current-confirmed-machine-ledger.json')
 assert v['display_fields_revised']==2537 and v['complete_scenes_reviewed']==72 and v['body_fields_revised']==2523 and v['explicit_speaker_label_repairs']==14 and v['restored_previously_empty_display_fields']==1
 assert v['specialized_tests_passed']==23 and v['additional_missing_display_contract_tests']==9
 assert p['version']==3318 and p['reader_commit']==REV and p['status']=='published_and_anonymously_verified' and p['changed_chinese_fields']==2537
 assert run['conclusion']=='success' and run['head_sha']==read('public-commit.json')['commit']
 assert h['source_revision']==REV and h['passed']==h['total'] and h['failed']==0 and h['total']>=1925 and h['authorized_196_all_covered']
 assert b['sourceRevision']==REV and b['passed'] and b['checks']==24 and edge['passed'] and edge['checks']==5
 assert q['python_tests']==611 and q['python_failures']==0 and q['node_tests']==730 and q['node_failures']==0 and q['source_or_test_code_modified_to_pass'] is False
 assert a['release']['source_revision']==REV and a['release']['deployment']==u['canonical_url'] and u['canonical_commit']==REV and u['all_other_configurations_unchanged']
 assert count['confirmed_current_machine_scripts']==1079 and count['complete']==347 and count['remaining']==732 and len(proof)==347 and len(ledger)==1079
 assert not cross['completed_scripts_with_player_body_differences']
 cv=read('contributions-3318/verification.json');cs=read('contributions-3318/summary.json');cc={r:read('contributions-3318-'+r+'-commit.json') for r in ('reader','patch','public')}
 assert cv['passed'] and cv['checks']==19 and cv['source_summary']==cs
 assert cs['last_published_scenario_version']==3318 and cs['confirmed_ai_fully_reviewed']==347 and cs['confirmed_ai_pending']==732 and cs['completed_before_takeover']==48 and cs['completed_after_takeover']==299 and cs['legacy_unique_registered_ids']==498
 assert all(x['remote_verified'] and x['ledger_sha256']==cv['ledger_sha256'] for x in cc.values())
 for repo in ('reader','patch'):
  git(repo,'fetch','origin','main');current=tree(repo,'FETCH_HEAD');key='reader_files' if repo=='reader' else 'runtime_files'
  assert all(current[x['path']]['sha']==x['after'] for x in read('repair-plan.json')[key]),'Current scenario source moved'
  assert current['docs/story-quality/contributions/ledger.json.gz']['sha']==blob((W/'contributions-3318/ledger.json.gz').read_bytes())
  if repo=='reader':
   for x in ledger:assert current[x['path']]['sha']==x['current_blob'] and current[x['jp_path']]['sha']==x['jp_blob'],x['path']
 versions=read('post-package-version-checks.json');assert len(versions)==2 and all(x['status']==200 and x['data']=={'version':3318,'size':p['package']['size'],'md5':p['package']['md5']} for x in versions)
 state={'reader_source_commit':REV,'reader_data_commit':REV,'cn_patch_source_commit':p['cn_patch_commit'],'scenario_version':3318,'package':p['package'],'package_publication_run':run['id'],'reader_production_deployment':u['canonical_id'],'reader_site_uploaded':True,'reader_site_uploaded_for_active_batch':True,'reader_exact_http':{k:v for k,v in h.items() if k!='results'},'reader_browser_checks':b,'adv_current_for_this_source_registered':True,'adv_registered_for_active_batch':True,'adv_record':a['release'],'game_device_verified':False,'contribution_ledger':{'entry':'docs/story-quality/contributions/README.md','summary':cs,'verification':{'checks':19,'ledger_sha256':cv['ledger_sha256']},'commits':cc,'include_previous_AI':True,'original_translation_authorship_reassigned':False,'game_credit_ui_changed':False}};save('delivery-state.json',state)
 progress=read('progress.json');progress.update(stage='delivered',closed_at=now,checkpoint=f"18话72脚本3822字段，2523正文及14显示姓名修正已交付3318、Reader {u['canonical_id'][:8]}与ADV；{h['total']} HTTP、24浏览器和5接口通过；确认AI已复核347/1079、待732；接手前后累计贡献三仓同步",active_sessions={},whole_corpus_complete=False,next=['按next-ai-only-full-chapter-queue.json继续确认AI完整剧情，写前刷新中日文blob并排除官方/人工','732待完整复核含24未索引；不得将扫描或单节命中计为整话完成','必须持续更新docs/story-quality/contributions/，保留3301起所有发布与更早498唯一ID历史，不得清零接手前AI贡献','Reader128和客户端35来源未明仅做来源调查，不直接重译','3318、Reader及ADV均已交付，不重发；下一批需以实际生产版本重新生成版本限定脚本']);save('progress.json',progress)
 queue_resume=read('resume-queue-verification.json');assert queue_resume['tests_passed']==7 and queue_resume['completed_count_unchanged']
 receipt={'schema':3,'verified_at':now,'batch':progress['batch'],'delivery':state,'translation':v,'tests':q,'edge_checks':edge,'counts':count,'indexed_candidate_counts':read('completion.json'),'cross_repo_binding':cross,'package_receipt':p,'ordinary_player_version_checks':versions,'contributions':{'summary':cs,'checks':cv,'commits':cc},'resume_queue_verification':queue_resume,'original_uncommitted_state_unchanged':True,'whole_corpus_complete':False,'device_gameplay_verified':False,'source_provenance_holds':{'reader':128,'client_only':35,'automatically_retranslate':False}};save('final-receipt.json',receipt)
 gaps=read('Reader_AI_Full_Ledger_20261002.json');gaps.update(verified_at=now,summary=count,cross_repo_summary=cross,client_extra_queue=read('patch-only-provenance-queue.json'),delivery={'scenario_version':3318,'reader_source':REV,'patch_source':p['cn_patch_commit'],'reader_deployment':u['canonical_id'],'adv_release':a['release']},contribution_entry='docs/story-quality/contributions/README.md');save('Reader_AI_Full_Ledger_20261002.json',gaps);compressed=gzip.compress(enc(gaps),mtime=0);(W/'Reader_AI_Full_Ledger_20261002.json.gz').write_bytes(compressed)
 doc=f'''# Reader／CN patch：3318校订与累计贡献交付回执

核验时间：{now}。本轮源码、玩家包、Reader正式站、ADV登记均已交付。

## 本轮实际修订

完整对照日文审读18整话、72个独立运行脚本、3822个正文显示字段；72个脚本均有改动，共修正2523处正文及14处有原文依据的年龄／亲属关系显示标签。同步36份源TXT／网页配对副本，共{v['reader_txt_field_spans']}个精确文本片段；13节历史导出均通过全文匹配底稿后同步，无模糊匹配、无缺失。

覆盖灯花·音梦（圣夜）、十咎桃子（修女）、花凛·阿莉娜（万圣节）、龙城明日香（新春龙神）、十七夜（吸血鬼）及米诺，各三话。每个目标都有冻结中日文blob和明确机器输出配对证据；官方、确认人工及仅来源不明的稿件不纳入重译。正确旧译保留，不把保留原译算作新译。

主要修复了修女误译为妹妹、压岁钱误译为一般礼物、台词否定与施受关系反转、漫画读者误译为画廊、分镜草稿误译为名字、把人物自身的理想／解读错写成事实等问题。14处标签只修复幼小表妹被写为表姐、同一位年长堂兄配音标签写错的问题，不改变角色身份、模型、站位或音频。

另恢复了311133-4中一条被机器翻译完全吞掉的幼儿笑声：原日文“きゃっきゃ”在同一既有textRight字段内，旧机器输出只剩控制标签。补回后Reader多显示一条原本被跳过的文字，但未新增运行节点或命令。原文、机器日志、同一演员ID、控制标签和逐地址校订证明均已留存；9项新增拒绝性测试专门限定这一恢复，不能用它放行任意新增台词。

## 接手前后的累计贡献

确认AI／机翻的独立运行片段共1079，现已完整复核347，尚待732，其中已经包含24个未索引片段。347中接手前48、接手后299；本轮新增72，未清零前一个AI的工作。

3301—3318全部18个已发布批次，按运行JSON路径去重后实际修改{cs['published_unique_runtime_scripts_modified']}个片段。其中涉及正文校订的{cs['published_unique_runtime_scripts_with_body_correction']}个片段、{cs['published_unique_body_addresses_corrected']}个不同字段地址；重复修改事件另记，不当作新的剧情或句子。姓名规范、运行兼容和原稿恢复均独立分类。这一“修改数”与“全文复核数”含义不同，不能相加。字段数也不等于新译句数：其中包括称呼、字词、文本错位归位等修正，历史3309里连同台词移动的内嵌标签亦已逐项保留。

更早的历史登记：507个候选条目、498个唯一剧情ID已全数保存。旧档的“剩余0”指当时译文写入／结构校验完成，不等于现版逐句审查全部完成；所有498个ID、原登记标题、当前路径和与现版复核的对应关系均已入台账，不因口径不同而丢弃历史贡献。

固定入口：`docs/story-quality/contributions/README.md`，Reader、CN patch、发行仓三个仓库均有。`processed-runtime-scripts.tsv`列出所有已发布修改的剧情ID、标题、脚本、首次／最近版本；`full-reviewed-ai-scripts.tsv`与`pending-ai-scripts.tsv`逐条列出完整复核和剩余；`indexed-chapters.tsv`区分整话与部分片段；`legacy-registered-stories.tsv`保留498个旧ID；`ledger.json.gz`包含字段级前后文字、地址、提交、发布回执和全部历史证据。19项独立核算检查通过，生成器已入库以便每批重建，不只手改汇总数字。

这些记录用于核定维护者主导的AI辅助校订、整合、兼容与发布贡献，不把原国服、官方、Wiki或确认人工译文改署给维护者。本次未修改游戏贡献UI、APK或玩家署名。

另Reader128个与客户端独有35个正文仍仅是来源调查事项，不自动标为AI或重译任务。广义来源候选目录300个，现有102个整话完整、198个未完整，它们不是纯AI分母。

## 四环节交付

Reader数据：`{REV}`（main）。CN patch数据：`{p['cn_patch_commit']}`（main）。

玩家包3318：latest及scenario-3318；GitHub工作流`{run['id']}`成功，两条普通玩家版本入口读回一致。字节数{p['package']['size']}，SHA-256`{p['package']['sha256']}`，MD5`{p['package']['md5']}`。

Reader正式部署：`{u['canonical_id']}`，源码`{REV}`。ADV公开登记：`{a['release']['deployment']}`，源码与Reader一致；不是仅有提交而未上线。

累计贡献三仓提交：Reader`{cc['reader']['commit']}`；CN patch`{cc['patch']['commit']}`；发行仓`{cc['public']['commit']}`。三仓账本SHA-256一致：`{cv['ledger_sha256']}`。

## 验证与保护范围

23项专项结构／翻译拒绝性测试、9项缺字恢复合同测试全部通过。72个脚本经过真实Reader解析；仅应用显式姓名修正及原文证明的既有缺字恢复后，原运行事件、角色身份与音频元数据一致。JSON和TXT改动均可精确逆向还原原始字节。

Python {q['python_tests']}项，失败0，跳过{q['python_skipped']}；Node {q['node_tests']}项，失败0。未修改原测试来使其通过；lint、typecheck、feature policy及生产依赖审计通过。正式站{h['total']}项逐字节HTTP检查全部通过，发生重试的目标{h['retries']}；桌面／手机24项浏览器阅读检查和5项状态接口检查通过。

玩家包{p['unchanged_files']}个非目标文件逐字节未变。先前{p['previous_corrected_scripts']}份已修订文件中，{p['previous_byte_identical']}份原样保留，另{len(p['previous_exact_extensions'])}份仅叠加本轮有据修改。43份V4兼容、196份授权中文、原工作树未提交状态及并行修改均保留。未动L2D、AIO、APK、字体或游戏贡献展示。Totentanz实机动画仍未验收，网页测试不替代设备测试。全库AI校订仍未完成。

## 本轮整话清单

| 剧情ID | 标题（当前目录原名） | 运行脚本 | 审读字段 |
|---|---|---|---:|
'''
 for ch in read('chapters.json'):doc+=f"| {ch['story_id']} | {ch['title'].replace('|','／')} | {', '.join(ch['script_ids'])} | {ch['fields']} |\n"
 doc+='\n## 后续接续\n\n从`STORY_QUALITY_HANDOFF.md`、`docs/story-quality/CONTINUATION.md`、`CONTINUATION_STATE.json`进入。当前发布回执为`docs/story-quality/20261002-ai-only-batch06-published.md`及同名JSON。最新复核总台账同时写入固定兼容路径`docs/story-quality/20261001-ai-only-census.json.gz`与新日期副本`20261002-ai-only-census.json.gz`。继续下批前刷新main与真实生产，3318已交付，勿重复发行。必须同步维护累计贡献，不能因换窗口丢掉接手前后记录。\n'
 reportname='Reader_AI_3318_Delivery_20261002.md';(W/reportname).write_text(doc,encoding='utf8')
 safe=['collect.py','decisions.py','review_io.py','record_raw.py','stage.py','sync_text.py','translation_rules.py','test_translation_rules.py','reader_check.cjs','reader_recovery_contract.cjs','test_reader_recovery.cjs','exact_json.py','prepare_delivery.py','commit_sources.py','build_package.py','prepare_public.py','publish_scenario_3318.py','prepare_build.py','update_census.py','cross_repo_verify.py','checkpoint.py','browser_verify.cjs','prepare_acceptance.py','run_full_qa.py','inspect_publisher.py','closeout.py','contribution_ledger.py','verify_contributions.py','commit_contributions.py','bases.json','review-sources.json','chapters.json','provenance.json','progress.json','validation.json','repair-plan.json','text-plan.json','historical-text-baselines.json','explicit-name-repairs.json','missing-display-restoration.json','second-pass-corrections.json','reader-render-validation.json','reader-commit.json','patch-commit.json','public-commit.json','publisher-run.json','published-package-receipt.json','post-package-version-checks.json','completed-machine-review-evidence.json','current-confirmed-machine-summary.json','cross-repo-machine-summary.json','next-ai-only-full-chapter-queue.json','delivery-state.json','final-receipt.json',reportname,'Reader_AI_Full_Ledger_20261002.json.gz','browser-verification.json','browser-harness-note.json','browser-first-attempt/browser-verification.json']
 safe+=['refresh_resume_queue.py','resume-queue-verification.json','resumed-live-state.json','resume-archive-diagnosis.json']
 safe+=['contributions-3318-'+r+'-commit.json' for r in ('reader','patch','public')]
 dep=['build-steps.json','full-check-result.json','source-preservation-before-generation.json','source-preservation-after-generation.json','source-preservation-after-build.json','source-preservation-after-qa.json','online-exact-verification.json','online-exact-plan.json','edge-status-production-verified.json','production-upload.json','adv-release-published.json'];members=[];archive=W/'20261002-ai-only-3318-recovery.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n in safe:assert (W/n).is_file(),n;z.write(W/n,n);members.append(n)
  for n in dep:assert (D/n).is_file(),n;z.write(D/n,'delivery/'+n);members.append('delivery/'+n)
  for pattern in ['review/*.edits.json','review/*.final.txt','trusted-*-reference.json','decisions-*.json','review-second-pass-baseline/*.json','contributions-3318/*']:
   for f in sorted(W.glob(pattern)):
    if not f.is_file():continue
    n=f.relative_to(W).as_posix();assert n not in members;z.write(f,n);members.append(n)
 with zipfile.ZipFile(archive,'r') as checked_zip:
  assert checked_zip.namelist()==members,'Recovery ZIP membership differs'
  assert checked_zip.testzip() is None,'Finalized recovery ZIP failed CRC'
  for name in members:
   assert checked_zip.read(name)==(W/name).read_bytes(),('Recovery member differs',name)
 recovery={'path':'docs/story-quality/recovery/20261002-ai-only-3318.zip','sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(members)};save('recovery-metadata.json',recovery);receipt['recovery']=recovery;save('final-receipt.json',receipt)
 st=json.loads((R/'docs/story-quality/CONTINUATION_STATE.json').read_bytes());st.update(state,updated_at=now,checkpoint=progress['checkpoint'],active_batch=progress,task_id=progress['task_id'],recovery_bundle=recovery,project_status='long_term_in_progress_AI_only_not_corpus_complete',pending=progress['next']);st['paths']['current_batch']=str(W)
 st['ai_only_scope']={'confirmed_machine_scripts':1079,'complete':347,'pending':732,'unit':'distinct runtime JSON fragment; source/TXT/player mirrors count once','pending_unindexed_included':24,'new_whole_chapters':18,'new_full_review_scripts':72,'broad_candidate_indexed_entries':300,'broad_candidate_complete':102,'broad_candidate_pending':198,'broad_candidates_not_all_proven_AI':True,'reader_provenance_only_holds':128,'client_only_provenance_holds':35,'ledger':'docs/story-quality/20261002-ai-only-census.json.gz','fixed_compatible_ledger':'docs/story-quality/20261001-ai-only-census.json.gz','rule':'Only confirmed AI; untouched official/human translators retain authorship; unknown provenance is not automatic retranslation.'}
 st.setdefault('previous_batch_summaries',{})[progress['batch']]={'stage':'delivered','scenario_version':3318,'reader_source_commit':REV,'cn_patch_source_commit':p['cn_patch_commit'],'recovery':recovery,'contribution_commits':cc}
 root=f'''# Reader／CN patch：剧情校订及累计贡献接续入口

更新：{now}

{progress['checkpoint']}。Reader数据`{REV}`，CN patch数据`{p['cn_patch_commit']}`。玩家3318，Reader／ADV部署`{u['canonical_id']}`。后续纯文档提交不是新的运行版本。

先读`docs/story-quality/20261002-ai-only-batch06-published.md`及同名JSON，再读CONTINUATION_STATE.json。最新逐片段台账`docs/story-quality/20261002-ai-only-census.json.gz`（固定旧路径20261001-ai-only-census.json.gz也已同步），恢复包`{recovery['path']}`。

**累计贡献必须持续保留：`docs/story-quality/contributions/README.md`。** 三仓已经留存3301—3318全部18次发行、接手前后改动和更早498唯一剧情ID登记；每条有标题、ID、路径、当前中日文blob、复核状态、前后文字和提交／发布证据。只能据证据追加，不得清零旧AI成果，不得把写入／扫描／结构校验视为现版全文复核，不得冒领原译者署名。当前已发布去重修改{cs['published_unique_runtime_scripts_modified']}片段，其中正文校订{cs['published_unique_runtime_scripts_with_body_correction']}片段、{cs['published_unique_body_addresses_corrected']}不同字段；这些数字不是全文复核的分母，也不能与498旧ID相加。游戏贡献UI／APK未改。

只处理确认AI／机翻。1079片段已完整复核347（接手前48＋接手后299），待732（含24未索引）。Reader128、客户端35仅做来源调查。广义目录102/300完整，不与片段计数混算。

本批18话72脚本3822字段，2523正文修正、14亲属年龄显示标签修正，1条机翻吞掉的既有笑声恢复。新增显示来自原已有命令，不新增运行节点、角色或音频；详见独立恢复证据和9项新增测试。原23项测试、真实解析、完整QA及公开验收均通过。

工作区`{R}`；本批`{W}`；任务`{progress['task_id']}`。按完整剧情队列继续并刷新中日文blob。3318已交付，不重复发行；版本限定脚本必须更新后才可用于下一批。

仅既有main，不建分支／PR／强推；保留43V4、196授权中文和所有并行工作树修改，不动L2D／AIO／APK／字体。每个可恢复断点与最终答复前提交最新交接和累计贡献。全库未完成，Totentanz实机动画未验收。
'''
 cont=(R/'docs/story-quality/CONTINUATION.md').read_text(encoding='utf8');start='<!-- AI-ONLY-BATCH06-START -->';end='<!-- AI-ONLY-BATCH06-END -->';assert start in cont and end in cont
 block=start+'\n## 最新断点：3318已交付，三仓累计贡献保留\n\n'+root+'\n旧段仅作历史，不覆盖上面的版本与统计。\n'+end;cont=cont[:cont.index(start)]+block+cont[cont.index(end)+len(end):]
 scope=f'''# AI-only scope after3318\n\nConfirmed AI runtime fragments1079; completed347 (48 before takeover,299 after); pending732 including24unindexed. Unknown reader128/client35 investigated separately. Broad indexed candidates300/102complete/198pending are not an AI-only denominator.\n\nPublished contribution history through3318: unique modified scripts{cs['published_unique_runtime_scripts_modified']}; body-corrected scripts{cs['published_unique_runtime_scripts_with_body_correction']},distinct addresses{cs['published_unique_body_addresses_corrected']}. Historical498registered IDs retained separately, without assuming current semantic completion. Official/human authorship is preserved; no credit UI changes.\n\nLatest receipt20261002-ai-only-batch06-published.md/.json; fullcensus20261002-ai-only-census.json.gz and fixedcompatible20261001-ai-only-census.json.gz. Mandatory cumulative entry docs/story-quality/contributions/README.md.\n'''
 files={'STORY_QUALITY_HANDOFF.md':root.encode(),'docs/story-quality/CONTINUATION.md':cont.encode(),'docs/story-quality/CONTINUATION_STATE.json':enc(st),'docs/story-quality/20261002-ai-only-scope.md':scope.encode(),'docs/story-quality/20261002-ai-only-batch06.md':doc.encode(),'docs/story-quality/20261002-ai-only-batch06-published.md':doc.encode(),'docs/story-quality/20261002-ai-only-batch06-published.json':enc(receipt),'docs/story-quality/20261001-ai-only-census.json.gz':compressed,'docs/story-quality/20261002-ai-only-census.json.gz':compressed,recovery['path']:archive.read_bytes()}
 for path,data in files.items():f=W/'closeout-stage/reader'/path;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(data)
 pfiles={path:data for path,data in files.items() if path.startswith('docs/story-quality/') and path not in ['docs/story-quality/CONTINUATION.md','docs/story-quality/CONTINUATION_STATE.json']}
 pc=commit_docs('patch',pfiles);st['delivery_receipt_commits']={'reader_data':REV,'patch_data':p['cn_patch_commit'],'patch_closeout':pc,'reader_closeout_note':'commit containing this final handoff','contribution_commits':cc};files['docs/story-quality/CONTINUATION_STATE.json']=enc(st);rc=commit_docs('reader',files);dirty_guard()
 save('final-handoff-commits.json',{'reader':rc,'patch':pc,'runtime_source_unchanged':True,'original_dirty_and_staged_state_unchanged':True,'contribution_commits':cc,'recovery':recovery})
 with (W/reportname).open('a',encoding='utf8') as f:f.write('\n最终交接提交：Reader `'+rc+'`；CN patch `'+pc+'`。\n恢复包：`'+recovery['path']+'`，'+str(recovery['files'])+'项文件，SHA-256 `'+recovery['sha256']+'`。\n')
 print('FINAL_HANDOFF_COMPLETE',rc,pc,json.dumps(recovery),flush=True)
if __name__=='__main__':main()
