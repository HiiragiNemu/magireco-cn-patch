"""Repair a stale derived next-chapter preview without granting new translation reviews."""
from pathlib import Path
import copy,datetime,gzip,hashlib,json,sys,unittest
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W))
from commit_sources import git,tree

def refresh(queue,ledger,source_tree):
    rows={x['path']:x for x in ledger}
    assert len(rows)==len(ledger),'Duplicate source ledger path'
    result=copy.deepcopy(queue);kept=[];seen=set()
    for chapter in result['queue']:
        sid=chapter['story_id'];assert sid not in seen,'Duplicate chapter'
        seen.add(sid);sources=chapter['sources']
        assert len(sources)==len({s['path'] for s in sources})==chapter['script_count'],'Duplicate/incomplete source mapping'
        for source in sources:
            path=source['path'];row=rows[path]
            assert source_tree[path]['sha']==row['current_blob'],'Chinese source drift'
            assert source_tree[row['jp_path']]['sha']==row['jp_blob'],'Japanese source drift'
            source.update(cn_blob=row['current_blob'],jp_path=row['jp_path'],jp_blob=row['jp_blob'],complete=row['complete'])
        chapter['pending_scripts']=sum(not s['complete'] for s in sources)
        if chapter['pending_scripts']:kept.append(chapter)
    result['queue']=kept
    result['next_complete_chapters']=copy.deepcopy(kept[:15])
    result['remaining_queued_whole_chapters']=len(kept)
    assert all(c['pending_scripts']>0 for c in result['next_complete_chapters'])
    return result

class ResumeQueueTests(unittest.TestCase):
    def setup_data(self):
        q={'queue':[{'story_id':'a','script_count':1,'sources':[{'path':'c'}]}],'next_complete_chapters':[{'story_id':'stale'}]}
        rows=[{'path':'c','current_blob':'cn','jp_path':'j','jp_blob':'jp','complete':False}]
        t={'c':{'sha':'cn'},'j':{'sha':'jp'}}
        return q,rows,t
    def test_preview_is_derived_not_inherited(self):
        q,r,t=self.setup_data();self.assertEqual(refresh(q,r,t)['next_complete_chapters'][0]['story_id'],'a')
    def test_completed_chapter_is_removed(self):
        q,r,t=self.setup_data();r[0]['complete']=True;self.assertEqual(refresh(q,r,t)['queue'],[])
    def test_does_not_grant_semantic_completion(self):
        q,r,t=self.setup_data();refresh(q,r,t);self.assertFalse(r[0]['complete'])
    def test_chinese_drift_rejected(self):
        q,r,t=self.setup_data();t['c']['sha']='new'
        with self.assertRaises(AssertionError):refresh(q,r,t)
    def test_japanese_drift_rejected(self):
        q,r,t=self.setup_data();t['j']['sha']='new'
        with self.assertRaises(AssertionError):refresh(q,r,t)
    def test_duplicate_chapter_rejected(self):
        q,r,t=self.setup_data();q['queue']*=2
        with self.assertRaises(AssertionError):refresh(q,r,t)
    def test_duplicate_script_rejected(self):
        q,r,t=self.setup_data();q['queue'][0]['sources']*=2;q['queue'][0]['script_count']=2
        with self.assertRaises(AssertionError):refresh(q,r,t)

def main():
    tests=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ResumeQueueTests))
    assert tests.wasSuccessful() and tests.testsRun==7
    qp=W/'next-ai-only-full-chapter-queue.json';lp=W/'Reader_AI_Full_Ledger_20261002.json'
    old=json.loads(qp.read_bytes());gaps=json.loads(lp.read_bytes());rev=json.loads((W/'reader-commit.json').read_bytes())['commit']
    git('reader','fetch','origin','main');current=tree('reader','FETCH_HEAD')
    for row in gaps['scripts']:
        assert current[row['path']]['sha']==row['current_blob'] and current[row['jp_path']]['sha']==row['jp_blob']
    refreshed=refresh(old,gaps['scripts'],current);now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
    refreshed.update(source_revision=rev,updated_at=now,preview_rule='next_complete_chapters is derived from the current pending queue, never copied from an older batch')
    before_ids=[x['story_id'] for x in old['next_complete_chapters']];after_ids=[x['story_id'] for x in refreshed['next_complete_chapters']]
    backup=W/'resume-queue-before.json'
    if not backup.exists():backup.write_bytes(qp.read_bytes())
    qp.write_text(json.dumps(refreshed,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    gaps['next_full_chapter_queue']=refreshed
    assert gaps['summary']['complete']==347 and gaps['summary']['remaining']==732 and len(gaps['completed_evidence'])==347
    lp.write_text(json.dumps(gaps,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    lp.with_suffix('.json.gz').write_bytes(gzip.compress(lp.read_bytes(),mtime=0))
    report={'verified_at':now,'source_revision':rev,'tests_passed':7,'confirmed_ai_sources_checked':len(gaps['scripts']),'complete':347,'pending':732,'completed_count_unchanged':True,'pending_queue_chapters':len(refreshed['queue']),'stale_preview_ids':before_ids,'corrected_preview_ids':after_ids,'runtime_or_translation_files_changed':False,'cause':'Derived preview retained completed chapters from an older batch while the primary pending queue had advanced.'}
    (W/'resume-queue-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    print('RESUME_QUEUE_VERIFIED',json.dumps(report,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
