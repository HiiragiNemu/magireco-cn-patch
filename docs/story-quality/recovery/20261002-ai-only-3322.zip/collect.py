"""Freeze complete AI-test-origin chapters, excluding verified-human and protected paths."""
from pathlib import Path
import json,sys,subprocess,collections,csv,io,hashlib,datetime
W=Path(__file__).resolve().parent; ROOT=W.parent; R=ROOT/'repo'; PRIOR=ROOT/'semantic-batch03-20261001'
sys.path[:0]=[str(PRIOR),str(ROOT/'severe-5109-20261001')]
from census import Store
from collect_review import fields,shape,differences,TEXT,CTRL
TEXT.add('textSelect')
IMPORT='3d463befe7a10d4cb72034378ce2a6f23c377abb'; TRUSTED='65f221f2aaa5a9fe161ed32e03e4dfbb93d4746d'
SELECTED=['510801', '510802', '510803', '510804', '510805', '511120', '511410', '511420', '512610', '512620']
PREVIOUS=ROOT/'semantic-batch09-ai-only-20261002'
CONFIRMED={x['path']:x for x in json.loads((W/'baseline-census.json').read_bytes())['scripts']}
P='A:/StoryQuality-20260930-1739/patch.git'
def git(*args,patch=False):return subprocess.check_output(['git',*(['--git-dir='+P] if patch else []),*args],cwd=R,timeout=90)
def tree(ref,patch=False):
 out={}
 for row in git('ls-tree','-r','-z',ref,patch=patch).split(b'\0'):
  if row:
   h,p=row.split(b'\t',1);out[p.decode()]=h.split()[2].decode()
 return out
def save(name,obj):
 p=W/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def main():
 assert not (W/'review-sources.json').exists(),'Do not replace frozen sources'
 git('fetch','origin','main');git('fetch','origin','main',patch=True)
 bases={'reader':git('rev-parse','HEAD').decode().strip(),'patch':git('rev-parse','FETCH_HEAD',patch=True).decode().strip()}
 assert bases['reader']==git('rev-parse','origin/main').decode().strip()
 rt=tree(bases['reader']);pt=tree(bases['patch'],True);it=tree(IMPORT);trusted=tree(TRUSTED)
 import gzip
 canonical=json.loads(gzip.decompress(git('show',bases['patch']+':docs/story-quality/20261002-ai-only-census.json.gz',patch=True)))
 assert canonical['scripts']==list(CONFIRMED.values()),'Local predecessor ledger differs from canonical CN patch'
 rs=Store();ps=Store(True);manifest=json.loads(rs.get(rt['website/public/data/machine_translation_manifest.generated.json']));index=json.loads(rs.get(rt['website/public/story_index.json']))
 candidates={x['story_id']:x for x in manifest['entries'] if not x['manual_human_verified']}
 human_paths={p for x in manifest['entries'] if x['manual_human_verified'] for s in index if s.get('source_identity')==x['source_identity'] for p in s.get('json_sources_cn',[])}
 protected=set(json.loads(rs.get(rt['docs/reader-availability-local-20260929.json']))['protected_source_failure']['paths'])
 protected.update(x['target_path'] for x in json.loads(rs.get(rt['manifests/authoritative_scenario_runtime_repairs.v1.json']))['entries'])
 review_tsv=rs.get(it['magireco-translate-data-master/TRANSLATION_REVIEW.tsv']).decode('utf-8-sig')
 machine_pairs=collections.defaultdict(list)
 for x in csv.DictReader(io.StringIO(review_tsv),delimiter='\t'):machine_pairs[x['japanese']].append(x)
 names=collections.defaultdict(list)
 for p in pt:
  if p.startswith('madomagi/resource/scenario/json/adv/') and p.endswith('.json'):names[Path(p).name].append(p)
 sources=[];chapters=[]
 for sid in SELECTED:
  assert sid in candidates
  hits=[s for s in index if s.get('source_identity')==candidates[sid]['source_identity']];assert len(hits)==1
  chapter=hits[0];paths=chapter['json_sources_cn'];assert paths
  chapter_sources=[]
  for cp in paths:
   assert cp not in human_paths|protected and cp not in trusted and cp in it,('Not unprotected newly machine-imported source',cp)
   script=Path(cp).stem;jp=cp.replace('magireco-translate-data-master/','magireco-source-master/',1);assert jp in rt
   proof=CONFIRMED[cp];assert proof['machine_output_pair_count']>0
   assert not proof['complete'] or sid in ['510802','510803','510804'],'Previously completed scenes only read for full-chapter context'
   assert proof['current_blob']==rt[cp] and proof['jp_blob']==rt[jp],('Refresh AI ledger before use',cp)
   cn=rs.get(rt[cp]);ja=rs.get(rt[jp]);initial=rs.get(it[cp]);c=json.loads(cn);j=json.loads(ja);cf=fields(c);jf=fields(j)
   assert [x['address'] for x in cf]==[x['address'] for x in jf],('Alignment differs',script)
   assert len(names[Path(cp).name])==1;pp=names[Path(cp).name][0];pb=ps.get(pt[pp]);reconciled=False
   if cn!=pb:
    assert (script,rt[cp],pt[pp],rt[jp])==('511420-6_Qp0aZ','5139fb687ee88a8e67f5fa30641ddafcc337677d','233e78fa5451556b4db0c7440f47c911481cdbbc','0b108a9cdcf8833f407dbf717541cc5a6cc67550'),('Unadjudicated Reader/player mismatch',script)
    diff=differences(c,json.loads(pb));assert len(diff)==2 and [x[0] for x in diff]==[['story','group_1',51,'textLeft'],['story','group_1',54,'textLeft']]
    assert not differences(shape(c),shape(json.loads(pb)))
    for address,reader_text,player_text in diff:
     node=j
     for k in address:node=node[k]
     assert node==player_text,'Player already preserves original intentional witch speech'
    save('source-reconciliation.json',{'script_id':script,'reader_blob':rt[cp],'patch_blob':pt[pp],'jp_blob':rt[jp],'differences':diff,'decision':'Keep player intentional garbled witch utterances exactly equal to Japanese; restore only Reader versions of those two literals. Other reviewed human-readable fields will use independently pinned patch operations.','nontext_identity_equal':True})
    reconciled=True
   nontext=differences(shape(c),shape(j));assert not nontext,('Existing runtime divergence needs separate adjudication',script,nontext[:2])
   initialfields={tuple(x['address']):x for x in fields(json.loads(initial))}
   aligned=[]
   for n,(a,b) in enumerate(zip(cf,jf)):
    orig=initialfields[tuple(a['address'])]['text'];matches=machine_pairs.get(b['text'],[])
    aligned.append({'ordinal':n,'address':a['address'],'cn_name':a['name'],'jp_name':b['name'],'actor_id':a['actor_id'],'jp_actor_id':b['actor_id'],'cn':a['text'],'jp':b['text'],'initial_import_cn':orig,'current_same_as_import':orig==a['text'],'translation_review_matches':matches})
   meta={'id':script,'chapter_id':sid,'cn_path':cp,'cn_sha':rt[cp],'jp_path':jp,'jp_sha':rt[jp],'patch_path':pp,'patch_sha':pt[pp],'cn_fields':len(cf),'jp_fields':len(jf),'same_field_addresses':True,'reader_player_bytes_equal':cn==pb,'adjudicated_intentional_witch_speech':reconciled,'nontext_diff_count':0,'already_complete_context_only':proof['complete'],'provenance':{'report_commit':IMPORT,'report_path':'magireco-translate-data-master/TRANSLATION_TEST_REPORT.md','import_blob':it[cp],'absent_from_trusted_baseline':True,'verified_human_excluded':True,'same_import_body_fields':sum(x['current_same_as_import'] for x in aligned),'total_body_fields':len(aligned)}}
   for suffix,b in [('cn',cn),('jp',ja),('import',initial)]:p=W/'review'/(script+'.'+suffix+'.json');p.parent.mkdir(exist_ok=True);p.write_bytes(b)
   save('review/'+script+'.aligned.json',aligned);save('review/'+script+'.cn-fields.json',cf);save('review/'+script+'.jp-fields.json',jf)
   text='\n'.join(str(x['ordinal'])+' '+str(x['cn_name'])+'/'+str(x['jp_name'])+'\nJ '+x['jp']+'\nC '+CTRL.sub('§',x['cn']) for x in aligned)+'\n'
   (W/'review'/(script+'.txt')).write_text(text,encoding='utf8');sources.append(meta);chapter_sources.append(meta)
  chapters.append({'story_id':sid,'title':chapter.get('title'),'source_identity':chapter['source_identity'],'paths':paths,'script_ids':[x['id'] for x in chapter_sources],'fields':sum(x['cn_fields'] for x in chapter_sources)})
  print(sid,len(paths),chapters[-1]['fields'],chapter.get('title'),flush=True)
 for filename,args in [('initial-diff.bin',('diff','--binary')),('initial-staged.bin',('diff','--cached','--binary')),('initial-status-z.bin',('status','--porcelain=v1','-z'))]:(W/filename).write_bytes(git(*args))
 dirty=git('diff','--name-only','-z').decode().split('\0');save('dirty-tracked-hashes.json',{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in dirty if p})
 save('bases.json',bases);save('reader-tree.json',rt);save('patch-tree.json',pt);save('review-sources.json',sources);save('chapters.json',chapters)
 previous=json.loads((PREVIOUS/'published-package-receipt.json').read_bytes());assert previous['version']==3321;save('baseline-delivery.json',json.loads((PREVIOUS/'delivery-state.json').read_bytes()) | {'scenario_version':previous['version'],'package':previous['package'],'player_data_commit':previous['cn_patch_commit']})
 save('progress.json',{'batch':'20261002-semantic-batch10-ai-only','task_id':'tsk_c70dbee3ad67c9ad','stage':'review','checkpoint':'Frozen 10 complete machine-test-origin chapters; no new semantic corrections yet','selected_chapters':len(chapters),'selected_scenes':len(sources),'selected_cn_fields':sum(x['cn_fields'] for x in sources),'reviewed':[],'reviewed_fields':0,'changed_fields':0,'target_version':3322})
 save('provenance.json',{'origin_commit':IMPORT,'trusted_baseline':TRUSTED,'source_report_path':'magireco-translate-data-master/TRANSLATION_TEST_REPORT.md','report_blob':it['magireco-translate-data-master/TRANSLATION_TEST_REPORT.md'],'report_text':rs.get(it['magireco-translate-data-master/TRANSLATION_TEST_REPORT.md']).decode('utf8'),'script_provenance':[{'id':x['id'],**x['provenance']} for x in sources],'note':'The import mixes reused human translation memory and newly generated machine text. Correct inherited wording is preserved; machine review never grants human-authorship status.'})
 rs.close();ps.close();print('FROZEN',len(chapters),len(sources),sum(x['cn_fields'] for x in sources),flush=True)
if __name__=='__main__':main()
