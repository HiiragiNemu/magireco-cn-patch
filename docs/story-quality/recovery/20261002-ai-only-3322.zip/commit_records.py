"""Exact source-pinned docs commits. Cumulative records are permitted in CN patch only."""
from pathlib import Path
import sys,json,os,datetime,hashlib
W=Path(__file__).resolve().parent;R=W.parent/'repo';sys.path.insert(0,str(W));from commit_sources import git,tree

def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def dirty_guard():
 for p,h in json.loads((W/'dirty-tracked-hashes.json').read_bytes()).items():assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h,p
 for n,a in [('initial-diff.bin',('diff','--binary')),('initial-staged.bin',('diff','--cached','--binary')),('initial-status-z.bin',('status','--porcelain=v1','-z'))]:assert git('reader',*a)==(W/n).read_bytes(),n

def commit(repo,files,tag):
 assert repo in ('reader','patch') and files
 for p,b in files.items():
  assert isinstance(b,bytes)
  assert p.startswith('docs/story-quality/') or p=='STORY_QUALITY_HANDOFF.md' or repo=='patch' and p in ['tools/story_quality_contributions.py','tools/verify_story_quality_contributions.py'],p
  if repo=='reader':assert '/contributions/' not in p and 'ai-only-census' not in p and not p.endswith('.zip'),'Cumulative/recovery archive belongs only in CN patch'
 git(repo,'fetch','origin','main');base=git(repo,'rev-parse','FETCH_HEAD').decode().strip();initial=tree(repo,base);expected={p:initial.get(p) for p in files}
 plan=json.loads((W/'repair-plan.json').read_bytes());key='reader_files' if repo=='reader' else 'runtime_files'
 for attempt in range(4):
  git(repo,'fetch','origin','main');head=git(repo,'rev-parse','FETCH_HEAD').decode().strip();cur=tree(repo,head)
  assert all(cur.get(p)==v for p,v in expected.items()),'Concurrent destination changed'
  assert all(cur[r['path']]['sha']==r['after'] for r in plan[key]),'Runtime source changed'
  env=os.environ.copy()|{'GIT_INDEX_FILE':str(W/(repo+'-'+tag+'-index-'+datetime.datetime.now().strftime('%H%M%S%f')))};git(repo,'read-tree',head,env=env);rows=[]
  for p,b in files.items():
   h=git(repo,'hash-object','-w','--stdin',data=b).decode().strip();assert h==blob(b);rows.append(('100644 '+h+'\t'+p+'\0').encode())
  git(repo,'update-index','-z','--index-info',data=b''.join(rows),env=env);t=git(repo,'write-tree',env=env).decode().strip();env|={'GIT_AUTHOR_NAME':'HiiragiNemu','GIT_AUTHOR_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com','GIT_COMMITTER_NAME':'HiiragiNemu','GIT_COMMITTER_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com'}
  c=git(repo,'commit-tree',t,'-p',head,data=('docs(story): '+tag+'3322; cumulative records in CN patch only [skip ci]\n').encode(),env=env).decode().strip();new=tree(repo,c)
  assert all(new[p]==v for p,v in cur.items() if p not in files) and all(new[p]['sha']==blob(b) for p,b in files.items())
  try:git(repo,'push','origin',c+':refs/heads/main')
  except RuntimeError:
   if attempt==3:raise
   continue
  git(repo,'fetch','origin','main');rem=tree(repo,'FETCH_HEAD');assert all(rem[p]['sha']==blob(b) for p,b in files.items())
  if repo=='reader':git(repo,'merge','--ff-only',c);dirty_guard()
  record={'repository':repo,'parent':head,'commit':c,'files':len(files),'remote_verified':True,'non_target_tree_preserved':True,'cumulative_storage':'CN patch only'};(W/(tag+'-'+repo+'-commit.json')).write_bytes(enc(record));print('COMMITTED_RECORDS',json.dumps(record),flush=True);return c
 raise RuntimeError('Could not safely advance main')

def contributions():
 assert not (W/'contributions-3322-patch-commit.json').exists(),'Already committed; verify instead'
 folder=W/'contributions-3322';v=json.loads((folder/'verification.json').read_bytes());assert v['passed'] and v['checks']==19
 s=v['source_summary'];assert s['last_published_scenario_version']==3322 and s['confirmed_ai_fully_reviewed']==694 and s['completed_before_takeover']==48 and s['legacy_unique_registered_ids']==498
 root='docs/story-quality/contributions/';files={root+p.name:p.read_bytes() for p in folder.iterdir() if p.is_file()};files[root+'snapshots/3322-summary.json']=(folder/'summary.json').read_bytes()
 git('patch','fetch','origin','main');current=tree('patch','FETCH_HEAD');assert root+'snapshots/3322-summary.json' not in current,'Immutable snapshot conflict'
 oldsnap=git('patch','show','FETCH_HEAD:'+root+'snapshots/3321-summary.json');assert json.loads(oldsnap)['last_published_scenario_version']==3321
 for n in ['20261001-ai-only-census.json.gz','20261002-ai-only-census.json.gz']:files['docs/story-quality/'+n]=(W/'Reader_AI_Full_Ledger_20261002.json.gz').read_bytes()
 files['tools/story_quality_contributions.py']=(W/'contribution_ledger.py').read_bytes();files['tools/verify_story_quality_contributions.py']=(W/'verify_contributions.py').read_bytes()
 c=commit('patch',files,'contributions-3322');assert git('patch','show',c+':'+root+'snapshots/3321-summary.json')==oldsnap
 record=json.loads((W/'contributions-3322-patch-commit.json').read_bytes());record['ledger_sha256']=v['ledger_sha256'];record['previous_snapshot_unchanged']=True;(W/'contributions-3322-patch-commit.json').write_bytes(enc(record));dirty_guard()
if __name__=='__main__':contributions()
