"""Run the repository's unmodified complete check after the bounded isolated build."""
from pathlib import Path
import subprocess,os,json,re,time,datetime,hashlib
W=Path(__file__).resolve().parent;D=W/'delivery';R=D/'repo';site=R/'website'
for attempt in range(180):
 f=D/'build-steps.json'
 if f.exists():
  steps=json.loads(f.read_text(encoding='utf-8-sig'))
  # PowerShell emits a single object until the second build step finishes.
  if isinstance(steps,dict):steps=[steps]
  assert all(x['exit_code']==0 for x in steps),'A build step failed; do not run final QA'
  if len(steps)==12:break
 time.sleep(5)
else:raise TimeoutError('Build completion not yet available; bounded QA invocation stopped')
rev=(D/'source-revision.txt').read_text().strip();env=os.environ.copy()|{'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','NEXT_TELEMETRY_DISABLED':'1','NODE_OPTIONS':'--max-old-space-size=8192','SOURCE_COMMIT_SHA':rev,'PAGES_ENVIRONMENT':'production'}
print('FULL_QA_START',rev,flush=True)
log=D/'full-check.log'
with log.open('w',encoding='utf8') as out:p=subprocess.run(['cmd','/c','npm','run','check'],cwd=site,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=900)
s=log.read_text(encoding='utf8');assert p.returncode==0,s[-5000:]
py=[int(x) for x in re.findall(r'Ran (\d+) tests?',s)];node=[int(x) for x in re.findall(r'(?:#|ℹ) tests (\d+)',s)];skipped=re.findall(r'OK \(skipped=(\d+)\)',s)
assert py and node,(py,node,s[-3000:]);assert max(py)==611 and max(node)==730,(py,node)
subprocess.run(['python','-X','utf8',str(D/'source_guard.py'),'after-qa'],cwd=R,env=env,check=True,timeout=300)
plan=json.loads((D/'online-exact-plan.json').read_bytes()) if (D/'online-exact-plan.json').exists() else None
report={'source_revision':rev,'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python_tests':max(py),'python_skipped':max(map(int,skipped),default=0),'python_failures':0,'node_tests':max(node),'node_failures':0,'lint':True,'typecheck':True,'feature_policy':True,'production_dependency_audit_vulnerabilities':0 if 'found 0 vulnerabilities' in s else 'see_unmodified_npm_audit_log','source_or_test_code_modified_to_pass':False,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
if plan:report['release_asset_hashes_after_qa']=len(plan['checks'])
(D/'full-check-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('FULL_QA_PASS',json.dumps(report,ensure_ascii=False),flush=True)
