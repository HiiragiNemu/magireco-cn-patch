"""Validate92 actual full reads;89 new scripts, two precisely adjudicated Reader-only restorations."""
from pathlib import Path
import sys,json,gzip,hashlib,subprocess,datetime
W=Path(__file__).resolve().parent;ROOT=W.parent;R=ROOT/'repo'
sys.path[:0]=[str(W),str(ROOT/'semantic-batch03-20261001'),str(ROOT/'severe-5109-20261001')]
from exact_json import apply,blob
from translation_rules import validate,execution_tokens,color_types
from collect_review import fields
from census import Store
from reconciliation_guard import check as reconcile

def read(n):return json.loads((W/n).read_bytes())
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def save(n,x):(W/n).write_bytes(enc(x))
def main():
 p=read('repair-plan.json');t=read('text-plan.json');rt=read('reader-tree.json');pt=read('patch-tree.json');render=read('reader-render-validation.json');sources=read('review-sources.json');store=Store()
 assert len(sources)==len(p['reviewed_stories'])==len(p['completed_review_stories'])==92 and not p['pending_adjudication_stories']
 assert len({s['chapter_id'] for s in sources})==10 and sum(s['cn_fields'] for s in sources)==p['reviewed_fields']==4731
 assert len(p['reader_files'])==len(p['runtime_files'])==89 and p['changed_fields']==1732
 assert sum(len(s['operations']) for s in p['runtime_files'])==1730
 assert render['passed'] and render['actualParser'] and len(render['files'])==92 and render['restoredPreviouslyEmptyDisplayFields']==0
 assert not t['holds'] and not t['missing'] and len(t['files'])==22 and t['physical_field_span_edits']==4776
 for pattern,n in [('test_translation_rules.py',23),('test_reconciliation_guard.py',9)]:
  test=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(W),'-p',pattern,'-v'],cwd=W,capture_output=True,text=True,encoding='utf8');(W/(pattern+'.log')).write_text(test.stdout+test.stderr,encoding='utf8');assert test.returncode==0 and ('Ran '+str(n)+' tests') in test.stderr
 test=subprocess.run(['node','--test',str(W/'test_reader_recovery.cjs'),str(W/'test_narrator_recovery.cjs')],cwd=W,capture_output=True,text=True,encoding='utf8');(W/'reader-recovery-tests.log').write_text(test.stdout+test.stderr,encoding='utf8');assert test.returncode==0 and 'tests 17' in test.stdout and 'fail 0' in test.stdout
 decisions={s['id']:read('review/'+s['id']+'.edits.json') for s in sources};rfiles={f['path']:f for f in p['reader_files']};pfiles={Path(f['path']).stem:f for f in p['runtime_files']};contexts=[];placeholders=0
 for s in sources:
  d=decisions[s['id']];assert d['reviewed_all_fields'] and d['source_cn_blob']==s['cn_sha'] and d['source_jp_blob']==s['jp_sha'] and d['field_count']==s['cn_fields']
  assert not d.get('name_edits')
  a=(W/'originals/reader'/s['cn_path']).read_bytes();b=(W/'stage/reader'/s['cn_path']).read_bytes();assert blob(a)==s['cn_sha']
  if s['already_complete_context_only']:
   contexts.append(s);assert not d['edits'] and a==b and s['cn_path'] not in rfiles and s['id'] not in pfiles
  else:assert s['cn_path'] in rfiles and s['id'] in pfiles
  af,bf=fields(json.loads(a)),fields(json.loads(b));assert len(af)==len(bf)==s['cn_fields']
  for x,y in zip(af,bf):
   assert x['address']==y['address'] and x['text'].count('userName')==y['text'].count('userName');placeholders+=x['text'].count('userName')
   assert execution_tokens(x['text'])==execution_tokens(y['text']) and color_types(x['text'])==color_types(y['text'])
 assert len(contexts)==3 and sum(s['cn_fields'] for s in contexts)==202
 assert {s['id'] for s in contexts}=={'510802-6_t5Dx9','510803-7_MTX4v','510804-3_zCzKI'}
 for repo,key in [('reader','reader_files'),('patch','runtime_files')]:
  for f in p[key]:
   a=(W/'originals'/repo/f['path']).read_bytes();b=(W/'stage'/repo/f['path']).read_bytes();assert blob(a)==f['before'] and blob(b)==f['after']
   validate(a,b,f['operations']);assert apply(a,f['operations'])==b and apply(b,[[at,new,old] for at,old,new in f['operations']])==a
 for s in sources:assert (W/'stage/reader'/s['cn_path']).read_bytes()==(W/'stage/patch'/s['patch_path']).read_bytes()
 special=next(s for s in sources if s['id']=='511420-6_Qp0aZ');rf=rfiles[special['cn_path']];pf=pfiles[special['id']]
 reconciliation=reconcile((W/'originals/reader'/rf['path']).read_bytes(),(W/'originals/patch'/pf['path']).read_bytes(),(W/'review'/('511420-6_Qp0aZ.jp.json')).read_bytes(),(W/'stage/reader'/rf['path']).read_bytes(),rf['operations'],pf['operations'])
 for f in t['files']:
  a=store.get(f['before']);b=(W/'stage/reader'/f['path']).read_bytes();assert blob(b)==f['after'];bom=b'\xef\xbb\xbf' if b.startswith(b'\xef\xbb\xbf') else b'';undo=b[len(bom):].decode()
  for e in sorted(f['edits'],key=lambda x:x['after_start'],reverse=True):
   assert undo[e['after_start']:e['after_end']]==e['after_text'];undo=undo[:e['after_start']]+e['before_text']+undo[e['after_end']:]
  assert bom+undo.encode()==a
 authorized=json.loads((R/'docs/reader-availability-local-20260929.json').read_bytes())['protected_source_failure']['paths'];assert len(authorized)==196
 changed=set(rfiles)|{f['path'] for f in t['files']};assert not set(authorized)&changed
 for path in authorized:assert blob((R/path).read_bytes())==rt[path]
 v4=json.loads((R/'manifests/authoritative_scenario_runtime_repairs.v1.json').read_bytes())['entries'];assert len(v4)==43;protected={}
 for f in v4:
  path=f['target_path'];assert path not in changed and blob((R/path).read_bytes())==rt[path]
  peers=[z for z in pt if z.startswith('madomagi/resource/scenario/json/adv/') and Path(z).name==Path(path).name];assert len(peers)==1;protected[peers[0]]=pt[peers[0]]
 assert not set(protected)&{f['path'] for f in p['runtime_files']}
 for path,h in read('dirty-tracked-hashes.json').items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==h
 anchors={'510802-4_t5Dx9':['全裸祭'],'510803-1_MTX4v':['荧光棒'],'510803-4_MTX4v':['十边球'],'510804-7_zCzKI':['梨花花','彩羽羽'],'510805-4_3SpcM':['从下面托住烟花'],'511120-3_5eVzV':['明日屋'],'511410-11_ycKqc':['小八'],'511420-11_Qp0aZ':['交换遗书'],'512610-0':['阿什莉·泰勒'],'512620-7_HxTD7':['不想要自己送的礼物'],'512620-11_HxTD7':['没有危险','情感能量']}
 for sid,terms in anchors.items():
  final=(W/'review'/(sid+'.final.txt')).read_text(encoding='utf8').replace('@','')
  for term in terms:assert term in final,(sid,term)
 # Scripted witch gibberish is intentional; every restored literal equals the JP at the same address.
 witch=[]
 for sid,ordinals in [('511420-6_Qp0aZ',[40,43,68,71]),('511420-7_Qp0aZ',[6,10,37])]:
  s=next(s for s in sources if s['id']==sid);jp=json.loads((W/'review'/(sid+'.jp.json')).read_bytes());cn=json.loads((W/'stage/reader'/s['cn_path']).read_bytes());af=fields(cn);jf=fields(jp)
  for ordinal in ordinals:
   assert af[ordinal]['address']==jf[ordinal]['address'] and af[ordinal]['text']==jf[ordinal]['text'];witch.append({'id':sid,'ordinal':ordinal,'address':af[ordinal]['address'],'source_literal':jf[ordinal]['text']})
 save('intentional-witch-literals.json',{'reader_restored':7,'runtime_restored':5,'runtime_two_already_correct':reconciliation,'literals':witch})
 inputs=p['inputs']|t.get('inputs',{})
 for path in authorized:inputs[path]=rt[path]
 for f in v4:inputs[f['target_path']]=rt[f['target_path']]
 for path in ['docs/reader-availability-local-20260929.json','manifests/authoritative_scenario_runtime_repairs.v1.json']:inputs[path]=rt[path]
 save('reader-inputs.json',inputs);save('protected-v4.json',protected)
 now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 v={'schema':4,'batch':p['batch'],'validated_at':now,'indexed_chapters_complete':10,'scenes_full_read':92,'complete_scenes_reviewed':92,'new_complete_scenes':89,'previous_complete_context_scenes':3,'new_reviewed_fields':4529,'context_fields':202,'pending_source_adjudication':[],'display_fields_reviewed':4731,'display_fields_revised':1732,'body_fields_revised':1732,'runtime_body_fields_revised':1730,'reader_only_original_literal_restorations':2,'intentional_witch_literals_restored_reader':7,'intentional_witch_literals_restored_runtime':5,'explicit_speaker_label_repairs':0,'display_only':True,'exact_reverse_to_original_bytes':True,'reader_player_converged_exact_bytes':92,'nontext_structure_actor_identity_and_audio_unchanged':True,'AI_import_source_verified':True,'executable_tags_and_highlight_types_unchanged':True,'player_name_placeholders_preserved':placeholders,'actual_reader_parser_files':92,'actual_reader_events_and_audio_metadata_unchanged_except_source_proven_missing_display':True,'restored_previously_empty_display_fields':0,'restored_display_explanation':'No new display events. Seven pre-existing witch speech literals restored exactly from Japanese;two player literals already correct and left byte-identical. Source-bound independent reverse proof for each repository.','specialized_tests_passed':23,'additional_missing_display_contract_tests':17,'source_reconciliation_refusal_tests':9,'reader_txt_files':22,'reader_txt_field_spans':4776,'historical_full_section_baselines':len(read('historical-text-baselines.json')),'multiline_artifact_spans':t['multiline_artifact_spans'],'txt_missing_fields':0,'txt_alignment_holds':0,'protected_v4_unchanged':43,'protected_authorized_cn_unchanged':196,'unrelated_dirty_paths_unchanged':True,'review_method':p['review_method'],'official_or_human_provenance_not_asserted':True,'published':False,'whole_corpus_complete':False,'device_gameplay_verified':False,'changed_runtime_scripts':89,'new_complete_unchanged_scripts':[]}
 save('validation.json',v)
 evidence={'validation':v,'plan':p,'text_plan':t,'historical_baselines':read('historical-text-baselines.json'),'decisions':decisions,'provenance':read('provenance.json'),'chapters':read('chapters.json'),'source_reconciliation':read('source-reconciliation.json'),'intentional_witch_literals':read('intentional-witch-literals.json'),'missing_display_restoration':read('missing-display-restoration.json'),'name_refinements':read('final-name-refinements.json'),'trusted_terms':{f.name:json.loads(f.read_bytes()) for f in W.glob('trusted-*-names.json')}|{f.name:json.loads(f.read_bytes()) for f in W.glob('trusted-*-nicknames.json')}}
 report='''# AI-only batch10: validated before3322

10primary chapters/92scripts/4731fields fully read against Japanese.89new complete scripts/4529fields;3prior complete contexts/202fields unchanged and not recounted.1732Reader body changes vs1730player changes:two player witch literals already exactly match Japanese, so only Reader needs those restorations. All92finalReader/player scripts converge to identical bytes with independent original-blob reversal. No labels,new events,actor IDs,execution controls or audio changes.

Whole5108festival5chapters31scripts;511120Girls in the Hood lower11scripts;5114Yachiyo/Mifuyu origin upper+lower28scripts;5126Japanese Horror upper+lower22scripts. Only proven machine-origin text reviewed;correct inherited translations and original English lines retained.22source/webTXT files/4776spans and compilation510801-05 synchronized by complete-section matching,15validated historical baselines.43V4/196authorized sources and original dirty state preserved.

23translation refusal tests,17recovery refusal tests,9exact reconciliation refusal tests and92real Reader parser comparisons pass. No runtime or original repository tests altered. This is source validation,not publication or device animation acceptance. Cumulative contributions and full census/recovery are stored ONLY in CN patch;Reader/public retain single-batch evidence and pointers.
'''
 root='manifests/story_quality_semantic_batch10_ai_only_20261002';files={root+'.json':enc(v),root+'_evidence.json.gz':gzip.compress(enc(evidence),mtime=0),'docs/story-quality/20261002-semantic-batch10-validated.md':report.encode()}
 for repo in ['reader','patch']:
  for path,data in files.items():q=W/'stage'/repo/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
 for f in (W/'review').glob('*.final.txt'):
  q=W/'stage/reader/docs/story-quality/reviewed/20261002-semantic-batch10-ai-only'/f.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
 progress=read('progress.json');progress.update(stage='validated',validation=v,checkpoint='10主话92片段4731字段全文复核，89新增；Reader1732修订/玩家1730，两条玩家原正确魔女文字不改，22TXT4776精确同步验证通过。待main与3322/Reader/ADV交付',next=['两仓既有main安全提交','实际新玩家3322发布并读回','隔离构建QA部署Reader与ADV','仅CN patch更新唯一累计台账与恢复交接，保留全部旧证据']);save('progress.json',progress);store.close();print('VALIDATED',json.dumps(v,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
