from pathlib import Path
import copy,json,unittest
from reconciliation_guard import check,ADDRESSES
from exact_json import apply
W=Path(__file__).resolve().parent
class ReconciliationBoundaryTests(unittest.TestCase):
 def setUp(self):
  plan=json.loads((W/'repair-plan.json').read_bytes());self.r=next(x for x in plan['reader_files'] if x['path'].endswith('/511420-6_Qp0aZ.json'));self.p=next(x for x in plan['runtime_files'] if x['path'].endswith('/511420-6_Qp0aZ.json'))
  self.args=[(W/'originals/reader'/self.r['path']).read_bytes(),(W/'originals/patch'/self.p['path']).read_bytes(),(W/'review/511420-6_Qp0aZ.jp.json').read_bytes(),(W/'stage/reader'/self.r['path']).read_bytes(),copy.deepcopy(self.r['operations']),copy.deepcopy(self.p['operations'])]
 def test_exact_two_literals_and_all_reviewed_changes_converge(self):self.assertEqual(len(check(*self.args)),2)
 def test_reader_baseline_drift_rejected(self):
  self.args[0]+=b' ';self.assertRaises(AssertionError,check,*self.args)
 def test_player_baseline_drift_rejected(self):
  self.args[1]+=b' ';self.assertRaises(AssertionError,check,*self.args)
 def test_japanese_baseline_drift_rejected(self):
  self.args[2]+=b' ';self.assertRaises(AssertionError,check,*self.args)
 def test_rewriting_preserved_player_literal_rejected(self):
  a=list(ADDRESSES[0]);v=json.loads(self.args[3]);old=v['story']['group_1'][51]['textLeft'];self.args[3]=apply(self.args[3],[[a,old,'不应翻译的魔女文字']]);self.assertRaises(AssertionError,check,*self.args)
 def test_recording_unchanged_player_literal_rejected(self):
  a=list(ADDRESSES[0]);v=json.loads(self.args[1]);old=v['story']['group_1'][51]['textLeft'];self.args[5].append([a,old,old]);self.assertRaises(AssertionError,check,*self.args)
 def test_missing_reader_restoration_rejected(self):
  self.args[4]=[x for x in self.args[4] if tuple(x[0])!=ADDRESSES[0]];self.assertRaises(AssertionError,check,*self.args)
 def test_missing_player_semantic_operation_rejected(self):
  self.args[5].pop();self.assertRaisesRegex(ValueError,'Unrecorded JSON change',check,*self.args)
 def test_unrecorded_runtime_node_change_rejected(self):
  v=json.loads(self.args[3]);v['unexpected_node']=True;self.args[3]=json.dumps(v,ensure_ascii=False).encode();self.assertRaisesRegex(ValueError,'Unrecorded JSON change',check,*self.args)
if __name__=='__main__':unittest.main()
