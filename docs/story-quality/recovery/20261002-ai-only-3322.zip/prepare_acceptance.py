"""Bind live acceptance to the newly built source, covering both primary and compilation routes."""
from pathlib import Path
import ast,json
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch09-ai-only-20261002';D=W/'delivery'
rev=json.loads((W/'reader-commit.json').read_bytes())['commit'];assert (D/'source-revision.txt').read_text().strip()==rev
assert (D/'source-preservation-after-build.json').exists()
p=D/'deploy_verified_snapshot.py';s=p.read_text(encoding='utf8');old="assert changed and set(changed)<=allowed,'Non-handoff source changed after build'";assert old in s;s=s.replace(old,"assert changed and all(p=='STORY_QUALITY_HANDOFF.md' or p.startswith('docs/story-quality/') for p in changed),'Non-handoff source changed after build'");ast.parse(s);p.write_text(s,encoding='utf8')
old=json.loads((O/'delivery/online-verification-targets.json').read_bytes());plan=json.loads((W/'repair-plan.json').read_bytes());text=json.loads((W/'text-plan.json').read_bytes())
old.update(source_revision=rev,changed_paths=sorted(set(old['changed_paths'])|{x['path'] for x in plan['reader_files']}),committed_txt_paths=sorted(set(old['committed_txt_paths'])|{x['path'] for x in text['files'] if x['path'].startswith('website/public/')}));(D/'online-verification-targets.json').write_text(json.dumps(old,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
targets=[['510801-1_ncQTe', '怯场'], ['510802-7_t5Dx9', '耳环'], ['510803-1_MTX4v', '荧光棒'], ['510804-6_zCzKI', '我们两个人一起看烟花'], ['510805-4_3SpcM', '从下面托住烟花'], ['510805-4_3SpcM', '从下面托住烟花', '510801-05'], ['511120-3_5eVzV', '明日屋'], ['511120-11_5eVzV', '和往常一样的昨天'], ['511410-11_ycKqc', '小八'], ['511410-13_ycKqc', '破绽'], ['511420-6_Qp0aZ', '縺雁燕ｑ溘'], ['511420-11_Qp0aZ', '交换遗书'], ['511420-13_Qp0aZ', '信纸套装'], ['512610-0', '我是阿什莉'], ['512610-3_NTfaR', '是假的'], ['512620-2_HxTD7', '家庭影院'], ['512620-7_HxTD7', '自己送的礼物'], ['512620-11_HxTD7', '没有危险'], ['340613-3', '为了保护弱者'], ['510204-3_m4VmX', '杀了她']]
for sid,t,*route in targets:
 f=W/'review'/(sid+'.final.txt')
 if f.exists():assert t in f.read_text(encoding='utf8').replace('@',''),(sid,t)
s=(O/'browser_verify.cjs').read_text(encoding='utf8');a=s.index('const targets=');b=s.index('\n(async()=>',a)
s=s[:a]+'const targets='+json.dumps(targets,ensure_ascii=False)+".map(([sid,text,routeHint])=>{const choices=index.filter(s=>(s.json_sources_cn||[]).some(p=>path.basename(p)===sid+'.json'));const s=routeHint?choices.find(s=>String(s.id)===routeHint):choices.sort((a,b)=>a.json_sources_cn.length-b.json_sources_cn.length)[0];if(!s)throw Error('No exact route '+sid+' '+routeHint);return{sid,text,route:s.id,url:'https://magireader.pages.dev/reader/'+encodeURIComponent(s.id)+'?cn='+encodeURIComponent(s.path_cn)+'&jp='+encodeURIComponent(s.path_jp)}});"+s[b:]
s=s.replace('results.length===36','results.length===40');(W/'browser_verify.cjs').write_text(s,encoding='utf8')
s=(O/'accept_live.py').read_text(encoding='utf8').replace("b['checks']==36","b['checks']==40").replace("'BROWSER_PASS',36","'BROWSER_PASS',40");ast.parse(s);(W/'accept_live.py').write_text(s,encoding='utf8')
p=W/'release_after_build.py';s=p.read_text(encoding='utf8').replace("b['checks']==36","b['checks']==40");ast.parse(s);p.write_text(s,encoding='utf8')
(W/'browser-targets.json').write_text(json.dumps(targets,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
print('ACCEPTANCE_READY',len(targets)*2,'primary-and-compilation-browser checks',len(old['changed_paths']),'source targets',len(old['committed_txt_paths']),'web texts',flush=True)
