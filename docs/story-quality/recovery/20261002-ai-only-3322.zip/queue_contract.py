"""Repair a stale derived next-chapter preview without granting new translation reviews."""
from pathlib import Path
import copy,datetime,gzip,hashlib,json,sys,unittest
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W))
from commit_sources import git,tree

def refresh(queue,ledger,source_tree):
    rows={x['path']:x for x in ledger}
    assert len(rows)==len(ledger),'Duplicate source ledger path'
    result=copy.deepcopy(queue);kept=[];seen=set()
    for chapter in result['queue']:
        sid=chapter['story_id'];assert sid not in seen,'Duplicate chapter'
        seen.add(sid);sources=chapter['sources']
        assert len(sources)==len({s['path'] for s in sources})==chapter['script_count'],'Duplicate/incomplete source mapping'
        for source in sources:
            path=source['path'];row=rows[path]
            assert source_tree[path]['sha']==row['current_blob'],'Chinese source drift'
            assert source_tree[row['jp_path']]['sha']==row['jp_blob'],'Japanese source drift'
            source.update(cn_blob=row['current_blob'],jp_path=row['jp_path'],jp_blob=row['jp_blob'],complete=row['complete'])
        chapter['pending_scripts']=sum(not s['complete'] for s in sources)
        if chapter['pending_scripts']:kept.append(chapter)
    result['queue']=kept
    result['next_complete_chapters']=copy.deepcopy(kept[:15])
    result['remaining_queued_whole_chapters']=len(kept)
    assert all(c['pending_scripts']>0 for c in result['next_complete_chapters'])
    return result

class ResumeQueueTests(unittest.TestCase):
    def setup_data(self):
        q={'queue':[{'story_id':'a','script_count':1,'sources':[{'path':'c'}]}],'next_complete_chapters':[{'story_id':'stale'}]}
        rows=[{'path':'c','current_blob':'cn','jp_path':'j','jp_blob':'jp','complete':False}]
        t={'c':{'sha':'cn'},'j':{'sha':'jp'}}
        return q,rows,t
    def test_preview_is_derived_not_inherited(self):
        q,r,t=self.setup_data();self.assertEqual(refresh(q,r,t)['next_complete_chapters'][0]['story_id'],'a')
    def test_completed_chapter_is_removed(self):
        q,r,t=self.setup_data();r[0]['complete']=True;self.assertEqual(refresh(q,r,t)['queue'],[])
    def test_does_not_grant_semantic_completion(self):
        q,r,t=self.setup_data();refresh(q,r,t);self.assertFalse(r[0]['complete'])
    def test_chinese_drift_rejected(self):
        q,r,t=self.setup_data();t['c']['sha']='new'
        with self.assertRaises(AssertionError):refresh(q,r,t)
    def test_japanese_drift_rejected(self):
        q,r,t=self.setup_data();t['j']['sha']='new'
        with self.assertRaises(AssertionError):refresh(q,r,t)
    def test_duplicate_chapter_rejected(self):
        q,r,t=self.setup_data();q['queue']*=2
        with self.assertRaises(AssertionError):refresh(q,r,t)
    def test_duplicate_script_rejected(self):
        q,r,t=self.setup_data();q['queue'][0]['sources']*=2;q['queue'][0]['script_count']=2
        with self.assertRaises(AssertionError):refresh(q,r,t)

