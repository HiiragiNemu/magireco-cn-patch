from pathlib import Path
import sys,json,collections
W=Path(__file__).resolve().parent;R=W.parent/'repo';P=W.parent/'semantic-batch03-20261001';sys.path.insert(0,str(P));from census import Store,sequence_fp,display
rt=json.loads((W/'reader-tree.json').read_bytes());pt=json.loads((W/'patch-tree.json').read_bytes());plan=json.loads((W/'repair-plan.json').read_bytes())
for r in plan['reader_files']:rt[r['path']]=r['after']
for r in plan['runtime_files']:pt[r['path']]=r['after']
current=json.loads((W/'current-confirmed-machine-ledger.json').read_bytes());rstore=Store();pstore=Store(True);byid=collections.defaultdict(list)
for p in pt:
 if p.startswith('madomagi/resource/scenario/json/adv/') and p.endswith('.json'):byid[Path(p).stem].append(p)
results=[]
for r in current:
 pp=byid[r['script_id']]
 if len(pp)!=1:results.append({'path':r['path'],'status':'player_mapping_unresolved','player_paths':pp,'review_complete':r['complete']});continue
 p=pp[0];a=rstore.get(rt[r['path']]);b=pstore.get(pt[p]);samebody=sequence_fp(json.loads(a))==sequence_fp(json.loads(b));labelsbody=[(x[-1],v) for x,v in display(json.loads(a))]==[(x[-1],v) for x,v in display(json.loads(b))]
 results.append({'path':r['path'],'player_path':p,'reader_blob':rt[r['path']],'player_blob':pt[p],'status':'exact_bytes' if a==b else 'same_full_display' if labelsbody else 'same_body_different_labels' if samebody else 'body_difference_requires_separate_sync','review_complete':r['complete']})
extras=json.loads((P/'patch-alias-census.json').read_bytes());extra=[];machine={x['path'] for x in current}
for r in extras:
 assert pt[r['path']]==r['blob'],'Extra source changed; refresh census'
 exact=[p for p in r['exact_reader_paths'] if rt.get(p)==r['blob']];body=[p for p in r['identical_body_reader_paths'] if p in rt]
 item={'path':r['path'],'script_id':r['script_id'],'player_blob':pt[r['path']],'body_fields':r['body_fields'],'exact_current_reader_paths':exact,'body_only_reader_paths':body,'possible_machine_aliases':sorted((set(exact)|set(body))&machine),'semantic_review_newly_granted':False}
 item['status']='no_body' if not r['body_fields'] else 'exact_reader_mirror' if exact else 'body_only_alias_needs_runtime_identity_validation' if body else 'extra_body_provenance_unresolved';extra.append(item)
summary={'confirmed_reader_scripts':len(results),'player_binding_counts':dict(collections.Counter(r['status'] for r in results)),'completed_scripts_with_player_body_differences':[r['path'] for r in results if r['review_complete'] and r['status'] not in ('exact_bytes','same_full_display')],'extra_player_ids':len(extra),'extra_player_counts':dict(collections.Counter(r['status'] for r in extra)),'extra_possible_machine_aliases':[r['path'] for r in extra if r['possible_machine_aliases']],'note':'Reader/player mirror paths are linked, not counted as separate stories. Exact current field sequence comparison is structural delivery evidence, not a substitute for source-bound semantic review.'}
for name,obj in [('cross-repo-machine-binding.json',results),('patch-only-provenance-queue.json',extra),('cross-repo-machine-summary.json',summary)]: (W/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
rstore.close();pstore.close();print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
