"""Save exact current-batch recovery, while referencing CN patch-only cumulative ledgers."""
from pathlib import Path
import subprocess,json,gzip,datetime,sys
W=Path(__file__).resolve().parent;R=W.parent/'repo'
def git(*a):return subprocess.check_output(['git',*a],cwd=R,timeout=120)
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def main():
 note=sys.argv[1];now=datetime.datetime.now(datetime.timezone.utc).isoformat();p=json.loads((W/'progress.json').read_bytes());p.update(checkpoint=note,updated_at=now);(W/'progress.json').write_bytes(enc(p))
 git('fetch','origin','main');assert git('rev-parse','HEAD').strip()==git('rev-parse','FETCH_HEAD').strip()
 paths=['STORY_QUALITY_HANDOFF.md','docs/story-quality/CONTINUATION.md','docs/story-quality/CONTINUATION_STATE.json','docs/story-quality/20261002-ai-only-batch10.md','docs/story-quality/recovery/20261002-ai-only-batch10-checkpoint.json.gz']
 assert not git('diff','--name-only','--',*paths).strip()
 st=json.loads((R/paths[2]).read_bytes());st.update(updated_at=now,checkpoint=note,active_batch=p,task_id=p['task_id']);st['paths']['current_batch']=str(W)
 st['contribution_storage_policy']='CN patch only';st['contribution_ledger']={'repository':'HiiragiNemu/magireco-cn-patch','entry':'docs/story-quality/contributions/README.md','census':'docs/story-quality/20261002-ai-only-census.json.gz','include_pre_takeover':True}
 st['pending']=['完成本批确认AI整话；暂存不等于发布','新内容完整验证后发布3322并独立核验Reader/ADV','累计贡献和全量已处理/待处理清单只提交CN patch，不回填Reader或发行仓']
 if (W/'delivery-state.json').exists():st.update(json.loads((W/'delivery-state.json').read_bytes()))
 (R/paths[2]).write_bytes(enc(st))
 root=f'''# Reader剧情质量接续入口\n\n更新：{now}\n\n{note}\n\n本批 `{W}`；工作区 `{R}`；任务 `{p['task_id']}`。已冻结{p['selected_chapters']}整话/{p['selected_scenes']}独立片段/{p['selected_cn_fields']}正文显示字段。当前全文审读{len(p.get('reviewed',[]))}片段、{p.get('reviewed_fields',0)}字段、修订{p.get('changed_fields',0)}字段，发布状态请读STATE，不把暂存当已交付。\n\n上批3321已正式发布，两条普通玩家入口一致。下一批新修订完成后发布3322，不重复抬版发行旧内容。只修确认AI，官方/人工/来源未明不重译；保全43V4、196授权中文、所有并行/未知本地改动。仅既有main，无分支/PR/强推。不改L2D/AIO/APK/字体。\n\n**累计贡献和全量已处理/待处理台账只在 `HiiragiNemu/magireco-cn-patch:docs/story-quality/contributions/README.md` 保存**。完整来源清单与含累计台账的旧恢复包也在CN patch；Reader和ProgettoMagius-1仅留指针和必要单批发布证据。不得再镜像全量台账。接手前成果须保留。\n\n先读本入口、CONTINUATION、STATE及20261002-ai-only-batch10.md；每个可恢复断点和最终回复前更新。实机动画未验收，全项目未完成。\n'''
 (R/paths[0]).write_text(root,encoding='utf8');cont=(R/paths[1]).read_text(encoding='utf8');a='<!-- AI-ONLY-BATCH10-START -->';b='<!-- AI-ONLY-BATCH10-END -->';block=a+'\n'+root+'\n'+b
 if a in cont:cont=cont[:cont.index(a)]+block+cont[cont.index(b)+len(b):]
 else:head,tail=cont.split('\n',1);cont=head+'\n\n'+block+'\n\n'+tail
 (R/paths[1]).write_text(cont,encoding='utf8');(R/paths[3]).write_text(root,encoding='utf8')
 evidence={'schema':1,'at':now,'batch_only':True,'progress':p,'bases':json.loads((W/'bases.json').read_bytes()),'review_sources':json.loads((W/'review-sources.json').read_bytes()),'decisions':{f.stem:json.loads(f.read_bytes()) for f in (W/'review').glob('*.edits.json')},'plan':json.loads((W/'repair-plan.json').read_bytes()) if (W/'repair-plan.json').exists() else None,'helpers':{n:(W/n).read_text(encoding='utf8') for n in ['collect.py','decisions.py','stage.py','review_io.py','record_raw.py','checkpoint.py']}}
 (R/paths[4]).write_bytes(gzip.compress(enc(evidence),mtime=0));git('add','--',*paths);git('commit','--only','-m','docs(handoff): '+note+' [skip ci]','--',*paths);git('push','origin','HEAD:refs/heads/main');sha=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==sha
 (W/'checkpoint-commit.json').write_bytes(enc({'commit':sha,'note':note,'at':now}));print('CHECKPOINT',sha,note,flush=True)
if __name__=='__main__':main()
