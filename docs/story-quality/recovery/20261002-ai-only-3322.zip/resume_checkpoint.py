"""Persist the recovered four-channel state; never republish an existing package."""
from pathlib import Path
import json,datetime,sys
W=Path(__file__).resolve().parent;R=W.parent/'repo';sys.path.insert(0,str(W))
from commit_records import commit,dirty_guard,enc

def main():
 dirty_guard();now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 audit=json.loads((W/'resume-20261002-verification.json').read_bytes());p=json.loads((W/'progress.json').read_bytes());pkg=json.loads((W/'published-package-receipt.json').read_bytes());run=json.loads((W/'publisher-run.json').read_bytes())
 assert audit['no_republish_needed'] and pkg['version']==3322 and len(p['reviewed'])==92
 note='中断恢复：92片段全文校订及3322玩家包已完成，两条普通玩家入口实读一致；CN patch累计台账已入库。Reader目前仍为3321，继续使用已验证的9f881c9b隔离构建部署并验收，随后ADV登记和最终交接。不得重复发包或计算校订。'
 p.update(stage='publishing',checkpoint=note,updated_at=now,resumed_at=now,player_package_published=True,player_package_version=3322,resume_evidence='resume-20261002-verification.json',next=['将已验证3322固定源码部署Reader并完整验收','公开读回ADV登记','只在CN patch保存累计台账及最终恢复包，完成四路交接'])
 (W/'progress.json').write_bytes(enc(p))
 state=json.loads((R/'docs/story-quality/CONTINUATION_STATE.json').read_bytes())
 state.update(updated_at=now,checkpoint=note,active_batch=p,scenario_version=3322,package=pkg['package'],package_publication_run=run['id'],cn_patch_source_commit=pkg['cn_patch_commit'],player_data_commit=pkg['cn_patch_commit'],reader_data_commit=pkg['reader_commit'],reader_site_uploaded_for_active_batch=False,adv_registered_for_active_batch=False,pending=p['next'])
 state['resume_status']={'player_version':3322,'reader_target_source':pkg['reader_commit'],'reader_observed_source':'20c748f726593711a2e29ad99d10f60f08a98db9','adv_observed_source':'20c748f726593711a2e29ad99d10f60f08a98db9','evidence':'docs/story-quality/20261002-batch10-resume-verification.json','new_review_work_claimed_in_recovery':False}
 root=f'''# Reader剧情质量接续入口\n\n更新：{now}\n\n{note}\n\n本批10主话92片段4731字段已完整对照；89新完成、3旧上下文不重计。Reader1732字段、玩家1730字段修订。数据提交Reader `{pkg['reader_commit']}`，CN patch `{pkg['cn_patch_commit']}`；玩家3322已发布，Reader/ADV尚未更新，不混淆四路状态。完整构建和611Python/730Node测试已成功，继续本批 `release_after_build.py`，不运行任何旧发布入口。\n\n工作区 `{R}`；本批 `{W}`；任务 `{p['task_id']}`。\n\n累计贡献、全部已处理待处理台账和包含台账的恢复包仅保存在 `HiiragiNemu/magireco-cn-patch:docs/story-quality/contributions/README.md`。前AI成果和旧版本记录保留。Reader和发行仓仅保存必要单批证据及指针。\n\n仅确认AI剧情；不重译官方/确认人工/未知来源；保全43V4、196授权及脏工作树。既有main，不分支PR强推；不动L2D/AIO/APK/字体。实机动画未验收。每个有恢复价值的断点与最终回复前更新本入口、CONTINUATION和STATE。\n'''
 cont=(R/'docs/story-quality/CONTINUATION.md').read_text(encoding='utf8');a='<!-- AI-ONLY-BATCH10-START -->';b='<!-- AI-ONLY-BATCH10-END -->';assert a in cont and b in cont
 cont=cont[:cont.index(a)]+a+'\n'+root+'\n'+b+cont[cont.index(b)+len(b):]
 commit('reader',{'STORY_QUALITY_HANDOFF.md':root.encode(),'docs/story-quality/CONTINUATION.md':cont.encode(),'docs/story-quality/CONTINUATION_STATE.json':enc(state),'docs/story-quality/20261002-ai-only-batch10.md':root.encode(),'docs/story-quality/20261002-batch10-resume-verification.json':enc(audit)},'resume-recovery')
if __name__=='__main__':main()
