"""Retain failed live evidence and rerun unchanged acceptance, never weaken checks."""
from pathlib import Path
import sys,json,subprocess,hashlib,datetime,time
W=Path(__file__).resolve().parent;D=W/'delivery';sys.path.insert(0,str(D))
from online_verify import fetch_check
from release_control import project,summary,BASE,REV

def enc(o):return (json.dumps(o,ensure_ascii=False,indent=2)+'\n').encode()
def main():
 archive=W/'resume-first-http-failure.json'
 if not archive.exists():
  raw=(D/'online-exact-verification.json').read_bytes();first=json.loads(raw);assert first['source_revision']==REV and first['failed']==4
  archive.write_bytes(raw);(W/'resume-first-http-failure.log').write_bytes((W/'live-exact-http.log').read_bytes())
 else:first=json.loads(archive.read_bytes())
 bad=[r for r in first['results'] if not r['ok']];assert len(bad)==4 and all('HTTP Error 503' in e for r in bad for e in r['errors'])
 before=summary(project());assert before['canonical_commit']==REV and before['canonical_id']==first['deployment_id']
 specs={s['path']:s for s in json.loads((D/'online-exact-plan.json').read_bytes())['checks']};probes=[]
 for trial in range(3):
  for row in bad:
   checked=fetch_check(specs[row['path']],BASE);assert checked['ok'],checked
   probes.append({'round':trial+1,**checked})
  time.sleep(1)
 (W/'resume-failed-endpoints-exact-recheck.json').write_bytes(enc({'source_revision':REV,'deployment_id':before['canonical_id'],'checks':len(probes),'passed':True,'results':probes,'no_cache_busting':True}))
 print('ALL_FOUR_ORIGINAL_FAILURES_RECHECKED_THREE_TIMES_EXACT',flush=True)
 with (W/'live-exact-http-second.log').open('w',encoding='utf8') as log:
  r=subprocess.run([sys.executable,'-X','utf8',str(D/'online_verify.py'),'verify'],cwd=W,stdout=log,stderr=subprocess.STDOUT,timeout=1500)
 if r.returncode:raise RuntimeError('Unchanged full live acceptance failed again; preserve evidence and diagnose, do not promote')
 final=json.loads((D/'online-exact-verification.json').read_bytes());after=summary(project())
 assert final['failed']==0 and final['total']==first['total']==final['passed']==2419
 assert final['source_revision']==REV and final['deployment_id']==before['canonical_id']==after['canonical_id']
 report={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_revision':REV,'deployment_id':after['canonical_id'],'first_pass':{k:v for k,v in first.items() if k!='results'},'original_failed_paths':[r['path'] for r in bad],'original_failed_report_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'targeted_recheck_successes':len(probes),'complete_second_pass':{k:v for k,v in final.items() if k!='results'},'runtime_code_changed':False,'source_text_changed':False,'check_list_or_validation_weakened':False,'redeployed':False,'root_cause':'Initial HTTP503observed;subsequent ordinary URL exact-body checks recovered without changes. Specific server-side cause not established.'}
 (W/'resume-http-recovery.json').write_bytes(enc(report));print('FULL_HTTP_SECOND_PASS_VERIFIED',json.dumps({k:v for k,v in final.items() if k!='results'},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
