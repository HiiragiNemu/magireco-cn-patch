"""Bounded current-turn release continuation: require real QA, verify live, then register/close."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import os,subprocess,json,time
W=Path(__file__).resolve().parent;D=W/'delivery';rev=json.loads((W/'reader-commit.json').read_bytes())['commit']
for i in range(180):
 p=D/'full-check-result.json'
 if p.exists():
  q=json.loads(p.read_bytes());assert q['source_revision']==rev and q['python_failures']==q['node_failures']==0 and q['node_tests']==730 and q['python_tests']==611;break
 time.sleep(5)
else:raise TimeoutError('No successful complete QA; no production write performed')
env=os.environ.copy()|{'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','HTTPS_PROXY':'http://127.0.0.1:7897','HTTP_PROXY':'http://127.0.0.1:7897','NODE_OPTIONS':'--max-old-space-size=8192 --use-env-proxy','NEXT_TELEMETRY_DISABLED':'1'}
def run(name,args,timeout=600):
 with (W/(name+'.log')).open('w',encoding='utf8') as log:r=subprocess.run(args,cwd=W,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout)
 if r.returncode:
  tail=(W/(name+'.log')).read_text(encoding='utf8')[-7000:];print('FAILED',name,tail,flush=True);raise RuntimeError(name+' failed')
 print('PASSED',name,flush=True)
run('online-plan',['python','-X','utf8',str(D/'online_verify.py'),'plan'])
if not (D/'production-upload.json').exists():run('production-upload-control',['python','-X','utf8',str(D/'deploy_verified_snapshot.py'),'deploy'],900)
else:assert json.loads((D/'production-upload.json').read_bytes())['canonical_commit']==rev
with ThreadPoolExecutor(max_workers=2) as pool:
 futures=[pool.submit(run,'live-exact-http',['python','-X','utf8',str(D/'online_verify.py'),'verify'],1200),pool.submit(run,'live-browser-status',['python','-X','utf8',str(W/'accept_live.py')],1500)]
 for f in futures:f.result()
h=json.loads((D/'online-exact-verification.json').read_bytes());b=json.loads((W/'browser-verification.json').read_bytes());assert h['failed']==0 and h['total']==h['passed'] and b['passed'] and b['checks']==40
run('adv-final-registration',['python','-X','utf8',str(D/'deploy_verified_snapshot.py'),'promote'],300)
print('READER_PRODUCTION_AND_ADV_VERIFIED_CLOSEOUT_PENDING',flush=True)
