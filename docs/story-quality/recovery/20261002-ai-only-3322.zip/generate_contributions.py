"""Generate sole-CN-patch contribution output only after3322 actual publication."""
from pathlib import Path
import json,gzip,datetime,sys,subprocess,unittest
W=Path(__file__).resolve().parent;R=W.parent/'repo';sys.path.insert(0,str(W));from commit_sources import git,tree
from queue_contract import refresh,ResumeQueueTests
run=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ResumeQueueTests));assert run.wasSuccessful() and run.testsRun==7
p=json.loads((W/'published-package-receipt.json').read_bytes());assert p['version']==3322 and p['status']=='published_and_anonymously_verified'
gaps=json.loads((W/'Reader_AI_Full_Ledger_20261002.json').read_bytes());git('reader','fetch','origin','main');rt=tree('reader','FETCH_HEAD');q=refresh(gaps['next_full_chapter_queue'],gaps['scripts'],rt);q.update(source_revision=p['reader_commit'],updated_at=datetime.datetime.now(datetime.timezone.utc).isoformat());gaps['next_full_chapter_queue']=q;gaps['cross_repo_summary']=json.loads((W/'cross-repo-machine-summary.json').read_bytes())
assert gaps['summary']['complete']==694 and gaps['summary']['remaining']==385 and len(gaps['completed_evidence'])==694
for name,obj in [('next-ai-only-full-chapter-queue.json',q),('Reader_AI_Full_Ledger_20261002.json',gaps)]: (W/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
(W/'Reader_AI_Full_Ledger_20261002.json.gz').write_bytes(gzip.compress((W/'Reader_AI_Full_Ledger_20261002.json').read_bytes(),mtime=0))
heads={}
for repo in ['reader','patch']:git(repo,'fetch','origin','main');heads[repo]=git(repo,'rev-parse','FETCH_HEAD').decode().strip()
G='A:/StoryQuality-20260930-1739/public.git';subprocess.run(['git','--git-dir='+G,'fetch','origin','main'],cwd=R,check=True,timeout=120);heads['public']=subprocess.check_output(['git','--git-dir='+G,'rev-parse','FETCH_HEAD'],cwd=R).decode().strip()
args=['python','-X','utf8',str(W/'contribution_ledger.py'),'--reader',str(R),'--patch-git','A:/StoryQuality-20260930-1739/patch.git','--public-git',G,'--reader-ref',heads['reader'],'--patch-ref',heads['patch'],'--public-ref',heads['public'],'--last-version','3322','--census-file',str(W/'Reader_AI_Full_Ledger_20261002.json.gz'),'--output',str(W/'contributions-3322')]
subprocess.run(args,cwd=W,check=True,timeout=600)
subprocess.run(['python','-X','utf8',str(W/'verify_contributions.py'),str(W/'contributions-3322')],cwd=W,check=True,timeout=180)
s=json.loads((W/'contributions-3322/summary.json').read_bytes());assert s['confirmed_ai_fully_reviewed']==694 and s['confirmed_ai_pending']==385 and s['completed_before_takeover']==48 and s['completed_after_takeover']==646 and s['legacy_unique_registered_ids']==498
print('CANONICAL_CONTRIBUTION_GENERATION_COMPLETE',json.dumps(s,ensure_ascii=False),'NEXT',q['queue'][0]['story_id'],flush=True)
