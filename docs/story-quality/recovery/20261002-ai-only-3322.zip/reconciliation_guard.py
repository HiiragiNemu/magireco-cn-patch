"""Narrow refusal boundary: preserve two exact player/JP witch literals, not arbitrary source drift."""
import json
from exact_json import blob,apply
from translation_rules import validate
PINNED=('5139fb687ee88a8e67f5fa30641ddafcc337677d','233e78fa5451556b4db0c7440f47c911481cdbbc','0b108a9cdcf8833f407dbf717541cc5a6cc67550')
ADDRESSES=(('story','group_1',51,'textLeft'),('story','group_1',54,'textLeft'))

def at(value,address):
 for k in address:value=value[k]
 return value

def check(reader_before,player_before,jp_before,reader_after,reader_operations,player_operations):
 assert tuple(map(blob,(reader_before,player_before,jp_before)))==PINNED,'Unapproved baseline drift'
 r,p,j=map(json.loads,(reader_before,player_before,jp_before));after=json.loads(reader_after)
 reconciliation=[]
 for address in ADDRESSES:
  old,correct=at(r,address),at(p,address)
  assert correct==at(j,address) and old!=correct,'Player literal must be exact Japanese source'
  assert at(after,address)==correct,'Never rewrite the already-correct player witch literal'
  assert sum(tuple(x[0])==address for x in reader_operations)==1
  assert not any(tuple(x[0])==address for x in player_operations)
  reconciliation.append([list(address),old,correct])
 assert apply(reader_before,reconciliation)==player_before,'Only these two original literals may differ'
 validate(reader_before,reader_after,reader_operations)
 validate(player_before,reader_after,player_operations)
 assert apply(reader_before,reader_operations)==apply(player_before,player_operations)==reader_after
 assert apply(reader_after,[[a,y,x] for a,x,y in reader_operations])==reader_before
 assert apply(reader_after,[[a,y,x] for a,x,y in player_operations])==player_before
 assert len(reader_operations)==len(player_operations)+2
 return reconciliation
