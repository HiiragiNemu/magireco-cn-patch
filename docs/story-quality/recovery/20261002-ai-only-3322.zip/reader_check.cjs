const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
const {execFileSync}=require('node:child_process');
const crypto=require('node:crypto');
const {applyProvenRecovery}=require('./reader_recovery_contract.cjs');
const recovery=JSON.parse(fs.readFileSync(path.join(__dirname,'missing-display-restoration.json'))).repairs;
const root = path.join(__dirname, '..', 'repo');
async function main() {
  const parser = await import(pathToFileURL(path.join(root, 'website/lib/story-parser.ts')));
  const plan = JSON.parse(fs.readFileSync(path.join(__dirname, 'repair-plan.json')));
  const results = [];
  const sources=JSON.parse(fs.readFileSync(path.join(__dirname,'review-sources.json')));
  const files=sources.map(s=>plan.reader_files.find(f=>f.path===s.cn_path)||{path:s.cn_path,before:s.cn_sha,operations:[]});
  for (const file of files) {
    const options = {filename: path.basename(file.path), mergeConsecutiveTextLines: false};
    const read = directory => parser.parseStoryContent(fs.readFileSync(path.join(__dirname, directory, 'reader', file.path), 'utf8'), options).lines;
    const before = read('originals');
    const approvedNames = file.operations.filter(([address]) => address.at(-1).startsWith('name'));
    const nameOnly = JSON.parse(fs.readFileSync(path.join(__dirname, 'originals', 'reader', file.path), 'utf8'));
    for (const [address, oldName, newName] of approvedNames) {
      let node = nameOnly;
      for (const key of address.slice(0,-1)) node = node[key];
      if (node[address.at(-1)] !== oldName) throw Error('Speaker-label baseline mismatch');
      node[address.at(-1)] = newName;
    }
    const recovered=recovery.filter(x=>x.path===file.path);
    for(const proof of recovered){
      const jpRaw=execFileSync('git',['cat-file','blob',proof.jp_blob],{cwd:root});
      const digest=crypto.createHash('sha1').update(Buffer.from('blob '+jpRaw.length+'\0')).update(jpRaw).digest('hex');
      if(digest!==proof.jp_blob||plan.inputs[Object.keys(plan.inputs).find(p=>p.startsWith('magireco-source-master/')&&path.basename(p)===proof.script_id+'.json')]!==proof.jp_blob)throw Error('Recovery Japanese source not frozen');
      applyProvenRecovery(nameOnly,JSON.parse(fs.readFileSync(path.join(__dirname,'originals','reader',file.path))),JSON.parse(jpRaw),file,proof);
    }
    const expectedIdentity = parser.parseStoryContent(JSON.stringify(nameOnly), options).lines;
    const after = read('stage');
    const identity = lines => lines.map(x => [x.speaker, x.isHeader, x.isChoice, x.sourceGroupId, x.sourceTurnIndex, x.sourceCommand, x.audioCueId, x.audioCueIds]);
    if (JSON.stringify(identity(expectedIdentity)) !== JSON.stringify(identity(after))) throw Error('Unexpected display or voice identity change: ' + file.path);
    results.push({path: file.path, beforeLines: before.length, afterLines: after.length, eventStructurePreserved: true, restoredPreviouslyEmptyDisplayFields: recovered.length, originalSourceCommandCountUnchanged: true, explicitlyReviewedSpeakerLabels: approvedNames.length, audioMetadataPreserved: true, before, after});
  }
  fs.writeFileSync(path.join(__dirname, 'reader-render-validation.json'), JSON.stringify({passed: true, actualParser: true, restoredPreviouslyEmptyDisplayFields: recovery.length, identityComparisonIncludesOnlyExplicitSourceBoundMissingSpeech: true, files: results}, null, 2));
  console.log('Reader parser verified:', results.length);
}
main().catch(error => { console.error(error); process.exitCode = 1; });
