"""Adapt inspected release helpers to exact frozen3322 counters. This command performs no publication."""
from pathlib import Path
import ast,re,json,subprocess
W=Path(__file__).resolve().parent;O=W.parent/'semantic-batch09-ai-only-20261002';R=W.parent/'repo'
def old(n):return (O/n).read_text(encoding='utf8')
def save(n,s):
 if n.endswith('.py'):ast.parse(s)
 assert not (W/n).exists(),'Inspect rather than overwrite existing helper '+n
 (W/n).write_text(s,encoding='utf8')
def swap(s,a,b):assert a in s,a;return s.replace(a,b)
def ver(s):return s.replace('3320','__BASE__').replace('3321','3322').replace('__BASE__','3321').replace('semantic-batch08','__OLD__').replace('semantic-batch09','semantic-batch10').replace('__OLD__','semantic-batch09').replace('semantic_batch09','semantic_batch10').replace('ai-only-batch09','ai-only-batch10').replace('AI-ONLY-BATCH09','AI-ONLY-BATCH10')
p=json.loads((W/'repair-plan.json').read_bytes());assert len(p['runtime_files'])==89 and p['changed_fields']==1732 and sum(len(x['operations']) for x in p['runtime_files'])==1730
s=ver(old('commit_sources.py'));a=s.index('  message=');b=s.index('  commit=',a)
s=s[:a]+"  message='fix(story): review10 AI chapters,89 new full scenes;1732Reader and1730player body fixes [stage-only] [skip ci]\\n\\n92scripts/4731fields fully read;3prior contexts unchanged. Two previously correct player witch literals preserved while restoring Reader to exact Japanese.22TXT mirrors incl510801-05compilation synchronized. Preserve43V4/196authorized and original dirty worktree.\\n'\n"+s[b:];save('commit_sources.py',s)
s=ver(old('build_package.py')).replace('73 full reads,71 new completions,70 modified scripts,9','92 full reads,89 new completions,89 modified scripts,10')
for a,b in [('len(specs)==70','len(specs)==89'),('==2217','==1730'),('>=822','>=892'),('changed_runtime_scripts=70','changed_runtime_scripts=89'),('full_scenes_read=73','full_scenes_read=92'),('reviewed_complete_scenes=73','reviewed_complete_scenes=92'),('new_complete_scenes=71','new_complete_scenes=89'),('previous_complete_context_scenes=2','previous_complete_context_scenes=3'),('new_reviewed_fields=4044','new_reviewed_fields=4529'),('context_fields=108','context_fields=202'),('complete_indexed_chapters=9','complete_indexed_chapters=10'),('reviewed_fields=4152','reviewed_fields=4731'),('changed_chinese_fields=2217','changed_chinese_fields=1730'),('body_fields_changed=2217','body_fields_changed=1730,reader_body_fields_changed=1732,reader_only_original_literal_restorations=2,intentional_witch_literals_restored_runtime=5'),('reviewed_execution_identities_preserved=73','reviewed_execution_identities_preserved=92')]:s=swap(s,a,b)
s=swap(s,'scenario_tests=23','scenario_tests=23,source_reconciliation_refusal_tests=9');save('build_package.py',s)
s=ver(old('prepare_public.py'))
for a,b in [('v[\'display_fields_revised\']==2217','v[\'display_fields_revised\']==1732 and v[\'runtime_body_fields_revised\']==1730'),("'changed_runtime_scripts':70","'changed_runtime_scripts':89"),("'full_scenes_read':73","'full_scenes_read':92"),("'complete_scenes_reviewed':73","'complete_scenes_reviewed':92"),("'new_complete_scenes':71","'new_complete_scenes':89"),("'previous_complete_context_scenes':2","'previous_complete_context_scenes':3"),("'complete_indexed_chapters':9","'complete_indexed_chapters':10"),("'reviewed_fields':4152","'reviewed_fields':4731"),("'changed_fields':2217","'changed_fields':1730,'reader_changed_fields':1732"),("'body_fields_changed':2217","'body_fields_changed':1730,'reader_only_original_literal_restorations':2")]:s=swap(s,a,b)
s=s.replace('nine','ten').replace('9整话71新完成脚本的2217显示修正','10主话89新完成；Reader1732修正、玩家1730修正，两条玩家原正确魔女文字保留');save('prepare_public.py',s)
s=ver(old('publish_scenario_3321.py')).replace("plan['changed_runtime_scripts']==70","plan['changed_runtime_scripts']==89").replace("plan['reviewed_fields']==4152","plan['reviewed_fields']==4731").replace("plan['changed_fields']==2217","plan['changed_fields']==1730").replace("plan['complete_scenes_reviewed']==73","plan['complete_scenes_reviewed']==92").replace('nine','ten')
a=s.index("'body':");b=s.index(",'draft':",a)
s=s[:a]+"'body':'10primary chapters/92complete Japanese comparisons/4731fields.89new complete scripts;3previously completed contexts remain byte-identical.89runtime scripts corrected at1730body fields;Reader has1732changes because2old player witch literals were already correct and remain unchanged.22source/webTXT mirrors incl510801-05compilation synchronized. No new display events,labels,commands,actors,audio or execution layout.43V4/196authorized sources preserved. Cumulative inventory only in CN patch. AI-assisted proofreading is not original human authorship;device gameplay not verified.'"+s[b:];save('publish_scenario_3322.py',s)
s=old('test_public_delivery_retry.py').replace('publish_scenario_3321','publish_scenario_3322');save('test_public_delivery_retry.py',s)
s=ver(old('inspect_publisher.py')).replace('==2217','==1730').replace("p['reviewed_complete_scenes']==73","p['reviewed_complete_scenes']==92");save('inspect_publisher.py',s)
for n in ['prepare_build.py','run_full_qa.py','cross_repo_verify.py','queue_contract.py','release_after_build.py','verify_final_state.py']:
 save(n,ver(old(n)))
s=ver(old('update_census.py'))
# Replace numeric literals in one pass, avoiding chained old/new collisions.
mapping={534:605,605:694,474:385,73:92,71:89,70:89,2217:1732,4044:4529,4152:4731,108:202}
s=re.sub(r'\b(534|605|474|73|71|70|2217|4044|4152|108)\b',lambda m:str(mapping[int(m.group())]),s)
s=s.replace('retaining534 prior proofs,2 old contexts and1 accurate unchanged script','retaining605 prior proofs and3 unchanged contexts').replace('Add71 source-bound','Add89 source-bound')
s=swap(s,'len(context)==2','len(context)==3');s=swap(s,'set(changes)<set(new)','set(changes)==set(new)')
s=swap(s,"assert [new[p]['id'] for p in unchanged]==['510710-5_1DyhN']","assert not unchanged")
s=s.replace('new_complete_chapters=9','new_complete_chapters=10').replace('context_only_scripts=2','context_only_scripts=3').replace('new_complete_unchanged_scripts=1','new_complete_unchanged_scripts=0')
s=swap(s,"extra=={'510601-04'}","extra=={'510801-05'}");s=swap(s,'len(new_ids)==10','len(new_ids)==11');s=swap(s,'old_complete+10','old_complete+11')
s=s.replace("'new_complete_chapters':9","'new_complete_chapters':10").replace("'reread_context_scripts':2","'reread_context_scripts':3").replace("'new_complete_unchanged_scripts':1","'new_complete_unchanged_scripts':0").replace("'new_complete_indexed_entries_including_aliases':10","'new_complete_indexed_entries_including_aliases':11").replace("'new_primary_chapters':9","'new_primary_chapters':10").replace("'new_indexed_entries':10","'new_indexed_entries':11")
s=re.sub(r"'note':'510601-04[^']*'","'note':'510801-05is a31script compilation alias. Count10primary chapters,89new scripts and3old context rereads;do not count11independent chapters or add mirror paths.'",s);save('update_census.py',s)
s=ver(old('generate_contributions.py'));s=re.sub(r'\b(605|474|557)\b',lambda m:{'605':'694','474':'385','557':'646'}[m.group()],s);save('generate_contributions.py',s)
s=ver(old('commit_records.py')).replace("s['confirmed_ai_fully_reviewed']==605","s['confirmed_ai_fully_reviewed']==694");save('commit_records.py',s)
for dest,path in [('contribution_ledger.py','tools/story_quality_contributions.py'),('verify_contributions.py','tools/verify_story_quality_contributions.py')]:
 raw=subprocess.check_output(['git','--git-dir=A:/StoryQuality-20260930-1739/patch.git','show','FETCH_HEAD:'+path],cwd=R).decode('utf8');save(dest,raw)
print('CURRENT_COUNTER_BOUND_HELPERS_READY_NO_PUBLICATION',flush=True)
