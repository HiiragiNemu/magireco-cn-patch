"""Persist current evidence before a non-force, explicit-path handoff commit."""
from pathlib import Path
import subprocess,json,sys,datetime,hashlib
W=Path(__file__).resolve().parent;R=W.parent/'repo'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,timeout=90)
def save(p,d):p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def main():
 note=sys.argv[1];now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
 progress=json.loads((W/'progress.json').read_bytes());progress.update(checkpoint=note,updated_at=now);save(W/'progress.json',progress)
 git('fetch','origin','main');head=git('rev-parse','HEAD').decode().strip();assert head==git('rev-parse','origin/main').decode().strip(),'Remote changed: reconcile first'
 paths=['STORY_QUALITY_HANDOFF.md','docs/story-quality/CONTINUATION.md','docs/story-quality/CONTINUATION_STATE.json','docs/story-quality/20261001-ai-only-batch04.md']
 assert not git('diff','--name-only','--',*paths).strip(),'Existing uncommitted handoff edits'
 state=json.loads((R/paths[2]).read_bytes());prior=json.loads(((W/'published-package-receipt.json') if (W/'published-package-receipt.json').exists() else (W.parent/'semantic-batch03-20261001/published-package-receipt.json')).read_bytes())
 state.update(updated_at=now,checkpoint=note,active_batch=progress,task_id=progress['task_id'])
 # The previous site's 3314 state remains independently recorded until new delivery verification.
 state.update(scenario_version=prior['version'],package=prior['package'],reader_data_commit=prior['reader_commit'],cn_patch_source_commit=prior['cn_patch_commit'])
 state['paths']['current_batch']=str(W)
 state['pending']=['Only machine/AI story semantics; verified human and official CN excluded.','Finish selected complete chapters; do not count one repaired subsection as a complete chapter.','Reader/ADV 3315 content not yet delivered at resume; combine with next verified content release.','Audit unindexed machine-origin scripts separately; 300 indexed candidates are not automatically the global AI total.']
 ledger=json.loads((W/'ai-candidate-ledger-before.json').read_bytes());done=sum(x['complete'] for x in ledger);partial=sum(bool(x['done_paths']) and not x['complete'] for x in ledger)
 state['ai_only_scope']={'source_unverified_entries':514,'manual_human_verified_excluded':214,'indexed_candidates':len(ledger),'full_chapters_complete_before_batch04':done,'partial_chapters_before_batch04':partial,'not_fully_complete_before_batch04':len(ledger)-done,'unmapped_entries':sum(x['missing_mapping'] for x in ledger),'previous_22_full_chapter_claim_invalid':True,'previous_278_global_upper_bound_invalid':True,'rule':'All required source scripts must have current source-bound full-review proof. Unindexed sources tracked separately. SOURCE_UNVERIFIED alone is not AI proof.'}
 if (W/'completion.json').exists():state['ai_only_scope']['current_completion']=json.loads((W/'completion.json').read_bytes())
 if (W/'current-confirmed-machine-summary.json').exists():state['ai_only_scope']['confirmed_machine_current']=json.loads((W/'current-confirmed-machine-summary.json').read_bytes())
 if (W/'delivery-state.json').exists():state.update(json.loads((W/'delivery-state.json').read_bytes()))
 save(R/paths[2],state)
 root=f'''# Reader / CN patch 剧情质量：固定接续入口\n\n更新时间：{now}\n\n当前断点：{note}\n\n维护者最新范围：只修AI/机翻剧情，官方、国服和已确认人工稿不重校。先读 docs/story-quality/20261001-ai-only-batch04.md、CONTINUATION_STATE.json 和 CONTINUATION.md 的最新 BATCH04 区。\n\n工作区 `{R}`；本批 `{W}`；AgentDock任务 `{progress['task_id']}`。\n\n计数按完整目录条目及其全部源脚本；上轮22篇/剩278的结论错误，部分条目只审过一节，还漏掉更早完成量和未索引稿。修正前置台账为300个待来源/语义候选中{done}完整通过、{partial}部分覆盖、{len(ledger)-done}尚未完整通过；这不是已证实AI错误总量。\n\n当前已核验玩家包为{prior['version']}；接续时Reader/ADV仍是3314，现阶段是否完成由最新STATE判定。四条交付状态分开核对，不重复发3315。最新状态以STATE及公开回读证据为准。\n\n只向既有main提交，不新建分支/PR/强推；保留43 V4、196授权修订和原有脏文件，不动L2D/AIO/原开发树。每个有价值断点保存并提交交接。\n'''
 (R/paths[0]).write_text(root,encoding='utf8')
 cont=(R/paths[1]).read_text(encoding='utf8');start='<!-- AI-ONLY-BATCH04-START -->';end='<!-- AI-ONLY-BATCH04-END -->'
 block=f'''{start}\n## 最新断点：仅AI剧情第四批\n\n{now}：{note}\n\n固定范围以维护者最后指示为准：人工/国服不重校。原“全库每篇都重新翻译”计划不再适用。新批次取样使用3d463befe7a10d4cb72034378ce2a6f23c377abb的TRANSLATION_TEST_REPORT与新增目标blob，排除人工标记及保护稿；不能用SOURCE_UNVERIFIED单独判定AI。\n\n目录 `{W}`，progress.json / review-sources.json / provenance.json记录当前断点。选定13个完整目录条目，包含全部子脚本。上轮22全完成的算法只是前缀命中；已纠正为全路径证据核验。接续前已有{done}完整条目，部分{partial}，未完整{len(ledger)-done}，未索引AI单独清点。\n\n3315玩家包已发布但网页仍3314，不能把玩家包等同Reader部署。最新四状态和验证见STATE。旧章节以下内容仅作历史，不覆盖本节范围。\n{end}'''
 if start in cont:cont=cont[:cont.index(start)]+block+cont[cont.index(end)+len(end):]
 else:
  first,rest=cont.split('\n',1);cont=first+'\n\n'+block+'\n'+rest
 (R/paths[1]).write_text(cont,encoding='utf8')
 report=f'''# AI剧情第四批：当前真实状态\n\n时间：{now}\n\n{note}\n\n本批只选机器翻译测试导入来源的完整剧情，排除已确认人工、国服及保护稿。原始报告区分既有人工翻译记忆与新增机器稿；正确旧译不为增加改动量而重写。\n\n本轮来源台账与逐句依据在 `{W}`。已选择{progress.get('selected_chapters')}个完整目录条目、{progress.get('selected_scenes')}个独立运行脚本、{progress.get('selected_cn_fields')}正文显示字段。\n\n本轮目前实际审读{len(progress.get('reviewed',[]))}个运行脚本、{progress.get('reviewed_fields',0)}字段，实际暂存{progress.get('changed_fields',0)}修订。这些是语义进度，不自动代表已提交/发布。\n\n统计纠正：300个未获人工确认的索引候选中，接续前{done}个已具备所有子脚本完整证据，{partial}个只是部分覆盖，{len(ledger)-done}个尚未完整通过，4个缺映射。上条回复以任意一个子脚本命中推算整篇完成，22/278不是可靠全局数字。未索引机器来源要单独追踪。\n\n玩家{prior['version']}源Reader {prior['reader_commit']}、CN patch {prior['cn_patch_commit']}；包SHA256 {prior['package']['sha256']}。接续时网站和ADV仍8cc01062 / d84a6724（3314）。本批不重复发行3315；有新修订再发布3316。\n'''
 (R/paths[3]).write_text(report,encoding='utf8')
 git('add','--',*paths);git('commit','--only','-m','docs(handoff): '+note+' [skip ci]','--',*paths);git('push','origin','HEAD:refs/heads/main');commit=git('rev-parse','HEAD').decode().strip();assert git('ls-remote','origin','refs/heads/main').decode().split()[0]==commit
 save(W/'checkpoint-commit.json',{'commit':commit,'at':now,'note':note});print('CHECKPOINT',commit,note,flush=True)
if __name__=='__main__':main()
