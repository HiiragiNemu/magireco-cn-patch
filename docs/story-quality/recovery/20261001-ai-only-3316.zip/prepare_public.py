from pathlib import Path
import sys,json,datetime
W=Path(__file__).resolve().parent;ROOT=W.parent;R=ROOT/'repo';sys.path[:0]=[str(W),str(ROOT)]
from closeout_reader import commit_files,api
from commit_sources import git,tree

def main():
 p=json.loads((W/'repair-plan.json').read_bytes());v=json.loads((W/'validation.json').read_bytes());commits={r:json.loads((W/(r+'-commit.json')).read_bytes())['commit'] for r in ('reader','patch')}
 assert p['base_version']==3315 and p['target_version']==3316 and v['display_fields_revised']==164
 for repo,key in [('reader','reader_files'),('patch','runtime_files')]:
  git(repo,'fetch','origin','main');current=tree(repo,'FETCH_HEAD')
  for x in p[key]:assert current[x['path']]['sha']==x['after']
 runtime=[]
 for item in p['runtime_files']:
  item=dict(item);item['permitted_name_operations']=[op for op in item['operations'] if op[0][-1].startswith('name')];runtime.append(item)
 assert sum(len(x['permitted_name_operations']) for x in runtime)==1
 publication={'schema':2,'batch':p['batch'],'base_version':3315,'target_version':3316,'base_package_sha256':p['base_package_sha256'],'reader_commit':commits['reader'],'cn_patch_commit':commits['patch'],'changed_runtime_scripts':44,'full_scenes_read':52,'complete_scenes_reviewed':52,'complete_indexed_chapters':13,'pending_source_adjudication':[],'reviewed_fields':2961,'changed_fields':164,'body_fields_changed':163,'speaker_labels_changed':1,'reader_txt_files':26,'reader_txt_field_spans':356,'protected_v4':json.loads((W/'protected-v4.json').read_bytes()),'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z'),'runtime_files':runtime,'review_method':p['review_method']}
 folder='story-quality/20261001-semantic-batch04-ai-only/'
 files={folder+'publication-plan.json':json.dumps(publication,ensure_ascii=False,indent=2)+'\n',folder+'build_scenario_batch.py':(W/'build_package.py').read_bytes(),folder+'publish_scenario_3316.py':(W/'publish_scenario_3316.py').read_bytes()}
 for n in ('exact_json.py','translation_rules.py','test_translation_rules.py'):files[folder+n]=(W/n).read_bytes()
 files['.github/workflows/publish-story-quality-3316.yml']="""name: Publish thirteen AI-origin chapter reviews 3316
on:
  push:
    branches: [main]
    paths: ['.github/workflows/publish-story-quality-3316.yml', 'story-quality/20261001-semantic-batch04-ai-only/**']
  workflow_dispatch:
permissions:
  contents: write
concurrency:
  group: public-resource-mirror
  cancel-in-progress: false
jobs:
  publish:
    runs-on: ubuntu-latest
    timeout-minutes: 25
    steps:
      - uses: actions/checkout@v4
        with:
          persist-credentials: false
      - uses: actions/setup-python@v5
        with:
          python-version: '3.12'
      - run: python -m unittest discover -s story-quality/20261001-semantic-batch04-ai-only -p 'test_*.py' -v
      - name: Verify immutable assets and public bytes before opening the version gate
        env:
          GH_TOKEN: ${{ github.token }}
        run: python -u story-quality/20261001-semantic-batch04-ai-only/publish_scenario_3316.py
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: scenario-3316-ai-only-receipt
          path: |
            scenario3316/candidate/story-quality-report.json
            scenario3316/candidate/version_scenario.json
          if-no-files-found: warn
          retention-days: 30
"""
 current=api('HiiragiNemu/ProgettoMagius-1','git/trees/main?recursive=1');assert not current.get('truncated');paths={x['path'] for x in current['tree']};assert not paths&set(files),'Publisher already exists; inspect rather than overwrite'
 (W/'publication-plan.json').write_text(json.dumps(publication,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 commit=commit_files('HiiragiNemu/ProgettoMagius-1',files,'release(scenario): thirteen complete AI-origin chapter reviews 3316')
 (W/'public-commit.json').write_text(json.dumps({'commit':commit,**commits},indent=2),encoding='utf8')
 progress=json.loads((W/'progress.json').read_bytes());progress.update(stage='publishing',source_commits=commits,public_workflow_commit=commit,checkpoint='13完整AI剧情的164修订已进入两仓main；3316事务发布已触发，真实玩家/Reader/ADV状态待读回')
 (W/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('PUBLIC_BUILD_COMMIT',commit,flush=True)
if __name__=='__main__':main()
