"""Resolve renamed paths only by exact full Chinese+Japanese sequences, never by numeric prefixes."""
from pathlib import Path
import sys,json,subprocess,collections,csv,io,re
W=Path(__file__).resolve().parent;R=W.parent/'repo';P=W.parent/'semantic-batch03-20261001'
sys.path[:0]=[str(P),str(W),str(W.parent/'severe-5109-20261001')]
from census import Store,sequence_fp,display,TEXT as BODY
from collect_review import fields
from census_ai_scope import tree,IMPORT,TRUSTED,CN,JP

def save(n,v):(W/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def main():
 rt=json.loads((W/'reader-tree.json').read_bytes());it=tree(IMPORT);tt=tree(TRUSTED);s=Store()
 rows=json.loads((W/'machine-origin-script-ledger.json').read_bytes());known={x['path']:x for x in rows};prior={x['path']:x for x in json.loads((P/'census-after.json').read_bytes())}
 manifest=json.loads(s.get(rt['website/public/data/machine_translation_manifest.generated.json']));index=json.loads(s.get(rt['website/public/story_index.json']));indexed={p for x in index if x.get('game')=='magireco' for p in x.get('json_sources_cn',[])}
 humans={p for e in manifest['entries'] if e['manual_human_verified'] for st in index if st.get('source_identity')==e['source_identity'] for p in st.get('json_sources_cn',[])}
 humans.update(json.loads(s.get(rt['docs/reader-availability-local-20260929.json']))['protected_source_failure']['paths']);humans.update(p for p,v in known.items() if v['status']=='human_confirmed_or_exact_trusted_restoration_excluded')
 human_pairs=set()
 for p,r in prior.items():
  if (rt.get(p)==tt.get(p) and p in tt or p in humans) and r.get('body_sequence_fingerprint') and r.get('jp_sequence_fingerprint'):human_pairs.add((r['body_sequence_fingerprint'],r['jp_sequence_fingerprint']))
 tsv=csv.DictReader(io.StringIO(s.get(it['magireco-translate-data-master/TRANSLATION_REVIEW.tsv']).decode('utf-8-sig')),delimiter='\t');outputs={(r.get('japanese'),r.get('chinese')) for r in tsv if r.get('type') in ('text','fallback') and r.get('japanese') and r.get('chinese')}
 imported_pairs=collections.defaultdict(list);jname=collections.defaultdict(list)
 for p in it:
  if p.startswith(JP) and p.endswith('.json'):jname[Path(p).stem].append(p)
 for old in rows:
  p=old['path'];jp=p.replace(CN,JP,1)
  if jp not in it:
   matches=jname[Path(p).stem]
   if len(matches)!=1:continue
   jp=matches[0]
  cnobj=json.loads(s.get(it[p]));jpobj=json.loads(s.get(it[jp]));jmap={tuple(f['address']):f['text'] for f in fields(jpobj)}
  proof=[f for f in fields(cnobj) if (jmap.get(tuple(f['address'])),f['text']) in outputs and len(f['text'])>=4 and re.search(r'[A-Za-z\u4e00-\u9fff\u3040-\u30ff]',f['text'])]
  if proof:imported_pairs[(sequence_fp(cnobj),sequence_fp(jpobj))].append({'path':p,'import_blob':it[p],'jp_path':jp,'jp_blob':it[jp],'machine_output_pair_count':len(proof)})
 new=[];unresolved=[];restored=[]
 for p in sorted(rt):
  if not(p.startswith(CN) and p.endswith('.json')) or p in tt or p in it or p in humans:continue
  r=prior.get(p)
  if not r:
   unresolved.append({'path':p,'current_blob':rt[p],'reason':'No prior full-path Japanese mapping; do not guess by prefix.'});continue
  key=(r['body_sequence_fingerprint'],r['jp_sequence_fingerprint'])
  if key in human_pairs:restored.append({'path':p,'blob':rt[p],'reason':'Exact full current Chinese/Japanese sequence pair matches verified-human or unchanged trusted text.'});continue
  if key not in imported_pairs:
   unresolved.append({'path':p,'current_blob':rt[p],'body_fields':r['text_fields'],'reason':'No exact full bilingual import-pair match; provenance remains unresolved.'});continue
  origins=imported_pairs[key];ok=bool(r['review_complete'] and r['blob']==rt[p] and rt.get(r['jp_path'])==r['jp_blob'])
  new.append({'path':p,'script_id':Path(p).stem,'current_blob':rt[p],'jp_path':r['jp_path'],'jp_blob':r['jp_blob'],'status':'machine_origin_full_review_complete' if ok else 'machine_origin_not_fully_reviewed','indexed':p in indexed,'complete':ok,'body_fields':r['text_fields'],'exact_import_aliases':origins,'method':'Exact entire Chinese display sequence and exact entire Japanese display sequence; no review completion is transferred between paths.'})
 current=[r for r in rows if r.get('status','').startswith('machine_origin_')]+new
 assert len({r['path'] for r in current})==len(current)
 summary={'confirmed_current_machine_scripts':len(current),'complete':sum(r['complete'] for r in current),'remaining':sum(not r['complete'] for r in current),'pending_unindexed':sum(not r['complete'] and not r['indexed'] for r in current),'exact_bilingual_renamed_paths_resolved':len(new),'additional_exact_human_text_aliases_excluded':len(restored),'new_paths_provenance_unresolved':len(unresolved),'no_exact_output_pair_proof_within_import':sum(r['status']=='import_origin_but_no_exact_machine_pair_proof' for r in rows),'note':'Verified current machine-origin physical scripts only. Unresolved provenance is a separate queue, not blanket retranslation. No counts from automatic scans count as complete.'}
 save('machine-origin-aliases.json',new);save('additional-human-alias-exclusions.json',restored);save('new-path-provenance-queue.json',unresolved);save('current-confirmed-machine-ledger.json',current);save('current-confirmed-machine-summary.json',summary)
 s.close();print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
