"""Validate source-bound semantic review and reversible runtime/text edits before publication."""
from pathlib import Path
import sys,json,gzip,hashlib,subprocess,datetime
W=Path(__file__).resolve().parent;ROOT=W.parent;R=ROOT/'repo'
sys.path[:0]=[str(W),str(ROOT/'semantic-batch03-20261001'),str(ROOT/'control-authority-20260930'),str(ROOT/'severe-5109-20261001')]
from exact_json import apply,blob
from translation_rules import validate,execution_tokens,color_types
from collect_review import fields
from census import Store
READER_STORE=Store()
def raw(repo,sha):
 assert repo=='reader'
 return READER_STORE.get(sha)

def load(n):return json.loads((W/n).read_bytes())
def dump(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def save(n,x):p=W/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(dump(x))
def main():
 p=load('repair-plan.json');t=load('text-plan.json');rt=load('reader-tree.json');pt=load('patch-tree.json');render=load('reader-render-validation.json')
 assert len(p['reviewed_stories'])==52 and len(p['completed_review_stories'])==52 and p['pending_adjudication_stories']==[]
 assert len(p['reader_files'])==len(p['runtime_files'])==44 and p['reviewed_fields']==2961 and p['changed_fields']==164
 assert render['passed'] and render['actualParser'] and len(render['files'])==44 and not t['holds'] and not t['missing']
 tests=subprocess.run([sys.executable,'-m','unittest','discover','-s',str(W),'-p','test_translation_rules.py','-v'],cwd=W,capture_output=True,text=True,encoding='utf-8');(W/'translation-tests.log').write_text(tests.stdout+tests.stderr,encoding='utf-8');assert tests.returncode==0 and 'Ran 23 tests' in tests.stderr
 decision={x['id']:load('review/'+x['id']+'.edits.json') for x in p['reviewed_stories']};placeholders=0
 for s in p['reader_files']:
  a=(W/'originals/reader'/s['path']).read_bytes();b=(W/'stage/reader'/s['path']).read_bytes();ops=s['operations'];d=decision[Path(s['path']).stem]
  authorized_names=[[x['address'],x['before'],x['after']] for x in d.get('name_edits',[])]
  assert blob(a)==s['before'] and blob(b)==s['after'];validate(a,b,ops,allowed_name_operations=authorized_names);assert apply(b,[[at,new,old] for at,old,new in ops])==a
  af=fields(json.loads(a));bf=fields(json.loads(b));assert len(af)==len(bf)
  for old,new in zip(af,bf):
   assert old['text'].count('userName')==new['text'].count('userName');placeholders+=old['text'].count('userName')
   assert execution_tokens(old['text'])==execution_tokens(new['text']) and color_types(old['text'])==color_types(new['text'])
 for s in t['files']:
  a=raw('reader',s['before']);b=(W/'stage/reader'/s['path']).read_bytes();assert blob(b)==s['after'];bom=b'\xef\xbb\xbf' if b.startswith(b'\xef\xbb\xbf') else b'';undo=b[len(bom):].decode()
  for e in sorted(s['edits'],key=lambda x:x['after_start'],reverse=True):
   assert undo[e['after_start']:e['after_end']]==e['after_text'];undo=undo[:e['after_start']]+e['before_text']+undo[e['after_end']:]
  assert bom+undo.encode()==a
 authorized=json.loads((R/'docs/reader-availability-local-20260929.json').read_bytes())['protected_source_failure']['paths'];assert len(authorized)==196
 changed={x['path'] for x in p['reader_files']}|{x['path'] for x in t['files']};assert not set(authorized)&changed
 for path in authorized:assert blob((R/path).read_bytes())==rt[path],path
 v4=json.loads((R/'manifests/authoritative_scenario_runtime_repairs.v1.json').read_bytes())['entries'];assert len(v4)==43;protected={}
 for x in v4:
  path=x['target_path'];assert path not in changed and blob((R/path).read_bytes())==rt[path]
  peers=[z for z in pt if z.startswith('madomagi/resource/scenario/json/adv/') and Path(z).name==Path(path).name];assert len(peers)==1;protected[peers[0]]=pt[peers[0]]
 assert not set(protected)&{x['path'] for x in p['runtime_files']}
 anchors={'310282-1':['归还玩具'],'310282-4':['只有小彦'],'310311-1':['光塚青年会'],'310312-1':['不觉得对方'],'310313-1':['所有人的领袖'],'310331-1':['那就是说'],'310331-2':['喜欢读这些书'],'310332-2':['只能让咪班上的同学'],'310333-1':['胡乱添加了调味料'],'310342-4':['传说确实存在','爱抖腿将军']}
 for sid,terms in anchors.items():
  text=(W/'review'/(sid+'.final.txt')).read_text(encoding='utf-8').replace('@','')
  for term in terms:assert term in text,(sid,term)
 for path,h in load('dirty-tracked-hashes.json').items():assert hashlib.sha256((R/path).read_bytes()).hexdigest()==h,path
 inputs=p['inputs']|t.get('inputs',{})
 for path in authorized:inputs[path]=rt[path]
 for x in v4:inputs[x['target_path']]=rt[x['target_path']]
 for path in ['docs/reader-availability-local-20260929.json','manifests/authoritative_scenario_runtime_repairs.v1.json']:inputs[path]=rt[path]
 save('reader-inputs.json',inputs);save('protected-v4.json',protected)
 now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds').replace('+00:00','Z')
 v={'schema':2,'batch':p['batch'],'validated_at':now,'indexed_chapters_complete':13,'scenes_full_read':52,'complete_scenes_reviewed':52,'pending_source_adjudication':[],'display_fields_reviewed':2961,'display_fields_revised':164,'body_fields_revised':163,'explicit_speaker_label_repairs':1,'display_only':True,'exact_reverse_to_original_bytes':True,'nontext_structure_actor_identity_and_audio_unchanged':True,'AI_import_source_verified':True,'executable_tags_and_highlight_types_unchanged':True,'player_name_placeholders_preserved':placeholders,'actual_reader_parser_files':44,'actual_reader_events_and_audio_metadata_unchanged':True,'specialized_tests_passed':23,'reader_txt_files':len(t['files']),'reader_txt_field_spans':t['physical_field_span_edits'],'historical_full_section_baselines':len(load('historical-text-baselines.json')),'multiline_artifact_spans':t['multiline_artifact_spans'],'txt_missing_fields':0,'txt_alignment_holds':0,'protected_v4_unchanged':43,'protected_authorized_cn_unchanged':196,'unrelated_dirty_paths_unchanged':True,'review_method':p['review_method'],'official_or_human_provenance_not_asserted':True,'published':False,'whole_corpus_complete':False,'device_gameplay_verified':False}
 save('validation.json',v)
 evidence={'validation':v,'plan':p,'text_plan':t,'historical_baselines':load('historical-text-baselines.json'),'decisions':decision,'provenance':load('provenance.json'),'chapters':load('chapters.json'),'export_preservation_exception':load('export-preservation-exception.json')}
 report="""# 20261001 AI-only semantic batch04: validated source changes

13 complete indexed chapters / 52 runtime scripts / 2961 body display fields were read in full against Japanese. 44 runtime scripts need changes: 163 body fields and one explicit speaker-label correction (164 total). Eight complete scripts remain byte-for-byte unchanged. No new runtime/actor/audio/model migration.

Selected: Himena 310282/310283; San 310311/310312/310313; Miyuri 310321/310322/310323; Rabi 310331/310332/310333; Asahi 310341/310342. All selected scripts are absent from the trusted human baseline and present in the identified machine-test import. Verified human-marked chapters and protected official/authorized content are excluded. Correct inherited translation-memory content was retained, not retranslated wholesale.

26 paired source/web TXT files were synchronized by whole-section exact matching, including 13 provably historical section baselines. A single harmless export-only laughter spelling in 310323-4 is preserved with an explicit source-bound exception; all other 49 fields in that section exactly match the source. No fuzzy or positional cross-character alignment.

Examples: wrong object of the request to return toys; confusing leadership over the group with leading everyone to the top; liking philosophy books mistranslated as liking a person's trait; continuation after consent mistranslated as goodbye; classmates being informed of a condition mistranslated as classmates themselves having it. Proper nouns follow verified baseline Japanese/Chinese pairs. Old correct source wording, narrative qualifications and phonetic jokes remain intact.

23 specialized refusal/regression tests, actual Reader parser checks on all 44 changed scripts, executable tag/color/actor/audio preservation and exact byte reversal passed. 43 accepted V4 repairs, 196 authorized sources and pre-existing worktree edits are protected. This is source validation, not a player/website/ADV publication receipt. Model-assisted review is not a claim of human or official authorship.
"""
 folder='manifests/story_quality_semantic_batch04_ai_only_20261001';files={folder+'.json':dump(v),folder+'_evidence.json.gz':gzip.compress(dump(evidence),mtime=0),'docs/story-quality/20261001-semantic-batch04-validated.md':report.encode()}
 for repo in ('reader','patch'):
  for path,b in files.items():out=W/'stage'/repo/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 for f in (W/'review').glob('*.final.txt'):
  out=W/'stage/reader/docs/story-quality/reviewed/20261001-semantic-batch04-ai-only'/f.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(f.read_bytes())
 progress=load('progress.json');progress.update(stage='validated',checkpoint='13个完整目录条目52脚本2961字段全文审读，164处修订及26份TXT通过结构/控制/来源/实际Reader验证，待两仓main提交与3316/Reader/ADV交付',validation=v,next=['提交两仓main并核验','3315基线构建3316玩家包','干净快照构建和部署Reader，补齐旧3315未上线内容','复验公开版本与ADV，更新完整篇数台账'])
 save('progress.json',progress);print('VALIDATED',json.dumps(v,ensure_ascii=False),flush=True)
if __name__=='__main__':main()
