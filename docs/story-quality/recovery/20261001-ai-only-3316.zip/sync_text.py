"""Prove every complete TXT section against a committed JSON, including multiline contamination."""
from pathlib import Path
import json,re,subprocess,sys,collections
W=Path(__file__).resolve().parent;R=W.parent/'repo';sys.path[:0]=[str(W),str(W.parent/'severe-5109-20261001'),'A:/StoryQuality-20260930-1739']
from collect_review import fields,raw
from prefix_exact import clean,HEADER
from exact_json import blob
plan=json.loads((W/'repair-plan.json').read_bytes());rt=json.loads((W/'reader-tree.json').read_bytes());sources={x['path']:x for x in plan['reader_files']};parents={str(Path(x).parent) for x in sources}
history={};files=[];holds=[];covered=set();already=set();inputs={};multiline=0;sections=0;names_accounted=[]

def cf(v,nl):return clean(v).replace('\r\n','\n').replace('\n',nl)
def try_match(fragment,rows,nl):
 pos=0;matches=[]
 for f in rows:
  m=re.match(r'[ \t\r\n]*',fragment[pos:]);pos+=len(m[0])
  start=pos
  # Bad historical names can contain a literal newline; match them only verbatim.
  bad=(f['name'] or '旁白').replace('\r\n','\n').replace('\n',nl)
  special=re.match(re.escape(bad)+r'[:：][ \t]?',fragment[pos:]) if '\n' in bad else None
  m=special or re.match(r'[^\r\n:：]*[:：][ \t]?',fragment[pos:])
  if not m:return None
  prefix=m[0];pos+=len(prefix);body=cf(f['text'],nl)
  if fragment[pos:pos+len(body)]!=body:return None
  pos+=len(body)
  if pos<len(fragment) and fragment[pos] not in '\r\n':return None
  matches.append((start,pos,prefix,body))
 if fragment[pos:].strip():return None
 return matches

def candidates(source):
 yield rt[source],None,raw('reader',rt[source])
 commits=['3d463befe7a10d4cb72034378ce2a6f23c377abb']+subprocess.check_output(['git','log','--format=%H','--',source],cwd=R).decode().splitlines()
 seen={rt[source]}
 for commit in commits:
  x=subprocess.run(['git','show',commit+':'+source],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  if x.returncode:continue
  sha=blob(x.stdout)
  if sha in seen:continue
  seen.add(sha);yield sha,commit,x.stdout

def origin_name_address(data,field):
 address=field['address'];g,i,key=address[1:];turns=data['story'][g];suffix=key.replace('textAv','').replace('text','');nk='name'+suffix if key.startswith('text') else 'nameFnarration' if key.lower().endswith('fnarration') else 'nameNarration';found=None
 for index,t in enumerate(turns[:i+1]):
  if nk in t:found=('story',g,index,nk)
 return found

for path in rt:
 if not path.startswith('magireco-translate-data-master/Scenarios_full/') or not path.endswith('.txt') or str(Path(path).parent) not in parents:continue
 rel=Path(path.split('Scenarios_full/',1)[1]);web='website/public/data/'+(rel.parent/(rel.stem+'_cn.txt')).as_posix()
 if web not in rt:holds.append({'path':path,'reason':'paired web TXT missing'});continue
 bs=[raw('reader',rt[p]) for p in (path,web)]
 if bs[0].decode('utf-8-sig').replace('\r\n','\n')!=bs[1].decode('utf-8-sig').replace('\r\n','\n'):holds.append({'path':path,'reason':'paired copies differ'});continue
 for target,original in zip((path,web),bs):
  bom=b'\xef\xbb\xbf' if original.startswith(b'\xef\xbb\xbf') else b'';text=original[len(bom):].decode();nl='\r\n' if '\r\n' in text else '\n';lines=text.splitlines(keepends=True);offset=0;heads=[]
  for line in lines:
   m=HEADER.match(line.rstrip('\r\n'))
   if m:heads.append((offset,offset+len(line),m))
   offset+=len(line)
  operations=[]
  for h,(_,start,m) in enumerate(heads):
   source=(Path(path).parent/m[2]).as_posix()
   if source not in sources:continue
   end=heads[h+1][0] if h+1<len(heads) else len(text);fragment=text[start:end];group='group_'+(m[1] or '1');found=None
   afterobj=json.loads((W/'stage/reader'/source).read_bytes());originalobj=json.loads(raw('reader',rt[source]));after=[x for x in fields(afterobj) if x['address'][1]==group and clean(x['text'])];current={tuple(x['address']):x for x in fields(originalobj)}
   # Independently reviewed harmless TXT-only laughter at one bound ordinal.
   # Preserve it rather than silently replacing a correct untouched export line.
   exception = Path(source).stem=='310323-4' and group=='group_1'
   if exception:
    assert len(after)==50 and after[47]['text']=='嘿嘿嘿。'
    assert '诶嘿嘿嘿' in fragment and len(re.findall('诶嘿嘿嘿',fragment))==1
    after[47]=dict(after[47],text='诶嘿嘿嘿')
   for sha,commit,data in candidates(source):
    before=[x for x in fields(json.loads(data)) if x['address'][1]==group and clean(x['text'])]
    if [x['address'] for x in before]!=[x['address'] for x in after]:continue
    if exception and len(before)==50 and before[47]['text']=='嘿嘿嘿。':
     before[47]=dict(before[47],text='诶嘿嘿嘿')
    matches=try_match(fragment,before,nl)
    if matches is not None:found=(sha,commit,before,matches);break
   if not found:holds.append({'path':target,'source':source,'group':group,'reason':'No exact complete historical body sequence match','visible_fields':len(after)});continue
   sha,commit,before,matches=found;sections+=1
   if sha!=rt[source]:history[source]={'blob':sha,'commit':commit,'path':source,'txt_path':path,'txt_blob':rt[path],'fields':len(before),'evidence':'all full-section visible fields matched verbatim in order, including physical multiline strings'}
   section_ops=[];failed=None
   for a,b,(lo,hi,prefix,oldbody) in zip(before,after,matches):
    at=tuple(a['address']);cur=current[at];label_address=origin_name_address(originalobj,cur);newprefix=prefix;label=prefix.rstrip(' \t')[:-1]
    if cur['name']!=b['name']:
     oldname=cur['name'].replace('\r\n','\n').replace('\n',nl);newname=b['name'].replace('\r\n','\n').replace('\n',nl)
     if label not in (oldname,newname):failed={'field':a['address'],'reason':'Existing TXT speaker differs from both exact old/new reviewed labels','label':label,'old_name':oldname,'new_name':newname};break
     delimiter=prefix[len(label):];newprefix=newname+delimiter
     if label_address:names_accounted.append((source,label_address))
    newbody=cf(b['text'],nl);old=prefix+oldbody;new=newprefix+newbody
    if old==new:
     already.add((source,at));continue
    covered.add((source,at));multiline+=('\n' in oldbody or '\n' in label)
    section_ops.append({'start':start+lo,'end':start+hi,'before_text':old,'after_text':new,'source_path':source,'address':a['address'],'source_sha':rt[source],'baseline_sha':sha,'before_name':label,'after_name':newprefix.rstrip(' \t')[:-1]})
   if failed:holds.append({'path':target,'source':source,**failed});continue
   operations.extend(section_ops)
  if not operations:continue
  result=text
  for o in sorted(operations,key=lambda x:x['start'],reverse=True):assert result[o['start']:o['end']]==o['before_text'];result=result[:o['start']]+o['after_text']+result[o['end']:]
  shift=0
  for o in sorted(operations,key=lambda x:x['start']):o['after_start']=o['start']+shift;o['after_end']=o['after_start']+len(o['after_text']);shift+=len(o['after_text'])-len(o['before_text'])
  undo=result
  for o in sorted(operations,key=lambda x:x['after_start'],reverse=True):assert undo[o['after_start']:o['after_end']]==o['after_text'];undo=undo[:o['after_start']]+o['before_text']+undo[o['after_end']:]
  assert bom+undo.encode()==original
  encoded=bom+result.encode()
  for folder,b in [('originals',original),('stage',encoded)]:p=W/folder/'reader'/target;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  files.append({'path':target,'before':blob(original),'after':blob(encoded),'edits':operations,'span_reversible':True});inputs[target]=rt[target]
body_needed={(x['path'],tuple(op[0])) for x in plan['reader_files'] for op in x['operations'] if not op[0][-1].startswith('name')}
name_needed={(x['path'],tuple(op[0])) for x in plan['reader_files'] for op in x['operations'] if op[0][-1].startswith('name')}
missing=body_needed-covered-already;missing_names=name_needed-set(names_accounted)
report={'schema':2,'files':files,'inputs':inputs,'physical_line_edits':sum(len(x['edits']) for x in files),'physical_field_span_edits':sum(len(x['edits']) for x in files),'unique_changed_source_fields':len(covered),'complete_section_matches':sections,'multiline_artifact_spans':multiline,'holds':holds,'already_correct_source_fields':[(p,list(a)) for p,a in sorted(already&body_needed)],'missing':[(p,list(a)) for p,a in sorted(missing|missing_names)],'name_fields_accounted':[(p,list(a)) for p,a in sorted(set(names_accounted))],'notes':['Physical span count is not necessarily line count: invalid literal newlines in translated strings are repaired without deleting adjacent records.','Only full exact matching sections qualify; no fuzzy matching or unverified replacement of human wording.']}
(W/'text-plan.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(W/'historical-text-baselines.json').write_text(json.dumps(history,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('FILES',len(files),'SPANS',report['physical_field_span_edits'],'FULL_SECTIONS',sections,'HISTORY',len(history),'HOLDS',len(holds),'MISSING',len(report['missing']),'MULTILINE',multiline)
if holds:print(json.dumps(holds,ensure_ascii=False,indent=2))
if report['missing']:print('MISSING',json.dumps(report['missing'],ensure_ascii=False)[:3500])
if holds or report['missing']:raise SystemExit(2)
