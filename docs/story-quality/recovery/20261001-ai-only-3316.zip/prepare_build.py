"""Provision an isolated committed Reader build; never build over the dirty development tree."""
from pathlib import Path
import sys,json,subprocess,shutil,hashlib,os
W=Path(__file__).resolve().parent;ROOT=W.parent;R=ROOT/'repo';D=W/'delivery'
sys.path.insert(0,str(ROOT))
from release_control import project,summary

def main():
 live=summary(project());old=json.loads((W/'baseline-delivery.json').read_bytes())
 assert live['canonical_commit']==old['reader_source_commit'] and live['canonical_id']==old['reader_production_deployment'],'Production changed; inspect before replacing'
 source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()
 remote=subprocess.check_output(['git','ls-remote','origin','refs/heads/main'],cwd=R).decode().split()[0];assert source==remote
 assert not D.exists(),'Existing isolated build; inspect rather than overwrite'
 D.mkdir();(D/'project-baseline.json').write_text(json.dumps(live,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');(D/'source-revision.txt').write_text(source,encoding='utf-8')
 subprocess.run(['git','-c','core.longpaths=true','clone','--shared','--no-checkout',str(R),str(D/'repo')],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=180)
 for args in [('config','core.autocrlf','false'),('config','core.longpaths','true'),('remote','set-url','origin','https://github.com/HiiragiNemu/magi-reader.git'),('checkout','--detach',source)]:
  subprocess.run(['git',*args],cwd=D/'repo',check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=300)
 assert not subprocess.check_output(['git','status','--porcelain=v1'],cwd=D/'repo')
 for n in ('release_control.py','source_guard.py','build_release.ps1','online_verify.py','verify_edge_status.py','probe_voice_binding.py','deploy_reader.py'):
  shutil.copy2(ROOT/n,D/n)
 # Adopt the established documentation-descendant allowance, without touching source files.
 helper=(ROOT/'cn-origin-20260930/deploy_verified_snapshot.py').read_text(encoding='utf-8')
 helper=helper.replace("sys.path.insert(0,str(Path(__file__).resolve().parent.parent))","sys.path.insert(0,str(Path(__file__).resolve().parent))")
 helper=helper.replace("save('cn-origin-20260930/document-only-descendant.json'","save('document-only-descendant.json'")
 (D/'deploy_verified_snapshot.py').write_text(helper,encoding='utf-8')
 progress=json.loads((W/'progress.json').read_bytes());progress.update(build_source_commit=source,build_root=str(D),checkpoint='3316正在事务发布，网页包含3315和3316修订；Reader在独立已提交快照安装固定锁文件依赖，原工作树不参与生成')
 (W/'progress.json').write_text(json.dumps(progress,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 env=os.environ.copy()|{'PYTHONUTF8':'1','NEXT_TELEMETRY_DISABLED':'1'}
 print('ISOLATED_BUILD_SOURCE',source,'ROOT',D,flush=True)
 with (D/'install.log').open('w',encoding='utf-8') as log:
  result=subprocess.run(['cmd','/c','npm','ci','--prefer-offline','--no-audit'],cwd=D/'repo/website',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 assert result.returncode==0,'Dependency install failed; inspect isolated install.log'
 assert (D/'repo/website/package-lock.json').read_bytes()==subprocess.check_output(['git','show',source+':website/package-lock.json'],cwd=D/'repo')
 print('ISOLATED_LOCKED_DEPENDENCIES_INSTALLED',flush=True)
if __name__=='__main__':main()
