const fs = require('node:fs');
const path = require('node:path');
const {pathToFileURL} = require('node:url');
const root = path.join(__dirname, '..', 'repo');
async function main() {
  const parser = await import(pathToFileURL(path.join(root, 'website/lib/story-parser.ts')));
  const plan = JSON.parse(fs.readFileSync(path.join(__dirname, 'repair-plan.json')));
  const results = [];
  for (const file of plan.reader_files) {
    const options = {filename: path.basename(file.path), mergeConsecutiveTextLines: false};
    const read = directory => parser.parseStoryContent(fs.readFileSync(path.join(__dirname, directory, 'reader', file.path), 'utf8'), options).lines;
    const before = read('originals');
    const approvedNames = file.operations.filter(([address]) => address.at(-1).startsWith('name'));
    const nameOnly = JSON.parse(fs.readFileSync(path.join(__dirname, 'originals', 'reader', file.path), 'utf8'));
    for (const [address, oldName, newName] of approvedNames) {
      let node = nameOnly;
      for (const key of address.slice(0,-1)) node = node[key];
      if (node[address.at(-1)] !== oldName) throw Error('Speaker-label baseline mismatch');
      node[address.at(-1)] = newName;
    }
    const expectedIdentity = parser.parseStoryContent(JSON.stringify(nameOnly), options).lines;
    const after = read('stage');
    const identity = lines => lines.map(x => [x.speaker, x.isHeader, x.isChoice, x.sourceGroupId, x.sourceTurnIndex, x.sourceCommand, x.audioCueId, x.audioCueIds]);
    if (JSON.stringify(identity(expectedIdentity)) !== JSON.stringify(identity(after))) throw Error('Unexpected display or voice identity change: ' + file.path);
    results.push({path: file.path, beforeLines: before.length, afterLines: after.length, eventStructurePreserved: true, explicitlyReviewedSpeakerLabels: approvedNames.length, audioMetadataPreserved: true, before, after});
  }
  fs.writeFileSync(path.join(__dirname, 'reader-render-validation.json'), JSON.stringify({passed: true, actualParser: true, files: results}, null, 2));
  console.log('Reader parser verified:', results.length);
}
main().catch(error => { console.error(error); process.exitCode = 1; });
