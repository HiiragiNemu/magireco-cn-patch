"""Census machine-test-origin scripts and indexed chapters; never equate snippets with chapters."""
from pathlib import Path
import json,sys,subprocess,collections,csv,io,re,hashlib,gzip
W=Path(__file__).resolve().parent;R=W.parent/'repo';P=W.parent/'semantic-batch03-20261001'
sys.path[:0]=[str(P),str(W.parent/'severe-5109-20261001')]
from census import Store
from collect_review import fields,TEXT
TEXT.add('textSelect')
IMPORT='3d463befe7a10d4cb72034378ce2a6f23c377abb';TRUSTED='65f221f2aaa5a9fe161ed32e03e4dfbb93d4746d';CN='magireco-translate-data-master/Scenarios_full/';JP='magireco-source-master/Scenarios_full/'
def tree(ref):
 out={}
 for line in subprocess.check_output(['git','ls-tree','-rz',ref],cwd=R).split(b'\0'):
  if line:
   m,p=line.split(b'\t',1);out[p.decode()]=m.split()[2].decode()
 return out
def dump(name,obj): (W/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def main():
 rt=json.loads((W/'reader-tree.json').read_bytes());it=tree(IMPORT);tt=tree(TRUSTED);s=Store()
 prior={x['path']:x for x in json.loads((P/'census-after.json').read_bytes())}
 plan=json.loads((W/'repair-plan.json').read_bytes());changed={x['path']:x for x in plan['reader_files']};selected={x['cn_path']:x for x in json.loads((W/'review-sources.json').read_bytes())}
 index=json.loads(s.get(rt['website/public/story_index.json']));manifest=json.loads(s.get(rt['website/public/data/machine_translation_manifest.generated.json']));human_entries=[x for x in manifest['entries'] if x['manual_human_verified']]
 human={p for e in human_entries for i in index if i.get('source_identity')==e['source_identity'] for p in i.get('json_sources_cn',[])}
 human.update(json.loads(s.get(rt['docs/reader-availability-local-20260929.json']))['protected_source_failure']['paths'])
 indexed={p for i in index if i.get('game')=='magireco' for p in i.get('json_sources_cn',[])}
 variants=json.loads(s.get(rt['manifests/authoritative_scenario_variant_repairs.v1.json']))['entries']
 restored=set();restoration_proofs=[]
 for e in variants:
  cp=e['canonical_path'];tp=e['target_path']
  if rt.get(cp)!=tt.get(cp) or cp not in tt or tp not in rt:continue
  cf=fields(json.loads(s.get(rt[cp])));tf=fields(json.loads(s.get(rt[tp])))
  if [x['text'] for x in cf]==[x['text'] for x in tf]:
   restored.add(tp);restoration_proofs.append({'path':tp,'blob':rt[tp],'trusted_canonical':cp,'trusted_canonical_blob':tt[cp],'method':'All display fields exactly equal the current unchanged trusted-baseline canonical file.'})
 human.update(restored)
 complete={p for p,r in prior.items() if r['review_complete'] and rt.get(p)==r['blob'] and rt.get(r.get('jp_path'))==r.get('jp_blob')}
 complete.update(selected)
 entries=[]
 for e in manifest['entries']:
  if e['manual_human_verified']:continue
  matches=[i for i in index if i.get('source_identity')==e['source_identity'] and i.get('game')=='magireco'];assert len(matches)==1
  paths=matches[0].get('json_sources_cn',[]);done=[p for p in paths if p in complete]
  entries.append({'story_id':e['story_id'],'source_identity':e['source_identity'],'title':e['title'],'paths':paths,'done_paths':done,'complete':bool(paths) and len(done)==len(paths),'missing_mapping':not paths,'added_complete_this_batch':e['story_id'] in {x['chapter_id'] for x in selected.values()}})
 tsv=csv.DictReader(io.StringIO(s.get(it['magireco-translate-data-master/TRANSLATION_REVIEW.tsv']).decode('utf-8-sig')),delimiter='\t')
 generated={(r.get('japanese'),r.get('chinese')) for r in tsv if r.get('type') in ('text','fallback') and r.get('japanese') and r.get('chinese')}
 rows=[]
 import_new=sorted(p for p in it if p.startswith(CN) and p.endswith('.json') and p not in tt)
 for p in import_new:
  if p not in rt:
   rows.append({'path':p,'status':'not_present_current','import_blob':it[p]});continue
  cur=prior.get(p);jp=p.replace(CN,JP,1)
  if jp not in it and cur:jp=cur.get('jp_path')
  original=fields(json.loads(s.get(it[p]))); japanese=fields(json.loads(s.get(it[jp]))) if jp in it else []
  jmap={tuple(x['address']):x['text'] for x in japanese};generated_proofs=[{'address':x['address'],'jp':jmap.get(tuple(x['address'])),'import_cn':x['text']} for x in original if (jmap.get(tuple(x['address'])),x['text']) in generated and len(x['text'])>=4 and re.search(r'[A-Za-z\u4e00-\u9fff\u3040-\u30ff]',x['text'])]
  lexical=cur.get('has_lexical_body',False) if cur else any(re.search(r'[A-Za-z\u4e00-\u9fff\u3040-\u30ff]',x['text']) for x in original)
  if p in human:status='human_confirmed_or_exact_trusted_restoration_excluded'
  elif not lexical:status='no_lexical_body'
  elif not generated_proofs:status='import_origin_but_no_exact_machine_pair_proof'
  elif p in complete:status='machine_origin_full_review_complete'
  else:status='machine_origin_not_fully_reviewed'
  rows.append({'path':p,'script_id':Path(p).stem,'import_blob':it[p],'current_blob':changed[p]['after'] if p in changed else rt[p],'jp_path':jp,'jp_blob':rt.get(jp),'indexed':p in indexed,'status':status,'complete':p in complete,'body_fields':cur.get('text_fields') if cur else len(original),'machine_output_pair_count':len(generated_proofs),'machine_output_pair_example':generated_proofs[:1]})
 counts=collections.Counter(r['status'] for r in rows)
 summary={'scope':'New CN JSON paths at the explicitly machine-test import, absent from trusted human baseline; current human-marked/restored paths excluded. Physical runtime scripts are not independent plots.','import_new_paths':len(rows),'status_counts':dict(counts),'indexed_candidate_entries':len(entries),'indexed_complete_entries':sum(e['complete'] for e in entries),'indexed_partial_entries':sum(bool(e['done_paths']) and not e['complete'] for e in entries),'indexed_not_fully_complete_entries':sum(not e['complete'] for e in entries),'indexed_unmapped_entries':sum(e['missing_mapping'] for e in entries),'new_complete_chapters':13,'new_full_review_scripts':52,'new_reviewed_fields':2961,'explicit_human_entries_excluded':len(human_entries),'exact_human_variant_restorations':len(restored),'confirmed_machine_pending_unindexed_scripts':sum(r['status']=='machine_origin_not_fully_reviewed' and not r.get('indexed') for r in rows),'bound_review_scripts_all':len(complete),'caveats':['SOURCE_UNVERIFIED is not AI authorship proof.','An exact import Japanese/Chinese output pair in the original machine output log corroborates machine-origin content; reviewed descendants are not relabeled human.','No-exact-pair rows remain provenance-only, not automatic semantic review tasks.','The import scope does not prove absence of AI imports outside this identified commit; missing/unmapped routes are not semantic failures.','Overlapping chapter routes may refer to the same runtime scripts, so route counts cannot be added to fragment counts.']}
 dump('completion.json',summary);dump('ai-candidate-ledger-after.json',entries);dump('machine-origin-script-ledger.json',rows);dump('exact-human-restoration-exclusions.json',restoration_proofs)
 with (W/'machine-origin-script-ledger.csv').open('w',encoding='utf-8-sig',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=['script_id','path','status','indexed','complete','body_fields','machine_output_pair_count','import_blob','current_blob','jp_path','jp_blob'],extrasaction='ignore');writer.writeheader();writer.writerows(rows)
 s.close();print(json.dumps(summary,ensure_ascii=False,indent=2),flush=True)
if __name__=='__main__':main()
