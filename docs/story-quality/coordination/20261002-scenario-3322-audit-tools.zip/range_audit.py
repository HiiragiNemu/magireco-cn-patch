"""Bounded ZIP-range evidence: all128 delta scenario entries plus actual3322 counterparts for conflicts."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,struct,hashlib,zlib,datetime,time,re,csv
from inspect_overlap import diff
W=Path(__file__).resolve().parent;R=W.parent/'repo';C=W/'range-cache';C.mkdir(exist_ok=True)
assets={a['name']:a for a in json.loads((W/'ProgettoMagius-1-latest.json').read_bytes())['assets']}
def save(n,o):(W/n).write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def get(n,lo,hi):
 a=assets[n];key=f"{a['id']}-{lo}-{hi}";f=C/(key+'.bin');meta=C/(key+'.json')
 if f.exists():assert meta.exists() and len(f.read_bytes())==hi-lo+1;return f.read_bytes()
 r=subprocess.run(['gh','api','repos/HiiragiNemu/ProgettoMagius-1/releases/assets/'+str(a['id'])+'?audit='+str(time.time_ns()),'-H','Accept: application/octet-stream','-H',f'Range: bytes={lo}-{hi}','--include'],cwd=R,capture_output=True,timeout=150)
 assert r.returncode==0,('range GET failed',n)
 header,b=r.stdout.split(b'\r\n\r\n',1);assert b'206' in header.splitlines()[0] and f'Content-Range: bytes {lo}-{hi}/{a["size"]}'.lower().encode() in header.lower() and len(b)==hi-lo+1,('range mismatch',n)
 f.write_bytes(b);meta.write_text(json.dumps({'asset_id':a['id'],'asset_digest':a['digest'],'start':lo,'end':hi,'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'status':206}),encoding='utf8');return b

def central(n,tail=None):
 a=assets[n];lo=max(0,a['size']-65557);tail=get(n,lo,a['size']-1) if tail is None else tail
 pos=tail.rfind(b'PK\x05\x06');assert pos>=0;h=struct.unpack_from('<4s4H2LH',tail,pos);size,off=h[5],h[6]
 cd=tail[off-lo:off-lo+size] if off>=lo else get(n,off,off+size-1)
 items=[];p=0
 while p<len(cd):
  z=struct.unpack_from('<4s6H3I5H2I',cd,p);assert z[0]==b'PK\x01\x02';name=cd[p+46:p+46+z[10]].decode('utf8' if z[3]&2048 else 'cp437');items.append({'name':name,'crc':z[7],'method':z[4],'compressed':z[8],'size':z[9],'offset':z[16],'flags':z[3]});p+=46+z[10]+z[11]+z[12]
 assert len(items)==h[4] and len({x['name'] for x in items})==len(items);save(n.replace('.zip','')+'-central-evidence.json',items);return {x['name']:x for x in items}
def decompress(item,data,base):
 p=item['offset']-base;h=struct.unpack_from('<4s5H3I2H',data,p);assert h[0]==b'PK\x03\x04' and not h[2]&1;start=p+30+h[9]+h[10];compressed=data[start:start+item['compressed']];assert len(compressed)==item['compressed'];out=zlib.decompress(compressed,-15) if item['method']==8 else compressed;assert len(out)==item['size'] and zlib.crc32(out)&0xffffffff==item['crc'];return out
if __name__=='__main__':
 delta={x['name']:x for x in json.loads((W/'delta-central-directory.json').read_bytes())};ds=[x for x in delta.values() if '/scenario/' in x['name']];lo=min(x['offset'] for x in ds);hi=max(x['offset']+30+len(x['name'].encode())+x['compressed']+4096 for x in ds)
 with ThreadPoolExecutor(max_workers=2) as pool:
  fd=pool.submit(get,'cn_js_delta.zip',lo,hi);fs=pool.submit(central,'cn_scenario_update.zip');block=fd.result();sc=fs.result()
 print('DELTA_RANGE_AND_SCENARIO_DIRECTORY_READ',len(ds),len(sc),flush=True)
 expected={x['path']:x for x in json.loads((W/'ProgettoMagius-1--cn_js_delta_manifest.json').read_bytes())['entries']};known=list(csv.DictReader((W.parent/'semantic-batch10-ai-only-20261002/contributions-3322/processed-runtime-scripts.tsv').open(encoding='utf-8-sig'),delimiter='\t'));known={x['runtime_path']:x for x in known}
 rev='199c127de4ff6e628ddac2a86e4e23b0f9404590';p=subprocess.Popen(['git','--git-dir=A:/StoryQuality-20260930-1739/patch.git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE);out=[];conflicts=[]
 for x in ds:
  n=x['name'];b=decompress(x,block,lo);assert hashlib.sha256(b).hexdigest()==expected[n]['sha256'];p.stdin.write((rev+':'+n+'\n').encode());p.stdin.flush();h=p.stdout.readline().decode().split();assert h[1]=='blob';a=p.stdout.read(int(h[2]));assert p.stdout.read(1)==b'\n'
  assert sc[n]['size']==len(a) and sc[n]['crc']==zlib.crc32(a)&0xffffffff,('3322 directory mismatch with source',n)
  changes=diff(json.loads(a),json.loads(b));v={'path':n,'delta_actual_sha256':hashlib.sha256(b).hexdigest(),'scenario_source_sha256':hashlib.sha256(a).hexdigest(),'scenario_source_git_blob':h[0],'exact_equal':a==b,'json_equal':not changes,'json_differences':len(changes),'known_scenario_corrected':n in known,'scenario_actual_zip_checked':False,'differences':[{'address':list(k),'scenario':u,'delta':v} for k,u,v in changes if not isinstance(u,(dict,list)) and not isinstance(v,(dict,list))]};out.append(v)
  if a!=b:conflicts.append((v,a,b,sc[n]))
 p.stdin.close();p.wait()
 def verify(c):
  v,a,b,i=c;off=i['offset'];raw=get('cn_scenario_update.zip',off,min(assets['cn_scenario_update.zip']['size']-1,off+30+len(i['name'].encode())+i['compressed']+4096));actual=decompress(i,raw,off);assert actual==a;v['scenario_actual_zip_checked']=True;v['scenario_actual_sha256']=hashlib.sha256(actual).hexdigest();return v
 with ThreadPoolExecutor(max_workers=4) as pool:list(pool.map(verify,conflicts))
 report={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All128scenario payload entries in delta21 plus actual3322 ZIP entries for4source mismatches; all1283322central CRC/size records also matched canonical3322source','delta_asset_id':assets['cn_js_delta.zip']['id'],'delta_asset_digest':assets['cn_js_delta.zip']['digest'],'scenario_asset_id':assets['cn_scenario_update.zip']['id'],'scenario_asset_digest':assets['cn_scenario_update.zip']['digest'],'scenario_baseline_commit':rev,'overlap_count':len(out),'bytes_equal':sum(x['exact_equal'] for x in out),'json_equal':sum(x['json_equal'] for x in out),'bytes_different':sum(not x['exact_equal'] for x in out),'json_different':sum(not x['json_equal'] for x in out),'known_scenario_corrected_intersections':sum(x['known_scenario_corrected'] for x in out),'known_scenario_corrected_json_conflicts':sum(x['known_scenario_corrected'] and not x['json_equal'] for x in out),'entries':out,'whole_package_sha256_independently_recomputed':False,'device_final_files_checked':False,'no_install_or_publication_performed':True}
 save('actual-range-overlap.json',report);print('ACTUAL_RANGE_OVERLAP',json.dumps({k:v for k,v in report.items() if k!='entries'},ensure_ascii=False),flush=True);print('CONFLICTS',json.dumps([x for x in out if not x['exact_equal']],ensure_ascii=False),flush=True)
