"""Download immutable-identity checked published packages; inspect only, never install or publish."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,hashlib,subprocess,zipfile,datetime,csv
W=Path(__file__).resolve().parent;R=W.parent/'repo';P=W/'packages';P.mkdir(exist_ok=True)
rel=json.loads((W/'ProgettoMagius-1-latest.json').read_bytes());assets={a['name']:a for a in rel['assets']}
def identity(p):
 h=hashlib.sha256();m=hashlib.md5();n=0
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b);m.update(b);n+=len(b)
 return {'size':n,'sha256':h.hexdigest(),'md5':m.hexdigest()}
def acquire(n):
 a=assets[n];out=P/n
 if not out.exists():
  temp=P/(n+'.partial')
  with temp.open('wb') as f:
   r=subprocess.run(['gh','api','repos/HiiragiNemu/ProgettoMagius-1/releases/assets/'+str(a['id']),'-H','Accept: application/octet-stream'],cwd=R,stdout=f,stderr=subprocess.PIPE,timeout=360)
  if r.returncode:raise RuntimeError('Download failed '+n+' code '+str(r.returncode))
  d=identity(temp);assert d['size']==a['size'] and 'sha256:'+d['sha256']==a['digest'],('wrong package bytes',n)
  temp.rename(out)
 d=identity(out);assert d['size']==a['size'] and 'sha256:'+d['sha256']==a['digest'];print('PACKAGE_BYTES_VERIFIED',n,json.dumps(d),flush=True);return n,d

def diff(a,b,path=()):
 if type(a)!=type(b):return [(path,a,b)]
 if isinstance(a,dict):
  if set(a)!=set(b):return [(path,a,b)]
  return [v for k in a for v in diff(a[k],b[k],path+(k,))]
 if isinstance(a,list):
  if len(a)!=len(b):return [(path,a,b)]
  return [v for i,(x,y) in enumerate(zip(a,b)) for v in diff(x,y,path+(i,))]
 return [] if a==b else [(path,a,b)]
def sha(b):return hashlib.sha256(b).hexdigest()
def gitblob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
if __name__=='__main__':
 with ThreadPoolExecutor(max_workers=2) as pool:ids=dict(pool.map(acquire,['cn_scenario_update.zip','cn_js_delta.zip']))
 receipt=json.loads((W.parent/'semantic-batch10-ai-only-20261002/published-package-receipt.json').read_bytes());assert ids['cn_scenario_update.zip']==receipt['package']
 ledger=W.parent/'semantic-batch10-ai-only-20261002/contributions-3322/processed-runtime-scripts.tsv'
 rows=list(csv.DictReader(ledger.open(encoding='utf-8-sig'),delimiter='\t'));pathkey=next(k for k in rows[0] if k in ['path','runtime_path','player_path']);known={r[pathkey]:r for r in rows}
 print('KNOWN_CORRECTED_PATHS',len(known),'PATHKEY',pathkey,flush=True)
 delta_manifest=json.loads((W/'ProgettoMagius-1--cn_js_delta_manifest.json').read_bytes());out=[]
 with zipfile.ZipFile(P/'cn_scenario_update.zip') as s,zipfile.ZipFile(P/'cn_js_delta.zip') as d:
  assert s.testzip() is None and d.testzip() is None
  sn={i.filename for i in s.infolist() if not i.is_dir()};dn={i.filename for i in d.infolist() if not i.is_dir()};assert len(sn)==14233
  for e in delta_manifest['entries']:
   b=d.read(e['path']);assert len(b)==e['size'] and sha(b)==e['sha256']
  overlapping=sorted(sn&dn)
  for n in overlapping:
   a,b=s.read(n),d.read(n);da=json.loads(a);db=json.loads(b);changes=diff(da,db)
   out.append({'path':n,'scenario_sha256':sha(a),'delta_sha256':sha(b),'scenario_git_blob':gitblob(a),'delta_git_blob':gitblob(b),'exact_bytes_equal':a==b,'parsed_json_equal':da==db,'json_leaf_differences':len(changes),'previous_scenario_corrected':n in known,'difference_samples':[{'address':list(p),'scenario':x,'delta':y} for p,x,y in changes[:5] if not isinstance(x,(dict,list)) and not isinstance(y,(dict,list))]})
  report={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_only':True,'packages':ids,'delta_manifest_all_payload_entries_verified':len(delta_manifest['entries']),'delta_scenario_paths':len([n for n in dn if '/scenario/' in n]),'overlap_count':len(out),'exact_equal':sum(x['exact_bytes_equal'] for x in out),'json_equal':sum(x['parsed_json_equal'] for x in out),'different_bytes':sum(not x['exact_bytes_equal'] for x in out),'different_json':sum(not x['parsed_json_equal'] for x in out),'known_scenario_corrected_intersections':sum(x['previous_scenario_corrected'] for x in out),'known_scenario_corrected_json_conflicts':sum(x['previous_scenario_corrected'] and not x['parsed_json_equal'] for x in out),'delta_only_scenario_paths':sorted(n for n in dn-sn if '/scenario/' in n),'entries':out,'device_installation_examined':False,'warning':'Package overlap proves conflict potential, not that the client installs all overlapped entries unconditionally. Device final bytes and the guarded install paths need separate verification.'}
 (W/'actual-package-overlap.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
 print('OVERLAP_RESULT',json.dumps({k:v for k,v in report.items() if k!='entries'},ensure_ascii=False),flush=True)
 print('CONFLICT_EXAMPLES',json.dumps([x for x in out if x['previous_scenario_corrected'] and not x['parsed_json_equal']][:4],ensure_ascii=False),flush=True)
