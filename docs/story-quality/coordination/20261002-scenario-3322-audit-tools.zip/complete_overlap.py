"""Complete actual ZIP entry comparison; no source/packaging equivalence assumed."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,hashlib,zlib,csv,datetime,collections
from range_audit import get,decompress,W,R,assets
from inspect_overlap import diff
D={x['name']:x for x in json.loads((W/'delta-central-directory.json').read_bytes())};S={x['name']:x for x in json.loads((W/'cn_scenario_update-central-evidence.json').read_bytes())};names=sorted(n for n in D if '/scenario/' in n);assert len(names)==128 and set(names)<=S.keys()
lo=min(D[n]['offset'] for n in names);hi=max(D[n]['offset']+30+len(n.encode())+D[n]['compressed']+4096 for n in names);delta=get('cn_js_delta.zip',lo,hi)
intervals=sorted((S[n]['offset'],S[n]['offset']+30+len(n.encode())+S[n]['compressed']+4096,n) for n in names);groups=[]
for l,h,n in intervals:
 if groups and l-groups[-1]['end']<=131072:groups[-1]['end']=max(h,groups[-1]['end']);groups[-1]['names'].append(n)
 else:groups.append({'start':l,'end':h,'names':[n]})
scenario={}
def load(g):
 b=get('cn_scenario_update.zip',g['start'],g['end']);return {n:decompress(S[n],b,g['start']) for n in g['names']}
with ThreadPoolExecutor(max_workers=8) as pool:
 fs=[pool.submit(load,g) for g in groups]
 for f in as_completed(fs):scenario.update(f.result());print('SCENARIO_PAYLOADS',len(scenario),'/128',flush=True)
expected={x['path']:x for x in json.loads((W/'ProgettoMagius-1--cn_js_delta_manifest.json').read_bytes())['entries']};sm=json.loads((W/'ProgettoMagius-1--cn_scenario_update_manifest.json').read_bytes())['files'];known={x['runtime_path']:x for x in csv.DictReader((W.parent/'semantic-batch10-ai-only-20261002/contributions-3322/processed-runtime-scripts.tsv').open(encoding='utf-8-sig'),delimiter='\t')}
p=subprocess.Popen(['git','--git-dir=A:/StoryQuality-20260930-1739/patch.git','cat-file','--batch'],cwd=R,stdin=subprocess.PIPE,stdout=subprocess.PIPE);out=[];rev='199c127de4ff6e628ddac2a86e4e23b0f9404590'
for n in names:
 a=scenario[n];b=decompress(D[n],delta,lo);sa=hashlib.sha256(a).hexdigest();sb=hashlib.sha256(b).hexdigest();assert sb==expected[n]['sha256'];assert len(a)==sm[n]['size'] and f'{zlib.crc32(a)&0xffffffff:08x}'==sm[n]['crc32']
 p.stdin.write((rev+':'+n+'\n').encode());p.stdin.flush();head=p.stdout.readline().decode().split();assert head[1]=='blob';src=p.stdout.read(int(head[2]));assert p.stdout.read(1)==b'\n'
 changes=diff(json.loads(a),json.loads(b));out.append({'path':n,'scenario_actual_sha256':sa,'delta_actual_sha256':sb,'source_blob':head[0],'source_sha256':hashlib.sha256(src).hexdigest(),'exact_equal':a==b,'parsed_json_equal':not changes,'scenario_matches_canonical_source':a==src,'delta_matches_canonical_source':b==src,'known_scenario_corrected':n in known,'canonical_correction_versions':known.get(n,{}).get('versions'),'json_differences':len(changes),'differences':[{'address':list(k),'scenario':u,'delta':v} for k,u,v in changes if not isinstance(u,(dict,list)) and not isinstance(v,(dict,list))]})
p.stdin.close();p.wait()
report={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'All128actual overlapping ZIP entries from published delta21 and scenario3322; ZIP CRC/size and release manifest identities verified, using pinned GitHub asset IDs and strict206ranges','scenario_asset_id':assets['cn_scenario_update.zip']['id'],'scenario_asset_digest':assets['cn_scenario_update.zip']['digest'],'delta_asset_id':assets['cn_js_delta.zip']['id'],'delta_asset_digest':assets['cn_js_delta.zip']['digest'],'overlap':len(out),'bytes_equal':sum(x['exact_equal'] for x in out),'json_equal':sum(x['parsed_json_equal'] for x in out),'bytes_different':sum(not x['exact_equal'] for x in out),'json_different':sum(not x['parsed_json_equal'] for x in out),'scenario_matches_source':sum(x['scenario_matches_canonical_source'] for x in out),'delta_matches_source':sum(x['delta_matches_canonical_source'] for x in out),'known_scenario_corrected_intersections':sum(x['known_scenario_corrected'] for x in out),'known_corrected_json_conflicts':sum(x['known_scenario_corrected'] and not x['parsed_json_equal'] for x in out),'entries':out,'whole_zip_sha256_recomputed_this_audit':False,'device_final_files_checked':False,'no_install_or_publication_performed':True}
(W/'actual-package-overlap.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf8');print('COMPLETE_OVERLAP',json.dumps({k:v for k,v in report.items() if k!='entries'},ensure_ascii=False),flush=True);print('KNOWN_CORRECTION_CONFLICTS',json.dumps([x for x in out if x['known_scenario_corrected'] and not x['parsed_json_equal']],ensure_ascii=False),flush=True)
