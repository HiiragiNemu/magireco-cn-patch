"""Read-only publication inspection. Never dispatch workflows, alter assets, or expose tokens."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import subprocess,json,hashlib,datetime,base64,urllib.request
W=Path(__file__).resolve().parent;R=W.parent/'repo'
REPOS=['HiiragiNemu/magireco-cn-patch','HiiragiNemu/ProgettoMagius-1']
NAMES=['cn_scenario_update.zip','cn_js_update.zip','cn_js_delta.zip','version_scenario.json','version_js.json','version_js_delta.json','cn_scenario_update_manifest.json','cn_js_update_manifest.json','cn_js_delta_manifest.json','manifest.json','magireco-latest-legacy-client.apk','magireco-latest-legacy-client.version.json']
def save(n,d):(W/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def gh(path,binary=False):
 args=['gh','api',path]
 if binary:args+=['-H','Accept: application/octet-stream']
 r=subprocess.run(args,cwd=R,capture_output=True,timeout=120)
 if r.returncode:raise RuntimeError('GET failed: '+path+'; exit '+str(r.returncode))
 return r.stdout if binary else json.loads(r.stdout)
def repo_snapshot(repo):
 name=repo.split('/')[-1];rel=gh('repos/'+repo+'/releases/tags/latest');head=gh('repos/'+repo+'/git/ref/heads/main')['object']['sha']
 save(name+'-latest.json',rel)
 chosen={a['name']:a for a in rel['assets'] if a['name'] in NAMES};out={'repository':repo,'head':head,'latest_release_id':rel['id'],'latest_tag':rel['tag_name'],'release_name':rel['name'],'assets':{n:{k:a.get(k) for k in ['id','name','size','digest','updated_at','browser_download_url']} for n,a in chosen.items()},'metadata':{}}
 for n in ['version_scenario.json','version_js.json','version_js_delta.json','magireco-latest-legacy-client.version.json','cn_scenario_update_manifest.json','cn_js_delta_manifest.json','cn_js_update_manifest.json','manifest.json']:
  a=chosen[n];raw=gh('repos/'+repo+'/releases/assets/'+str(a['id']),True)
  assert len(raw)==a['size'] and 'sha256:'+hashlib.sha256(raw).hexdigest()==a['digest'],('metadata identity',repo,n)
  obj=json.loads(raw);(W/(name+'--'+n)).write_bytes(raw)
  out['metadata'][n]=obj if n.startswith('version_') or n.endswith('.version.json') else {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'keys':list(obj)[:16]}
 config_path='configures/personal-online-config.json' if name=='magireco-cn-patch' else 'legacy/config.json'
 c=gh('repos/'+repo+'/contents/'+config_path+'?ref='+head);config=json.loads(base64.b64decode(c['content']))
 # Retain only player-facing routing and release gates, not whole environment/config.
 out['routing']={'path':config_path,'blob':c['sha'],'client':{k:v for k,v in config.get('client',{}).items() if k in ['version','apk_url','size','sha256']},'settings':{k:v for k,v in config.get('settings',{}).items() if 'url' in k or 'version' in k or 'manifest' in k},'mirrors':config.get('mirrors',[])}
 save(name+'-snapshot.json',out);return out
if __name__=='__main__':
 W.mkdir(exist_ok=True)
 for n,args in [('initial-status.bin',['status','--porcelain=v1','-z']),('initial-diff.bin',['diff','--binary']),('initial-index.bin',['diff','--cached','--binary'])]:
  p=W/n
  if not p.exists():p.write_bytes(subprocess.check_output(['git',*args],cwd=R))
 with ThreadPoolExecutor(max_workers=2) as pool:snaps=list(pool.map(repo_snapshot,REPOS))
 out={'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'read_only':True,'snapshots':snaps,'asset_differences':[]}
 a,b=snaps
 for n in NAMES:
  aa,bb=a['assets'].get(n),b['assets'].get(n)
  if aa and bb and (aa['size'],aa['digest'])!=(bb['size'],bb['digest']):out['asset_differences'].append(n)
 save('live-publication-snapshot.json',out)
 for x in snaps:
  print(x['repository'],'HEAD',x['head'],'GATES',json.dumps({k:v for k,v in x['metadata'].items() if k.startswith('version_') or k.endswith('.version.json')},ensure_ascii=False),flush=True)
  print('ROUTING',json.dumps(x['routing'],ensure_ascii=False),flush=True)
 print('DIFFERENT_ASSETS',out['asset_differences'],flush=True)
 runs=gh('repos/HiiragiNemu/magireco-cn-patch/actions/workflows/mirror-public-resources.yml/runs?per_page=6')['workflow_runs']
 safe=[{k:r.get(k) for k in ['id','status','conclusion','event','head_sha','created_at','updated_at','html_url']} for r in runs];save('mirror-recent-runs.json',safe);print('MIRROR_RUNS',json.dumps(safe),flush=True)
