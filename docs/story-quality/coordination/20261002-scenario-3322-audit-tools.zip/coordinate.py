"""Publish isolated coordination documents only. Never mutate releases, workflows or runtime data."""
from pathlib import Path
import subprocess,json,gzip,hashlib,os,datetime,uuid
W=Path(__file__).resolve().parent;R=W.parent/'repo';B=W.parent/'semantic-batch10-ai-only-20261002';PG='A:/StoryQuality-20260930-1739/patch.git'
TASK='tsk_33166d025533cab0';OTHER='tsk_7157a63af2456791';BASE='docs/story-quality/coordination/20261002-scenario-3322-publication';NOW=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
def enc(x):return (json.dumps(x,ensure_ascii=False,indent=2)+'\n').encode()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(repo,*args,data=None,env=None):
 r=subprocess.run(['git',*(['--git-dir='+PG] if repo=='patch' else []),*args],cwd=R,input=data,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,timeout=180)
 if r.returncode:raise RuntimeError('git '+args[0]+' failed: '+r.stderr.decode(errors='replace')[:2500])
 return r.stdout

def tree(repo,ref):
 out={}
 for row in git(repo,'ls-tree','-r','-z',ref).split(b'\0'):
  if row:
   a,p=row.split(b'\t',1);out[p.decode()]=a.decode()
 return out

def guard():
 for n,a in [('initial-status.bin',('status','--porcelain=v1','-z')),('initial-diff.bin',('diff','--binary')),('initial-index.bin',('diff','--cached','--binary'))]:assert git('reader',*a)==(W/n).read_bytes(),('Reader worktree differs from audit start',n)

def commit(repo,files,expected,subject):
 assert repo in ('reader','patch') and files
 for p,b in files.items():
  assert isinstance(b,bytes)
  assert p in ('STORY_QUALITY_HANDOFF.md','docs/story-quality/CONTINUATION.md','docs/story-quality/CONTINUATION_STATE.json') or p.startswith('docs/story-quality/coordination/'),p
  if repo=='reader':assert p in ('STORY_QUALITY_HANDOFF.md','docs/story-quality/CONTINUATION.md','docs/story-quality/CONTINUATION_STATE.json'),'Only pointers in Reader'
 for attempt in range(4):
  git(repo,'fetch','origin','main');head=git(repo,'rev-parse','FETCH_HEAD').decode().strip();cur=tree(repo,head)
  assert all(cur.get(p)==v for p,v in expected.items()),'Concurrent coordination destination changed; stop rather than overwrite'
  for e in overlap['entries']:
   if repo=='patch':assert cur[e['path']].split()[2]==e['source_blob'],('Canonical story changed during audit',e['path'])
  if repo=='reader':assert cur['docs/story-quality/CONTINUATION_STATE.json']==expected['docs/story-quality/CONTINUATION_STATE.json']
  env=os.environ.copy()|{'GIT_INDEX_FILE':str(W/(repo+'-'+uuid.uuid4().hex+'.index'))};git(repo,'read-tree',head,env=env);rows=[]
  for p,b in files.items():
   h=git(repo,'hash-object','-w','--stdin',data=b).decode().strip();assert h==blob(b);rows.append(('100644 '+h+'\t'+p+'\0').encode())
  git(repo,'update-index','-z','--index-info',data=b''.join(rows),env=env);t=git(repo,'write-tree',env=env).decode().strip();env|={'GIT_AUTHOR_NAME':'HiiragiNemu','GIT_AUTHOR_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com','GIT_COMMITTER_NAME':'HiiragiNemu','GIT_COMMITTER_EMAIL':'128921071+HiiragiNemu@users.noreply.github.com'}
  c=git(repo,'commit-tree',t,'-p',head,data=(subject+' [skip ci]\n').encode(),env=env).decode().strip();new=tree(repo,c)
  assert all(new[p]==v for p,v in cur.items() if p not in files) and all(new[p].split()[2]==blob(b) for p,b in files.items())
  try:git(repo,'push','origin',c+':refs/heads/main')
  except RuntimeError:
   if attempt==3:raise
   continue
  git(repo,'fetch','origin','main');h=git(repo,'rev-parse','FETCH_HEAD').decode().strip();remote=tree(repo,h);assert all(remote[p].split()[2]==blob(b) for p,b in files.items())
  if repo=='reader':git(repo,'merge','--ff-only',c);guard()
  result={'repository':repo,'parent':head,'commit':c,'readback_head':h,'files':{p:hashlib.sha256(b).hexdigest() for p,b in files.items()},'non_target_tree_unchanged':True,'remote_readback_verified':True};(W/(repo+'-coordination-commit.json')).write_bytes(enc(result));print('COORDINATION_COMMITTED',json.dumps(result),flush=True);return result
 raise RuntimeError('No safe main update')

if __name__=='__main__':
 guard();overlap=json.loads((W/'actual-package-overlap.json').read_bytes());live=json.loads((W/'live-publication-snapshot.json').read_bytes());receipt=json.loads((B/'published-package-receipt.json').read_bytes());counts=json.loads((B/'contributions-3322/summary.json').read_bytes())
 assert overlap['overlap']==128 and overlap['bytes_different']==overlap['json_different']==128 and overlap['scenario_matches_source']==4 and overlap['delta_matches_source']==124 and overlap['known_corrected_json_conflicts']==4
 old=[e for e in overlap['entries'] if not e['known_scenario_corrected']];assert len(old)==124 and sum(e['json_differences'] for e in old)==274 and all(isinstance(d['scenario'],str) and d['scenario'].replace('白翼','白羽')==d['delta'] for e in old for d in e['differences'])
 assert receipt['version']==3322 and counts['confirmed_ai_fully_reviewed']==694 and counts['confirmed_ai_pending']==385
 specs={x['repository'].split('/')[-1]:x for x in live['snapshots']};source=specs['magireco-cn-patch'];public=specs['ProgettoMagius-1']
 for n in ('cn_js_update.zip','cn_js_delta.zip'):assert (source['assets'][n]['digest'],source['assets'][n]['size'])==(public['assets'][n]['digest'],public['assets'][n]['size'])
 assert source['metadata']['version_scenario.json']['version']==3300 and public['metadata']['version_scenario.json']['version']==3322
 report={'schema':1,'observed_at':NOW,'status':'audit_complete_pipeline_repair_owned_by_other_window','this_task':TASK,'repair_owner_task':OTHER,'other_window_acknowledged':False,'this_window_publication_hold':True,'global_workflow_disable_or_lock_performed':False,'latest_verified_story_version':3322,'source_commit':receipt['cn_patch_commit'],'reader_source_commit':receipt['reader_commit'],'scenario_package':receipt['package'],'fresh_release_snapshot':{k:v for k,v in live.items() if k!='snapshots'},'release_comparison':[{k:x[k] for k in ['repository','head','assets','metadata','routing']} for x in live['snapshots']],'latest_mirror_failure':{'run':37002364349,'message':'Refusing a public version rollback','phase':'before asset write loop','not_a_permission_error':True,'other_failures_not_all_root_caused':True},'overlap_summary':{k:v for k,v in overlap.items() if k!='entries'},'delta_retained_source_corrections':{'scripts':124,'fields':274,'change':'白翼→白羽','these_are_existing_canonical_source_corrections_not_new_translation_claims':True},'scenario_retained_source_corrections':[e for e in overlap['entries'] if e['known_scenario_corrected']],'contributions_unchanged':{'confirmed_ai':1079,'complete':694,'pending':385,'audit_adds_no_translation_credit':True},'must_not_do':['blindly rerun source3300-to-public3322mirror','remove rollback guard','delete all scenario files from delta before carrying124existing corrections forward','simply apply scenario last without reconciling124delta corrections','delete historical receipt/release dependencies without migration','run3323from the old publication helpers while coordination remains open'],'exit_conditions':['A single agreed publisher/owner per latest asset and metadata with cross-repo serialization','All128overlapping paths reconcile to canonical source or individually reviewed newer corrections;all981prior correctedruntimepaths protected','Verify firstinstall/update/offlineimport/redownload final installed bytes as applicable,not merely version3322','Confirm public/CF/source emergency routing and metadata coherence; preserve all current JS/image/client fixes','Record explicit repair receipt then allow this story window to resume from refreshed source and release baseline'],'device_final_files_verified':False,'all16packages_and_all5mirrors_verified':False,'whole_zip_sha256_recomputed_this_audit':False,'no_release_or_runtime_mutation_this_audit':True}
 md=f'''# 3322发布链协调与双向覆盖审计

核验时间：{NOW}。本窗口任务`{TASK}`；资源修复窗口任务`{OTHER}`。

## 当前分工和发布暂停

维护者明确指出另一个窗口已在核查资源包发布。本窗口已读取对方真实任务以及保存的两仓发行快照、同步脚本和失败日志。对方目标覆盖安装顺序、跨包拥有权、镜像同步与最新下载入口修复。本窗口只提供scenario已发布基线和非破坏性核验，不抢占同一修复。

**本窗口暂停3323及后续新包发布，不重跑3322、不触发镜像、不改客户端/对方工作流、不删除Release、不清数据、不重装。** 未关闭任何工作流，也没有声称建立跨进程技术锁。协调文件已放进对方正在使用的审计目录；这不等于对方已阅读或确认。

## 已证实的发布链矛盾

CN patch的latest版本文件仍是scenario3300；ProgettoMagius-1的latest是3322。JS完整包两边均为103，同尺寸同SHA；delta两边均为21，同尺寸同SHA；APK均为1.0.201。同名资产的上传日期不能替代字节核验。部分delta元数据序列化不同，但解析后的版本与payload一致。

最新同步失败run37002364349明确报`Refusing a public version rollback`，执行位置在资产写入循环之前。其意义是阻止把公开3322替换为源Release3300，不能移除保护或盲目重跑。最近6次均失败，但本次只核定了最新这次的直接原因。

本窗口的scenario发布器直接推进公开仓latest及migration/last-sync.json；原source-owned镜像却把CN patch Release当成全部资源的来源。两套发布规则没有闭合，是本窗口scenario交付流程也必须承担的集成缺口。源码已提交、单个scenario包已下载校验，并不证明最终16包安装状态。

## 128个实际ZIP交叠路径：必须双向保全

通过固定GitHub资产ID与严格206Range读取两包全部128个重叠剧情条目的真实压缩载荷，解压后逐条核验CRC、长度以及发行清单；没有把源仓文件当作已下载ZIP替身。128个文件全部存在真实JSON差异，不只是换行或JSON格式差异。

- **124个文件、274处字段**：delta保存了当前CN patch源码已有的`白翼→白羽`修订，而scenario3322仍是较早文本。这些是既有修订，不是本轮新翻译贡献。直接删除delta内剧情，或简单把scenario放在最后安装，会使这124处文件中的既有修订失效。
- **另外4个文件**：scenario3322保存了3310已发布的运行修复，delta仍是较早版本。若实际安装路径无条件让delta覆盖scenario，则会撤销这些修复。

| 剧情文件 | scenario已有、delta缺少的修复 |
| --- | --- |
| `101704-1_YTq8g.json` | 一处完整语音调用标签 |
| `101802-21_a7FVS.json` | 一处闪白和大幅震动特效标签 |
| `506905-5_ifs6e.json` | 13处角色ID／内嵌角色指令差异，当前源码使用101471 |
| `506909-9_Arnzs.json` | 21处角色ID／内嵌角色指令差异，当前源码使用100770 |

因此不是“scenario永远优先”或“delta永远优先”。在本次冻结源码`{receipt['cn_patch_commit']}`里，124项取delta现值、4项取scenario现值，能够同时保留两批已经入库的修订。实际修复前仍须刷新当前main确认没有更新修订，不能把该冻结结论机械覆盖后来的正确工作。

**尚未证明用户设备最终128项文件被无条件覆盖，也没有证据表明694份AI全文校订全部失效。** 安装路径、资源所有权过滤、首次安装/增量更新/离线导入/手动重下等实际最终文件，仍由资源修复窗口负责验证。本次未核验全部16个包，也未遍历5条镜像。

## 必须保留的3322基线

Reader源码`{receipt['reader_commit']}`；CN patch剧情源码`{receipt['cn_patch_commit']}`。

scenarioZIP：{receipt['package']['size']}字节；SHA256`{receipt['package']['sha256']}`；MD5`{receipt['package']['md5']}`。公开latest和固定scenario-3322原发布run36985876172。独立版本Release用于回退与前序receipt依赖；必须先迁移引用、保留回退点，才能整理历史入口，不能因页面拥挤直接删除。

玩家应只需使用一个清晰的latest下载页，其中所有配套资源和版本文件一致；历史审计不应要求玩家逐版本补装。不能用新的版本标签或重新上传同一份旧内容冒充修复。

## 恢复发布的条件

先统一每类资源及manifest/version的唯一发布者与跨仓并发控制；将两侧正确内容合并到唯一权威剧情载荷（或明确验证过的分层拥有权），确认旧delta/full/base不会在任何支持的安装路径撤回它。对当前已发布981个修订片段建立最终文件保全检查，并验证普通更新、全新安装、离线导入和资源重下的适用路径。修复成功后读回公开仓、Cloudflare及旧仓应急入口和客户端实际字节，形成明确修复回执，本窗口才按新基线继续校订和发包。

累计台账只在CN patch `docs/story-quality/contributions/`。本次保持1079确认AI／694完成／385待处理，旧498剧情登记及以前贡献不变，审计和重复同步不能新增翻译功劳。

## 证据与限制

同目录同名JSON为结构化协调状态；`20261002-scenario-3322-overlap.json.gz`保存全部128路径、各自实际SHA256、源码blob和逐字段差异。`20261002-scenario-3322-audit-tools.zip`只保存核验脚本、元数据与范围校验索引，不含资源ZIP、字体、凭据或设备配置。整个ZIP的SHA256本轮未重新下载计算，资产身份以发行descriptor为依据，128项实际内容已独立读取校验。

本地证据目录：`{W}`。对方协作文件：`D:\\magia\\MyProducts\\.codex-delivery\\client-publication-20261001\\.build\\resource-integrity-20261002\\SCENARIO_WINDOW_COORDINATION.md`。未向另一窗口声称直接消息已送达，未改它的任务和代码。
'''
 # Artifact source and evidence are saved before any main commit.
 (W/'Scenario_3322_Release_Coordination_20261002.md').write_text(md,encoding='utf8');(W/'coordination.json').write_bytes(enc(report))
 import zipfile
 archive=W/'audit-tools.zip';safe=['inspect_live.py','inspect_overlap.py','range_audit.py','complete_overlap.py','coordinate.py','live-publication-snapshot.json','mirror-recent-runs.json','delta-central-directory.json','cn_scenario_update-central-evidence.json','delta-manifest-vs-canonical-source.json','actual-package-overlap.json']
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
  for n in safe:z.write(W/n,n)
  for f in sorted((W/'range-cache').glob('*.json')):z.write(f,'range-verification/'+f.name)
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None
 git('patch','fetch','origin','main');ph=git('patch','rev-parse','FETCH_HEAD').decode().strip();pt=tree('patch',ph)
 files={BASE+'.md':md.encode(),BASE+'.json':enc(report),'docs/story-quality/coordination/20261002-scenario-3322-overlap.json.gz':gzip.compress((W/'actual-package-overlap.json').read_bytes(),mtime=0),'docs/story-quality/coordination/20261002-scenario-3322-audit-tools.zip':archive.read_bytes()}
 assert not any(p in pt for p in files),'Already committed coordination path; inspect existing state before retry'
 pc=commit('patch',files,{p:pt.get(p) for p in files},'docs(release): record3322 bidirectional overlap and story publication hold')
 git('reader','fetch','origin','main');rh=git('reader','rev-parse','FETCH_HEAD').decode().strip();rt=tree('reader',rh)
 paths=['STORY_QUALITY_HANDOFF.md','docs/story-quality/CONTINUATION.md','docs/story-quality/CONTINUATION_STATE.json'];raw={p:git('reader','show',rh+':'+p) for p in paths};state=json.loads(raw[paths[2]])
 assert state['scenario_version']==3322 and state['reader_source_commit']==receipt['reader_commit']
 pointer=f'''<!-- SCENARIO-PUBLICATION-COORDINATION-20261002 -->
## 当前优先：发布链协调，暂停本窗口新包

更新：{NOW}。本窗口暂不发布3323、不重跑3322、不改安装器/镜像工作流，避免和资源修复窗口`{OTHER}`并发修改发布链。3322历史单包/Reader/ADV验收仍保留，但不代表最终16包安装无覆盖。

先读CN patch协调文档：`HiiragiNemu/magireco-cn-patch:{BASE}.md`，提交`{pc['commit']}`。完整跨包差异与累计台账仍只在CN patch。修复范围由该资源窗口承担，本窗口只做基线保全与证据核验；对方尚未回执确认本协调文件。未禁用全局工作流或建立技术锁。

后续校订可做隔离准备，但在资源拥有权、单一发布链和实际安装字节验收形成明确回执前，不得沿用旧脚本发布新scenario。恢复时刷新两仓main、Release和共享协调状态，保留全部以前修订；不得删除旧delta剧情或单改安装顺序来掩盖双向修订差异。
<!-- /SCENARIO-PUBLICATION-COORDINATION-20261002 -->

'''
 assert '<!-- SCENARIO-PUBLICATION-COORDINATION-20261002 -->' not in raw[paths[0]].decode()
 hold={'status':'held_by_story_window_pending_resource_pipeline_reconciliation','this_task':TASK,'repair_owner_task':OTHER,'since':NOW,'canonical_repository':'HiiragiNemu/magireco-cn-patch','coordination_path':BASE+'.md','coordination_commit':pc['commit'],'other_window_acknowledged':False,'global_workflow_disabled':False,'standalone_scenario_verified':True,'final_composite_installation_verified':False,'rule':'No new scenario publication or old-publisher rerun before explicit cross-package repair receipt; preserve both delta and scenario corrections.'}
 state.update(updated_at=NOW,checkpoint='3322资源发布链协调：本窗口暂停新包，单包验收不等于最终安装；对方资源任务负责修复，完整证据只在CN patch',task_id=TASK,publication_hold=hold)
 state['pending']= ['优先读取CN patch发布链协调和资源修复回执，未闭合前不发布新包']+state.get('pending',[])
 rf={paths[0]:pointer.encode()+raw[paths[0]],paths[1]:pointer.encode()+raw[paths[1]],paths[2]:enc(state)}
 rc=commit('reader',rf,{p:rt[p] for p in rf},'docs(handoff): pause scenario writer pending cross-window resource repair')
 final={'reader':rc,'patch':pc,'publication_hold':hold,'no_resources_or_workflows_changed':True,'original_reader_worktree_unchanged':True};(W/'coordination-commits.json').write_bytes(enc(final))
 with (W/'Scenario_3322_Release_Coordination_20261002.md').open('a',encoding='utf8') as f:f.write('\nCN patch协调提交：`'+pc['commit']+'`。Reader仅暂停指针提交：`'+rc['commit']+'`。两个提交均已远端读回，非目标树及原Reader未提交状态保持不变。\n')
 print('COORDINATION_HANDOFF_DONE',json.dumps(final,ensure_ascii=False),flush=True)
